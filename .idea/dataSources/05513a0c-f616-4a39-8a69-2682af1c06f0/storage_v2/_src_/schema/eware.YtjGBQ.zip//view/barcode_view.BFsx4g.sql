create view barcode_view as select
                              `eware`.`ew_car`.`barcode` AS `barcode`,
                              `eware`.`ew_car`.`name`    AS `name`
                            from `eware`.`ew_car`
                            union all select
                                        `eware`.`ew_part`.`barcode` AS `barcode`,
                                        `eware`.`ew_part`.`name`    AS `name`
                                      from `eware`.`ew_part`;

