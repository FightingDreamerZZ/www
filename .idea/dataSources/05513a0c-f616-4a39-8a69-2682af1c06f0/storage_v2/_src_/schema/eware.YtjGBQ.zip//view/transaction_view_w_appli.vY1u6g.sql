create view transaction_view_w_appli as
  select
    `eware`.`ew_transaction`.`tid`                                          AS `tid`,
    `eware`.`ew_transaction`.`user`                                         AS `user`,
    `eware`.`ew_transaction`.`barcode`                                      AS `barcode`,
    (select `barcode_view`.`name` AS `name`
     from `eware`.`barcode_view`
     where (`eware`.`ew_transaction`.`barcode` = `barcode_view`.`barcode`)) AS `name`,
    `eware`.`ew_transaction`.`type`                                         AS `type`,
    `eware`.`ew_transaction`.`quantity`                                     AS `quantity`,
    `eware`.`ew_transaction`.`application`                                  AS `application`,
    `eware`.`ew_transaction`.`time`                                         AS `time`
  from `eware`.`ew_transaction`;

