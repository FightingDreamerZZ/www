-- Status:14:2144:MP_0:eware:php:1.24.4::5.5.32:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|barcode_view|300|0||
-- TABLE|ec_company|1|4336|2013-12-20 12:52:33|MyISAM
-- TABLE|ec_customer|6|4736|2013-12-20 12:51:37|MyISAM
-- TABLE|ew_admin|1|2068|2013-12-13 13:05:31|MyISAM
-- TABLE|ew_car|69|23160|2013-12-23 16:49:06|MyISAM
-- TABLE|ew_cart|1|2088|2014-01-06 10:26:40|MyISAM
-- TABLE|ew_log|812|71528|2014-01-06 10:25:28|MyISAM
-- TABLE|ew_message|4|2580|2014-01-06 10:26:40|MyISAM
-- TABLE|ew_part|231|86516|2014-01-06 10:26:40|MyISAM
-- TABLE|ew_pending|0|1024|2013-12-13 13:05:31|MyISAM
-- TABLE|ew_relation|3|2168|2013-12-20 16:57:25|MyISAM
-- TABLE|ew_transaction|354|20276|2014-01-06 10:25:37|MyISAM
-- TABLE|ew_user|8|2244|2014-01-03 10:49:58|MyISAM
-- TABLE|transaction_view|354|0||
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-01-06 16:26

--
-- Create Table `barcode_view`
--

DROP VIEW IF EXISTS `barcode_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `barcode_view` AS select `ew_car`.`barcode` AS `barcode`,`ew_car`.`name` AS `name` from `ew_car` union all select `ew_part`.`barcode` AS `barcode`,`ew_part`.`name` AS `name` from `ew_part`;



--
-- Create Table `ec_company`
--

DROP TABLE IF EXISTS `ec_company`;
CREATE TABLE `ec_company` (
  `name` varchar(80) CHARACTER SET utf8 NOT NULL,
  `slogan` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tax_number` varchar(40) CHARACTER SET utf8 NOT NULL,
  `address1` varchar(100) CHARACTER SET utf8 NOT NULL,
  `address2` varchar(100) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fax` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(80) CHARACTER SET utf8 NOT NULL,
  `web` varchar(40) CHARACTER SET utf8 NOT NULL,
  `logo_url` varchar(40) CHARACTER SET utf8 NOT NULL,
  `tax_rate` decimal(4,2) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ec_company`
--

/*!40000 ALTER TABLE `ec_company` DISABLE KEYS */;
INSERT INTO `ec_company` (`name`,`slogan`,`tax_number`,`address1`,`address2`,`phone`,`fax`,`email`,`web`,`logo_url`,`tax_rate`) VALUES ('AGT Electric Cars','Our parent company can benefit all mankind.','82270 4896 RT0001','1185 Corporate Drive, Unit #2','Burlington, Ontario, Canada L7L 5V5','1-905-331-0491','1-905-331-3504','info@agtecars.com','www.agtecars.com','images/companylogo.png','0.13');
/*!40000 ALTER TABLE `ec_company` ENABLE KEYS */;


--
-- Create Table `ec_customer`
--

DROP TABLE IF EXISTS `ec_customer`;
CREATE TABLE `ec_customer` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `logo_url` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT 'upload/defaultlogo.jpg',
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `contact` varchar(40) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fax` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(80) CHARACTER SET utf8 DEFAULT NULL,
  `web` varchar(80) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `des` text CHARACTER SET utf8,
  `interact` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` varchar(20) CHARACTER SET utf8 NOT NULL,
  `xsearch` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Data for Table `ec_customer`
--

/*!40000 ALTER TABLE `ec_customer` DISABLE KEYS */;
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('2','upload/1387533447466.png','AGT Electric Cars','Reception','9053310491','9053313504','info@agtecars.com','www.agtecars.com','1185 Corporate Drive, Unit #2,','Burlington, Ontario, Canada, L7L 5V5','Home Company','2013-12-20 04:57:27','partner','existing','company:agt electric cars, type:partner, status:existing, contact:reception, phone:9053310491, fax:9053313504, web:www.agtecars.com, email:info@agtecars.com , address:1185 corporate drive, unit #2, burlington, ontario, canada, l7l 5v5');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('3','upload/defaultlogo.jpg','Armada Golf Cars','Bill Heaps','9057133525','9057133526','armadacorp@bellnet.ca','www.armadagolfcars.ca','36 Industrial Parkway South,','Aurora, Ontario, Canada L4G 3W2','','2013-12-20 05:34:35','dealer','existing','company:armada golf cars, type:dealer, status:existing, contact:bill heaps, phone:9057133525, fax:9057133526, web:www.armadagolfcars.ca, email:armadacorp@bellnet.ca , address:36 industrial parkway south, aurora, on l4g 3w2');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('4','upload/defaultlogo.jpg','Birdie Golf Cart','Mike Macdonald','9058943113','9058949985','mikemacdonald@telus.blackberry.net','www.birdiegolfcarts.com','4915 Ontario #3','Ridgeway, Ontario, Canada, L0S 1N0','','2013-12-20 05:38:34','dealer','existing','company:birdie golf cart, type:dealer, status:existing, contact:mike macdonald, phone:9058943113, fax:9058949985, web:www.birdiegolfcarts.com, email:mikemacdonald@telus.blackberry.net , address:4915 ontario #3 ridgeway, on, l0s 1n0');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('5','upload/defaultlogo.jpg','Calgary Golf Cart Centre','Kelly Gurnsey','4032795025','4032034233','calgarygolfcar@rogers.com','www.calgarygolfcentre.com','Bay 7, 4115 - 64th Avenue S.E.,','Calgary, Alberta, Canada, T2C 2C8','','2013-12-20 05:40:06','dealer','existing','company:calgary golf cart centre, type:dealer, status:existing, contact:kelly gurnsey, phone:4032795025, fax:4032034233, web:www.calgarygolfcentre.com, email:calgarygolfcar@rogers.com , address:bay 7, 4115 - 64th avenue s.e., calgary, alberta, t2c 2c8');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('6','upload/defaultlogo.jpg','Canadian Cart Sales','Perry Stover','5193492300','5193492221','perrys@turfcare.ca','www.canadiancartsales.com','P.O Box 159, 4 Given Road,','St. Marys, Ontario, Canada, N4X 1B1','','2013-12-20 05:43:07','dealer','existing','company:canadian cart sales, type:dealer, status:existing, contact:perry stover, phone:5193492300, fax:5193492221, web:www.canadiancartsales.com, email:perrys@turfcare.ca , address:p.o box 159, 4 given road, st. marys, ontario, n4x 1b1');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('7','upload/defaultlogo.jpg','Cart Guy','Chris/Jamie/Kim','18889052278','18663532278','sales@cartguy.ca','www.cartguy.ca','2933 Hwy #35 S., Box 105,','Lindsay, Ontario, Canada, K9V 4R4','','2013-12-20 05:45:21','dealer','existing','company:cart guy, type:dealer, status:existing, contact:chris/jamie/kim, phone:18889052278, fax:18663532278, web:www.cartguy.ca, email:sales@cartguy.ca , address:2933 hwy #35 s., box 105, lindsay, ontario, k9v 4r4');
/*!40000 ALTER TABLE `ec_customer` ENABLE KEYS */;


--
-- Create Table `ew_admin`
--

DROP TABLE IF EXISTS `ew_admin`;
CREATE TABLE `ew_admin` (
  `user` varchar(40) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(40) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_admin`
--

/*!40000 ALTER TABLE `ew_admin` DISABLE KEYS */;
INSERT INTO `ew_admin` (`user`,`pass`) VALUES ('admin','1');
/*!40000 ALTER TABLE `ew_admin` ENABLE KEYS */;


--
-- Create Table `ew_car`
--

DROP TABLE IF EXISTS `ew_car`;
CREATE TABLE `ew_car` (
  `barcode` varchar(20) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT 'Name of the car',
  `photo_url` varchar(200) DEFAULT 'upload\\default.jpg' COMMENT 'Photo URL',
  `model` varchar(40) NOT NULL COMMENT 'Model of the car',
  `vin` varchar(40) DEFAULT NULL,
  `year` int(10) NOT NULL DEFAULT '2013',
  `category` varchar(20) NOT NULL COMMENT 'Finished/Semi finished',
  `color` varchar(20) DEFAULT NULL COMMENT 'The color of product',
  `condition` varchar(20) NOT NULL COMMENT 'New, used, demo, damaged',
  `p_price` decimal(10,2) NOT NULL COMMENT 'Purchase price',
  `w_price` decimal(10,2) NOT NULL COMMENT 'Wholesale price',
  `r_price` decimal(10,2) NOT NULL COMMENT 'Retail price',
  `quantity` int(10) NOT NULL COMMENT 'Amount in stock',
  `w_quantity` int(10) NOT NULL COMMENT 'Warning if in stock less than this amount',
  `l_zone` varchar(20) DEFAULT NULL COMMENT 'Location zone',
  `l_column` varchar(20) DEFAULT NULL COMMENT 'Location column',
  `l_level` varchar(20) DEFAULT NULL COMMENT 'Location level',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Latest update date',
  `des` text COMMENT 'Description of item',
  `xsearch` text NOT NULL COMMENT 'name,barcode,model,category,color,location,condition',
  PRIMARY KEY (`barcode`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_car`
--

/*!40000 ALTER TABLE `ew_car` DISABLE KEYS */;
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849843167','KERNEL','upload/1387564421160.jpg','EG6020X','Null','2013','finish','orange','new','0.00','10999.00','13999.00','1','5','n','1','1','2013-12-20 13:33:42','										','barcode:013849843167, name:kernel, model:eg6020x, category:finish, color:orange, location:n_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849843596','HULK','upload/1387814466567.jpg','EG6020A4D','Null','2013','finish','camo','new','0.00','9850.00','12999.00','1','0','n','1','1','2013-12-23 11:01:07','','barcode:013849843596, name:hulk, model:eg6020a4d, category:finish, color:camo, location:n_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849844238','HOBBIT 4+2 Customize','upload/1387564555098.jpg','EG2048KSZ','Null','2013','finish','blue','new','0.00','5750.00','7699.00','1','0','n','1','1','2013-12-20 13:35:56','No Cover','barcode:013849844238, name:hobbit 4+2 customize, model:eg2048ksz, category:finish, color:blue, location:n_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849845400','Motorcycle','upload/1387564515817.jpg','Customize','123','2013','finish','white','damaged','0.00','0.00','0.00','1','0','n','1','1','2013-12-20 13:35:16','no battery','barcode:013849845400, name:motorcycle, model:customize, category:finish, color:white, location:n_1_1, condition:damaged, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849846414','QUANTUM Customize','upload/1387564287707.jpg','EG6043K01','Null','2013','finish','white','new','0.00','8499.00','10999.00','1','0','c','1','1','2013-12-20 13:31:28','This car is sealed.','barcode:013849846414, name:quantum customize, model:eg6043k01, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849847336','Garbage Truck','upload/1387563015035.jpg','Customize','Undefined ','2013','finish','green','new','0.00','0.00','0.00','1','0','c','1','1','2013-12-20 13:10:16','','barcode:013849847336, name:garbage truck, model:customize, category:finish, color:green, location:c_1_1, condition:new, year:2013, vin:undefined ');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848035','ARGO 14','upload/1387564596238.jpg','EG6158K01','Null','2013','finish','black','new','0.00','13599.00','17999.00','1','0','c','1','1','2013-12-20 13:36:37','','barcode:013849848035, name:argo 14, model:eg6158k01, category:finish, color:black, location:c_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848309','ARGO 14','upload/1387564626801.jpg','EG6158K01','Null','2013','finish','white','new','0.00','13599.00','17999.00','1','0','c','1','1','2013-12-20 13:37:07','','barcode:013849848309, name:argo 14, model:eg6158k01, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848727','HOBBIT 2+2 Ambulance','upload/1387563091145.jpg','EG2028KSZ01','Undefine','2013','finish','red','new','0.00','4599.00','6199.00','1','0','c','2','1','2013-12-20 13:11:32','','barcode:013849848727, name:hobbit 2+2 ambulance, model:eg2028ksz01, category:finish, color:red, location:c_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849849042','HOBBIT 6+2','upload/1387564742801.jpg','EG2068KSZ','Null','2013','finish','red','new','0.00','6999.00','9150.00','1','0','c','2','1','2013-12-20 13:39:03','','barcode:013849849042, name:hobbit 6+2, model:eg2068ksz, category:finish, color:red, location:c_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849850219','HOBBIT 6+2','upload/1387564697738.jpg','EG2068KSZ','Null','2013','finish','silver','demo','0.00','6999.00','9150.00','1','0','c','2','1','2013-12-20 13:38:18','','barcode:013849850219, name:hobbit 6+2, model:eg2068ksz, category:finish, color:silver, location:c_2_1, condition:demo, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849851104','HOBBIT 4+2','upload/1387564952770.jpg','EG2048KSZ','Null','2013','finish','green','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-12-20 13:42:33','','barcode:013849851104, name:hobbit 4+2, model:eg2048ksz, category:finish, color:green, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849851341','HOBBIT 4+2','upload/1387564901957.jpg','EG2048KSZ','Null','2013','finish','black','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-12-20 13:41:42','										','barcode:013849851341, name:hobbit 4+2, model:eg2048ksz, category:finish, color:black, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852101','RAMBLER','upload/1387565717598.jpg','EG2040ASZ','123','2013','finish','black','damaged','0.00','6199.00','8299.00','1','0','c','4','1','2013-12-23 14:14:39','','barcode:013849852101, name:rambler, model:eg2040asz, category:finish, color:black, location:c_4_1, condition:damaged, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852326','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','semi','silver','new','0.00','5950.00','7499.00','1','0','c','4','1','2013-11-20 17:08:14','','barcode:013849852326, name:nomad, model:eg2020asz, category:semi, color:silver, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852676','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','semi','gold','new','0.00','5950.00','7499.00','1','0','c','4','1','2013-11-20 17:08:04','','barcode:013849852676, name:nomad, model:eg2020asz, category:semi, color:gold, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849853196','CRICKET 2','upload/1387565083332.jpg','EG2028K','Null','2013','semi','white','demo','0.00','4299.00','5799.00','1','0','c','5','1','2013-12-20 13:44:44','','barcode:013849853196, name:cricket 2, model:eg2028k, category:semi, color:white, location:c_5_1, condition:demo, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849853756','HOBBIT 2+2','upload/1387565205926.jpg','EG2028KSZ01','Null','2013','semi','black','new','0.00','4599.00','6199.00','1','0','s','1','1','2013-12-20 13:46:46','','barcode:013849853756, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:black, location:s_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849854322','HOBBIT 4+2','upload/1387565013754.jpg','EG2048KSZ','Null','2013','finish','black','new','0.00','5750.00','7699.00','1','0','s','2','1','2013-12-20 13:43:34','','barcode:013849854322, name:hobbit 4+2, model:eg2048ksz, category:finish, color:black, location:s_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849854684','QUANTUM Customize','upload/1387564353160.jpg','EG6043K01','Null','2013','finish','white','new','0.00','8499.00','10999.00','1','0','s','2','1','2013-12-20 13:32:34','This car has a cargo box~','barcode:013849854684, name:quantum customize, model:eg6043k01, category:finish, color:white, location:s_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849855695','CRICKET 2','upload/1387565153395.jpg','EG2028K','Null','2013','semi','green','used','0.00','4299.00','5799.00','1','0','e','6','1','2013-12-20 13:45:54','','barcode:013849855695, name:cricket 2, model:eg2028k, category:semi, color:green, location:e_6_1, condition:used, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856001','NOMAD','upload/1387565301223.jpg','EG2020ASZ','Null','2013','finish','black','new','0.00','5950.00','7499.00','1','0','e','5','1','2013-12-20 13:48:22','','barcode:013849856001, name:nomad, model:eg2020asz, category:finish, color:black, location:e_5_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856394','CRICKET 2','upload/sample/cricket2.jpg','EG2028K',NULL,'2013','finish','red','new','0.00','4299.00','5799.00','1','0','e','5','1','2013-11-20 17:14:09','','barcode:013849856394, name:cricket 2, model:eg2028k, category:finish, color:red, location:e_5_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856577','NOMAD','upload/1387565390020.jpg','EG2020ASZ','Null','2013','finish','black','new','0.00','5950.00','7499.00','1','0','c','5','1','2013-12-20 13:49:51','','barcode:013849856577, name:nomad, model:eg2020asz, category:finish, color:black, location:c_5_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856801','NUCLEUS','upload/1387565761363.jpg','EG6021H','Null','2013','finish','orange','new','0.00','7199.00','9599.00','1','0','c','4','1','2013-12-20 13:56:02','','barcode:013849856801, name:nucleus, model:eg6021h, category:finish, color:orange, location:c_4_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857035','HOBBIT 2+2','upload/1387565666192.jpg','EG2028KSZ01','Null','2013','finish','black','new','0.00','4599.00','6199.00','1','0','e','4','1','2013-12-20 13:54:27','','barcode:013849857035, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:e_4_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857340','HOBBIT 2+2','upload/1387565575863.jpg','EG2028KSZ01','Null','2013','finish','red','new','0.00','4599.00','6199.00','1','0','c','3','1','2013-12-20 13:52:56','','barcode:013849857340, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:red, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857778','HOBBIT 4+2','upload/1387563476723.jpg','EG2048KSZ','123','2013','finish','green','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-12-20 13:17:57','','barcode:013849857778, name:hobbit 4+2, model:eg2048ksz, category:finish, color:green, location:c_3_1, condition:new, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857969','HOBBIT 2+2','upload/1387565605895.jpg','EG2028KSZ01','Null','2013','finish','green','new','0.00','4599.00','6199.00','1','0','c','3','1','2013-12-20 13:53:26','','barcode:013849857969, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:green, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858260','NOMAD','upload/1387565348410.jpg','EG2020ASZ','Null','2013','finish','red','new','0.00','5950.00','7499.00','1','0','c','2','1','2013-12-20 13:49:09','','barcode:013849858260, name:nomad, model:eg2020asz, category:finish, color:red, location:c_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858479','HOBBIT 2+2','upload/1387565637832.jpg','EG2028KSZ01','Null','2013','finish','blue','damaged','0.00','4599.00','6199.00','1','0','e','2','1','2013-12-20 13:53:58','','barcode:013849858479, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:blue, location:e_2_1, condition:damaged, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858782','RAMBLER','upload/1387564847832.jpg','EG2040ASZ','Null','2013','finish','silver','new','0.00','6199.00','8299.00','1','0','e','2','1','2013-12-23 14:13:00','','barcode:013849858782, name:rambler, model:eg2040asz, category:finish, color:silver, location:e_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859041','RAMBLER','upload/1387564802192.jpg','EG2040ASZ','Null','2013','finish','blue','new','0.00','6199.00','8299.00','1','0','c','2','1','2013-12-23 14:12:24','','barcode:013849859041, name:rambler, model:eg2040asz, category:finish, color:blue, location:c_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859323','HOBBIT 2+2','upload/1387565534410.jpg','EG2028KSZ01','Null','2013','finish','black','new','0.00','4599.00','6199.00','1','0','c','2','1','2013-12-20 13:52:15','','barcode:013849859323, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:c_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859659','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','321','2013','semi','black','new','0.00','6199.00','8299.00','1','0','c','4','1','2013-12-23 14:12:08','','barcode:013849859659, name:rambler, model:eg2040asz, category:semi, color:black, location:c_4_1, condition:new, year:2013, vin:321');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859999','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','123','2013','semi','silver','new','0.00','5750.00','7699.00','1','0','c','4','1','2013-11-28 09:42:37','','barcode:013849859999, name:hobbit 4+2, model:eg2048ksz, category:semi, color:silver, location:c_4_1, condition:new, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013853546558','ARGO 11','upload/sample/argo11.jpg','EG6118KA','3C3CFFAR1DT546508','2013','finish','black','new','0.00','12299.00','15599.00','0','0','c','1','1','2013-11-25 10:44:00','Assembly by otto;','barcode:013853546558, name:argo 11, model:eg6118ka, category:finish, color:black, location:c_1_1, condition:new, year:2013, vin:3c3cffar1dt546508');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013859994784','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','finish','White','new','0.00','5850.00','7899.00','0','0','c','1','1','2013-12-23 16:35:01','Serial Number: 13080079\r\nController Number: 12261P060690','barcode:013859994784, name:hobbit 2hcx, model:eg2048hcx, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878178357','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','semi','Green','new','0.00','5850.00','7899.00','1','0','W','3','1','2013-12-23 11:59:10','','barcode:013878178357, name:hobbit 2hcx, model:eg2048hcx, category:semi, color:green, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878179093','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Silver','new','0.00','6199.00','8299.00','1','0','W','3','1','2013-12-23 14:11:51','','barcode:013878179093, name:rambler, model:eg2040asz, category:semi, color:silver, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878179678','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Red','new','0.00','6199.00','8299.00','1','0','W','3','1','2013-12-23 14:11:39','','barcode:013878179678, name:rambler, model:eg2040asz, category:semi, color:red, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878181388','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','semi','Black','new','0.00','5850.00','7899.00','1','0','W','3','1','2013-12-23 12:02:43','','barcode:013878181388, name:hobbit 2hcx, model:eg2048hcx, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878183182','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','undefine','2013','semi','Red','new','0.00','5750.00','7699.00','1','0','W','3','1','2013-12-23 12:05:45','','barcode:013878183182, name:hobbit 4+2, model:eg2048ksz, category:semi, color:red, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878248948','HOBBIT 4+H','upload/sample/hobbit4ph.jpg','EG2048H','undefine','2013','semi','Black','new','0.00','5750.00','7699.00','1','0','W','3','1','2013-12-23 13:55:35','','barcode:013878248948, name:hobbit 4+h, model:eg2048h, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878250105','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Silver','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 13:57:58','','barcode:013878250105, name:nomad, model:eg2020asz, category:semi, color:silver, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878250462','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Blue','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 13:57:44','','barcode:013878250462, name:nomad, model:eg2020asz, category:semi, color:blue, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878252345','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Black','new','0.00','4599.00','6199.00','1','0','W','3','1','2013-12-23 14:01:09','','barcode:013878252345, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878252919','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Silver','new','0.00','4599.00','6199.00','1','0','W','3','1','2013-12-23 14:01:59','','barcode:013878252919, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:silver, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878253878','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Orange','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 14:03:27','','barcode:013878253878, name:nomad, model:eg2020asz, category:semi, color:orange, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878254236','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Green','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 14:04:13','','barcode:013878254236, name:nomad, model:eg2020asz, category:semi, color:green, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878255184','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Black','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 14:05:35','','barcode:013878255184, name:nomad, model:eg2020asz, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878255554','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','undefine','2013','semi','Silver','new','0.00','5750.00','7699.00','1','0','W','2','1','2013-12-23 14:06:16','','barcode:013878255554, name:hobbit 4+2, model:eg2048ksz, category:semi, color:silver, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878261696','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Black','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:17:36','','barcode:013878261696, name:rambler, model:eg2040asz, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878269189','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Black','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:29:01','','barcode:013878269189, name:rambler, model:eg2040asz, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878269640','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Orange','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:30:41','','barcode:013878269640, name:rambler, model:eg2040asz, category:semi, color:orange, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878269848','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Orange','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:30:01','','barcode:013878269848, name:rambler, model:eg2040asz, category:semi, color:orange, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878270074','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Green','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:30:26','','barcode:013878270074, name:rambler, model:eg2040asz, category:semi, color:green, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878271054','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','White','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:32:11','','barcode:013878271054, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:white, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878272167','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ','undefine','2013','semi','Black','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:34:10','','barcode:013878272167, name:hobbit 2+2, model:eg2028ksz, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878272679','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Red','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:34:49','','barcode:013878272679, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:red, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878273016','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Silver','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:35:17','','barcode:013878273016, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:silver, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878273573','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Red','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:36:12','','barcode:013878273573, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:red, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878273839','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Black','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:36:38','','barcode:013878273839, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878274028','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Silver','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:37:14','','barcode:013878274028, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:silver, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878274540','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ','undefine','2013','semi','White','new','0.00','6999.00','9150.00','1','0','W','1','1','2013-12-23 14:37:51','','barcode:013878274540, name:hobbit 6+2, model:eg2068ksz, category:semi, color:white, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878274827','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ','undefine','2013','semi','Black','new','0.00','6999.00','9150.00','1','0','W','1','1','2013-12-23 14:38:20','','barcode:013878274827, name:hobbit 6+2, model:eg2068ksz, category:semi, color:black, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878275466','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','undefine','2013','semi','White','new','0.00','5750.00','7699.00','1','0','W','1','1','2013-12-23 14:39:28','','barcode:013878275466, name:hobbit 4+2, model:eg2048ksz, category:semi, color:white, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878275778','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ','undefine','2013','semi','Silver','new','0.00','6999.00','9150.00','1','0','W','1','1','2013-12-23 14:39:53','','barcode:013878275778, name:hobbit 6+2, model:eg2068ksz, category:semi, color:silver, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878292620','HOBBIT 4+2','upload/1387829760988.jpg','EG2048KSZ','undefine','2013','semi','Red','new','0.00','5750.00','7699.00','1','0','P','1','1','2013-12-23 15:16:02','','barcode:013878292620, name:hobbit 4+2, model:eg2048ksz, category:semi, color:red, location:p_1_1, condition:new, year:2013, vin:undefine');
/*!40000 ALTER TABLE `ew_car` ENABLE KEYS */;


--
-- Create Table `ew_cart`
--

DROP TABLE IF EXISTS `ew_cart`;
CREATE TABLE `ew_cart` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user` varchar(20) CHARACTER SET utf8 NOT NULL,
  `table` varchar(20) CHARACTER SET utf8 NOT NULL,
  `quantity` int(10) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=230 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_cart`
--

/*!40000 ALTER TABLE `ew_cart` DISABLE KEYS */;
INSERT INTO `ew_cart` (`cid`,`barcode`,`user`,`table`,`quantity`) VALUES ('229','113878261008','otto ','ew_part','1');
/*!40000 ALTER TABLE `ew_cart` ENABLE KEYS */;


--
-- Create Table `ew_log`
--

DROP TABLE IF EXISTS `ew_log`;
CREATE TABLE `ew_log` (
  `log_id` int(20) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Log time',
  `user` varchar(20) NOT NULL COMMENT 'Who made this transaction',
  `msg` tinytext NOT NULL COMMENT 'Log message',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=813 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_log`
--

/*!40000 ALTER TABLE `ew_log` DISABLE KEYS */;
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1','2013-12-05 11:16:17','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('2','2013-12-10 10:01:18','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('3','2013-12-12 11:34:00','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('4','2013-12-12 15:35:55','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('5','2013-12-13 10:41:07','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('6','2013-12-13 10:41:20','otto','del part, barcode=113855784845,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('7','2013-12-13 16:48:23','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('8','2013-12-16 09:50:35','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('9','2013-12-16 10:04:19','si','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('10','2013-12-16 11:08:22','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('11','2013-12-16 11:45:54','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('12','2013-12-16 11:48:11','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('13','2013-12-16 11:49:27','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('14','2013-12-16 13:27:34','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('15','2013-12-18 09:43:53','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('16','2013-12-18 12:34:40','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('17','2013-12-18 12:35:22','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('18','2013-12-18 12:35:47','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('19','2013-12-18 13:18:42','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('20','2013-12-18 13:19:49','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('21','2013-12-18 13:23:43','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('22','2013-12-18 13:25:36','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('23','2013-12-18 13:26:03','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('24','2013-12-18 13:26:27','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('25','2013-12-18 13:27:18','otto','edit part, barcode=113861020003,name=Passenger Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('26','2013-12-18 13:28:54','otto','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('27','2013-12-18 13:29:13','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('28','2013-12-18 13:32:02','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('29','2013-12-18 13:34:12','otto','edit part, barcode=113861020003,name=Passenger Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('30','2013-12-18 13:38:26','otto','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('31','2013-12-18 13:56:09','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('32','2013-12-18 13:56:13','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('33','2013-12-18 13:57:55','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('34','2013-12-18 14:58:10','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('35','2013-12-18 15:10:58','otto','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('36','2013-12-18 15:12:11','otto','edit part, barcode=113860008361,name=Central Cover - camouflage - used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('37','2013-12-18 15:12:49','otto','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('38','2013-12-18 15:13:55','otto','edit part, barcode=113860007132,name=Front Cover - Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('39','2013-12-18 15:14:18','otto','edit part, barcode=113860008361,name=Central Cover - camouflage - used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('40','2013-12-18 15:14:43','otto','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('41','2013-12-18 15:15:20','otto','edit part, barcode=113860005355,name=Front Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('42','2013-12-18 15:15:47','otto','edit part, barcode=113860002295,name=Front Cover - Metallic Green - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('43','2013-12-18 15:16:46','otto','edit part, barcode=113856751895,name=Rear Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('44','2013-12-18 15:17:11','otto','edit part, barcode=113856751451,name=Rear Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('45','2013-12-18 15:19:02','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('46','2013-12-18 15:19:25','otto','edit part, barcode=113856750152,name=Rear Cover - Metallic Green - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('47','2013-12-18 15:20:43','otto','edit part, barcode=113856751451,name=Rear Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('48','2013-12-18 15:21:38','otto','edit part, barcode=113856751451,name=Rear Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('49','2013-12-18 15:26:30','otto','edit part, barcode=113856732204,name=770x1100x250 Carbon Steel Cargo Box- Standard');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('50','2013-12-18 15:26:55','otto','edit part, barcode=113856732204,name=770x1100x250 Carbon Steel Cargo Box- Standard');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('51','2013-12-18 15:27:44','otto','edit part, barcode=113856730198,name=770x1100x250 Aluminum Cargo Box- Standard');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('52','2013-12-18 15:28:25','otto','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('53','2013-12-18 15:29:55','otto','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('54','2013-12-18 15:33:08','otto','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('55','2013-12-18 15:33:40','otto','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('56','2013-12-18 15:34:59','otto','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('57','2013-12-18 15:36:35','otto','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('58','2013-12-18 15:37:56','otto','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('59','2013-12-18 15:38:35','otto','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('60','2013-12-18 15:38:50','otto','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('61','2013-12-18 15:39:34','otto','edit part, barcode=113856717210,name=1400x1100x250 Carbon Steel Cargo Box- Manual Dump');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('62','2013-12-18 15:40:51','otto','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('63','2013-12-18 15:41:31','otto','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('64','2013-12-18 15:42:13','otto','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('65','2013-12-18 15:45:26','otto','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('66','2013-12-18 15:47:03','otto','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('67','2013-12-18 15:49:51','otto','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('68','2013-12-18 15:50:39','otto','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('69','2013-12-18 15:51:56','otto','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('70','2013-12-18 15:55:21','otto','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('71','2013-12-18 15:58:55','otto','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('72','2013-12-18 15:59:41','otto','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('73','2013-12-18 16:00:22','otto','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('74','2013-12-18 16:00:46','otto','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('75','2013-12-18 16:01:35','otto','edit part, barcode=113855777806,name=25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('76','2013-12-18 16:04:35','otto','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('77','2013-12-18 16:05:11','otto','edit part, barcode=113855768358,name=21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('78','2013-12-18 16:09:58','otto','add new part, barcode=113874008674,name=Front Bumper - Metallic,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('79','2013-12-18 16:14:28','otto','add new part, barcode=113874010003,name=Windshield - Non Foldable - 6040,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('80','2013-12-18 16:16:07','otto','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('81','2013-12-18 16:17:18','otto','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('82','2013-12-18 16:18:07','otto','edit part, barcode=113861699105,name=Front Axle Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('83','2013-12-18 16:30:02','otto','add new part, barcode=113874020209,name=Backrest Cushion,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('84','2013-12-18 16:33:34','otto','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('85','2013-12-18 16:38:24','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('86','2013-12-18 16:40:07','san','add new part, barcode=113874027780,name=sads,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('87','2013-12-18 16:52:01','otto','add new part, barcode=113874033533,name=Side Rear View Mirror,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('88','2013-12-18 16:52:54','otto','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('89','2013-12-19 09:30:20','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('90','2013-12-19 09:31:19','otto','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('91','2013-12-19 09:31:44','otto','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('92','2013-12-19 10:07:47','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('93','2013-12-19 10:12:16','otto','add new part, barcode=113874657396,name=Front Basket,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('94','2013-12-19 10:15:24','otto','add new part, barcode=113874660495,name=Inner Rearview Mirror,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('95','2013-12-19 10:21:01','otto','add new part, barcode=113874661256,name=Rear Bracket,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('96','2013-12-19 10:23:53','otto','add new part, barcode=113874665250,name=Rear Bracket - 2028K,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('97','2013-12-19 10:25:19','otto','add new part, barcode=113874666349,name=Rear Bracket - 2028KSF,amount=14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('98','2013-12-19 10:26:57','otto','add new part, barcode=113874667209,name=Front Basket Bracket,amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('99','2013-12-19 10:28:24','otto','add new part, barcode=113874668190,name=Rear Standing Board,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('100','2013-12-19 10:30:44','otto','add new part, barcode=113874669055,name=Sweater Basket - Carbon Steel,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('101','2013-12-19 10:33:15','otto','del part, barcode=113874027780,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('102','2013-12-19 10:36:42','otto','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('103','2013-12-19 10:38:03','otto','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('104','2013-12-19 10:41:04','otto','add new part, barcode=113874676203,name=Rear Bracket - Undefined,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('105','2013-12-19 10:46:30','otto','add new part, barcode=113874676661,name=Seat Back Main Bracket - 2028 Cargo Box,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('106','2013-12-19 11:02:16','otto','add new part, barcode=113874688608,name=Cargo Box Support Bracket - 2048HCX,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('107','2013-12-19 11:03:43','otto','add new part, barcode=113874689510,name=Side Armrest,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('108','2013-12-19 11:05:43','otto','add new part, barcode=113874690781,name=Seat Frame,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('109','2013-12-19 11:09:22','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('110','2013-12-19 11:10:55','otto','add new part, barcode=113874694069,name=Cargo Box Bracket Support,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('111','2013-12-19 11:13:38','otto','add new part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('112','2013-12-19 11:14:12','otto','edit part, barcode=113874689510,name=Side Armrest');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('113','2013-12-19 11:14:29','otto','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('114','2013-12-19 11:15:16','otto','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('115','2013-12-19 11:15:38','otto','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('116','2013-12-19 11:23:18','otto','add new part, barcode=113874701375,name=Searching Light Bracket 1,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('117','2013-12-19 14:08:39','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('118','2013-12-19 14:11:10','otto','add new part, barcode=113874801718,name=Searching Light,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('119','2013-12-19 14:14:21','otto','add new part, barcode=113874802719,name=Rear assembled light - LH,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('120','2013-12-19 14:15:45','otto','add new part, barcode=113874804634,name=Rear assembled light - RH,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('121','2013-12-19 14:18:08','otto','add new part, barcode=113874805471,name=Head Light - LH EG2028,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('122','2013-12-19 14:18:39','otto','add new part, barcode=113874806896,name=Head Light - RH EG2028,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('123','2013-12-19 14:19:42','otto','add new part, barcode=113874807201,name=Combination Switch,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('124','2013-12-19 14:21:13','otto','add new part, barcode=113874807834,name=Converter DC 48V-12V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('125','2013-12-19 14:21:57','otto','add new part, barcode=113874808788,name=Converter DC 36V-12V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('126','2013-12-19 14:25:17','otto','add new part, barcode=113874809185,name=Controller Curtis 1243-4320,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('127','2013-12-19 14:27:44','otto','add new part, barcode=113874811211,name=Controller Curtis 1266-5201,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('128','2013-12-19 14:28:59','otto','add new part, barcode=113874812661,name=Controller Curtis 1268-5403,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('129','2013-12-19 14:33:01','otto','add new part, barcode=113874813410,name=Tail Light LT - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('130','2013-12-19 14:33:26','otto','add new part, barcode=113874815828,name=Tail Light RT - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('131','2013-12-19 14:34:35','otto','add new part, barcode=113874816080,name=Controller Curtis 1244-5461,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('132','2013-12-19 14:48:58','otto','add new part, barcode=113874816760,name=Converter DC 72V-12V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('133','2013-12-19 14:50:17','otto','edit part, barcode=113874801718,name=Searching Light');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('134','2013-12-19 14:50:38','otto','edit part, barcode=113874802719,name=Rear assembled light - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('135','2013-12-19 14:51:05','otto','edit part, barcode=113874804634,name=Rear assembled light - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('136','2013-12-19 14:51:15','otto','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('137','2013-12-19 14:51:26','otto','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('138','2013-12-19 14:51:40','otto','edit part, barcode=113874807834,name=Converter DC 48V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('139','2013-12-19 14:52:09','otto','edit part, barcode=113874808788,name=Converter DC 36V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('140','2013-12-19 14:52:39','otto','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('141','2013-12-19 14:52:55','otto','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('142','2013-12-19 14:53:07','otto','edit part, barcode=113874811211,name=Controller Curtis 1266-5201');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('143','2013-12-19 14:53:18','otto','edit part, barcode=113874812661,name=Controller Curtis 1268-5403');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('144','2013-12-19 14:53:29','otto','edit part, barcode=113874813410,name=Tail Light LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('145','2013-12-19 15:05:31','otto','add new part, barcode=113874833776,name=Combination Switch - Non Golf Cart,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('146','2013-12-19 15:06:00','otto','edit part, barcode=113861699105,name=Front Axle Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('147','2013-12-19 15:08:29','otto','add new part, barcode=113874835726,name=Speed Meter,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('148','2013-12-19 15:11:28','otto','add new part, barcode=113874837101,name=AC Cable Extension,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('149','2013-12-19 15:12:32','otto','add new part, barcode=113874838896,name=AC Cable ,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('150','2013-12-19 15:12:51','otto','edit part, barcode=113874837101,name=AC Cable Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('151','2013-12-19 15:15:04','otto','add new part, barcode=113874840236,name=Motor 48V 5KW,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('152','2013-12-19 15:15:42','otto','add new part, barcode=113874841056,name=Motor 36V 3kw,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('153','2013-12-19 15:16:13','otto','edit part, barcode=113874841056,name=Motor 36V 3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('154','2013-12-19 15:16:47','otto','add new part, barcode=113874841768,name=Motor 48V 3.8kw,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('155','2013-12-19 15:17:24','otto','add new part, barcode=113874842091,name=Motor 48V 5.3kw,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('156','2013-12-19 15:17:36','otto','edit part, barcode=113874835726,name=Speed Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('157','2013-12-19 15:19:11','otto','add new part, barcode=113874843125,name=Charger - Smart 36V-120V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('158','2013-12-19 15:20:43','otto','add new part, barcode=113874843531,name=Windshield Wiper Motor Assembly,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('159','2013-12-19 15:22:38','otto','add new part, barcode=113874844445,name=Charger - DeltaQ 48V-110,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('160','2013-12-19 15:23:13','otto','add new part, barcode=113874845600,name=Charger - DeltaQ 36V-110,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('161','2013-12-19 15:27:00','otto','add new part, barcode=113874845946,name=Charger - DeltaQ 72V-110V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('162','2013-12-19 15:28:08','otto','edit part, barcode=113874845600,name=Charger - DeltaQ 36V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('163','2013-12-19 15:28:20','otto','edit part, barcode=113874844445,name=Charger - DeltaQ 48V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('164','2013-12-19 15:28:38','otto','edit part, barcode=113874843125,name=Charger - Smart 36V-120V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('165','2013-12-19 15:38:50','otto','add new part, barcode=113874854618,name=Head Light - LH EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('166','2013-12-19 15:39:30','otto','add new part, barcode=113874855314,name=Head Light - RH EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('167','2013-12-19 15:40:18','otto','add new part, barcode=113874855716,name=Front Fog Light - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('168','2013-12-19 15:41:03','otto','add new part, barcode=113874856197,name=Front Turn Signal - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('169','2013-12-19 15:42:20','otto','edit part, barcode=113874856197,name=Light - Front Turn Signal - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('170','2013-12-19 15:42:40','otto','edit part, barcode=113874855716,name= Light - Front Fog - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('171','2013-12-19 15:43:02','otto','edit part, barcode=113874855314,name=Light - Head - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('172','2013-12-19 15:43:23','otto','edit part, barcode=113874854618,name=Light - Head - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('173','2013-12-19 15:44:09','otto','edit part, barcode=113874815828,name=Light - Tail RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('174','2013-12-19 15:44:33','otto','edit part, barcode=113874815828,name=Light - Tail - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('175','2013-12-19 15:45:03','otto','edit part, barcode=113874813410,name=Light - Tail - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('176','2013-12-19 15:45:39','otto','edit part, barcode=113874806896,name=Light - Head - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('177','2013-12-19 15:45:57','otto','edit part, barcode=113874805471,name=Light - Head - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('178','2013-12-19 15:46:31','otto','edit part, barcode=113874804634,name=Light - Rear assembled - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('179','2013-12-19 15:46:51','otto','edit part, barcode=113874802719,name=Light - Rear assembled - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('180','2013-12-19 15:47:30','otto','edit part, barcode=113874801718,name=Light - Searching - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('181','2013-12-19 15:50:09','otto','add new part, barcode=113874862027,name=Light - Rear assembled - LH - Truck,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('182','2013-12-19 15:50:31','otto','add new part, barcode=113874862100,name=Light - Rear assembled - RH - Truck,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('183','2013-12-19 15:52:21','otto','add new part, barcode=113874862955,name=Light - Head - EG2020,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('184','2013-12-19 15:54:11','otto','add new part, barcode=113874863430,name=Battery Cable Jacket - Black,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('185','2013-12-19 15:55:50','otto','add new part, barcode=113874864521,name=Battery Cable Jacket - Red,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('186','2013-12-19 15:56:27','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('187','2013-12-19 16:03:01','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('188','2013-12-19 16:03:33','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('189','2013-12-19 16:04:10','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('190','2013-12-19 16:04:21','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('191','2013-12-19 16:04:24','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('192','2013-12-19 16:06:26','otto','edit part, barcode=113874864521,name=Battery Cable Jacket - Red');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('193','2013-12-19 16:06:49','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('194','2013-12-19 16:20:24','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('195','2013-12-19 16:23:14','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('196','2013-12-19 16:23:22','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('197','2013-12-19 16:25:02','otto','add new part, barcode=113874880273,name=Connect Wire 252Ã—130mm ,amount=40');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('198','2013-12-19 16:25:12','si','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('199','2013-12-19 16:25:16','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('200','2013-12-19 16:32:37','otto','del part, barcode=113861699105,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('201','2013-12-19 16:40:25','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('202','2013-12-19 16:40:30','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('203','2013-12-19 16:40:44','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('204','2013-12-19 16:41:00','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('205','2013-12-19 16:41:03','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('206','2013-12-19 16:41:26','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('207','2013-12-19 16:43:20','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('208','2013-12-19 16:50:08','san','edit car, barcode=013849847336,name=Garbage Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('209','2013-12-19 16:51:16','Boyao','edit part, barcode=113874863430,name=Battery Cable Jacket - Black');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('210','2013-12-19 16:52:21','Boyao','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('211','2013-12-19 16:52:27','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('212','2013-12-19 16:52:35','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('213','2013-12-19 16:53:05','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('214','2013-12-19 16:53:44','Boyao','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('215','2013-12-19 16:54:02','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('216','2013-12-19 16:54:22','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('217','2013-12-20 08:58:01','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('218','2013-12-20 09:04:02','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('219','2013-12-20 09:25:09','otto','edit part, barcode=113874880273,name=Connect Wire 25x130mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('220','2013-12-20 09:26:23','otto','add new part, barcode=113875495207,name=Connect Wire 25x200mm ,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('221','2013-12-20 09:27:34','otto','add new part, barcode=113875495845,name=Connect Wire 25Ã—300mm ,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('222','2013-12-20 09:29:03','otto','add new part, barcode=113875496561,name=Connect Wire 25Ã—440mm ,amount=30');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('223','2013-12-20 09:29:42','otto','edit part, barcode=113875495845,name=Connect Wire 25Ã—300mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('224','2013-12-20 09:33:55','otto','add new part, barcode=113875499828,name=Connect Wire 25Ã—440mm ,amount=40');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('225','2013-12-20 09:36:36','otto','edit part, barcode=113875499828,name=Battery Dead Lever');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('226','2013-12-20 09:37:47','otto','add new part, barcode=113875502090,name=Battery Impact Block,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('227','2013-12-20 09:39:01','otto','add new part, barcode=113875502687,name=Battery Dead Lever - S End,amount=16');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('228','2013-12-20 09:39:31','otto','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('229','2013-12-20 09:39:54','otto','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('230','2013-12-20 09:41:51','otto','add new part, barcode=113875504357,name=Accelerator,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('231','2013-12-20 09:43:35','otto','add new part, barcode=113875505132,name=Main Contactor - 36V 200A,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('232','2013-12-20 09:43:58','otto','edit part, barcode=113875505132,name=Main Contactor - 36V 200A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('233','2013-12-20 09:44:31','otto','add new part, barcode=113875506414,name=Main Contactor - 48V 150A,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('234','2013-12-20 09:44:58','otto','add new part, barcode=113875506733,name=Main Contactor - 48V 300A,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('235','2013-12-20 09:45:50','otto','add new part, barcode=113875506994,name=Main Contactor - 48V 100A FSIP,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('236','2013-12-20 09:47:19','otto','add new part, barcode=113875507516,name=Meter,amount=24');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('237','2013-12-20 09:47:58','otto','add new part, barcode=113875508403,name=Meter Holder,amount=22');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('238','2013-12-20 09:50:32','otto','add new part, barcode=113875508802,name=Meter Wires - Long,amount=16');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('239','2013-12-20 09:51:14','otto','add new part, barcode=113875510340,name=Meter Wires - Short,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('240','2013-12-20 09:51:49','otto','add new part, barcode=113875510757,name=Meter Wires - Extension,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('241','2013-12-20 09:53:44','otto','add new part, barcode=113875511107,name=Battery Impact Block Cap,amount=39');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('242','2013-12-20 09:59:22','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('243','2013-12-20 10:04:41','otto','add new part, barcode=113875517870,name=Side rear view mirror LH,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('244','2013-12-20 10:05:50','otto','add new part, barcode=113875518830,name=Side rear view mirror LH,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('245','2013-12-20 10:11:22','otto','add new part, barcode=113875519554,name=EG6020A4D Battery Cover on Front Body,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('246','2013-12-20 10:15:15','otto','add new part, barcode=113875523072,name=Motor Access,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('247','2013-12-20 10:18:31','otto','add new part, barcode=113875525170,name=Motor Cover - EG6040A4D,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('248','2013-12-20 10:20:42','otto','add new part, barcode=113875527221,name=Split Windshield - Slip block,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('249','2013-12-20 10:21:23','otto','add new part, barcode=113875528431,name=Split Windshield - Clipping block,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('250','2013-12-20 11:18:06','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('251','2013-12-20 11:19:52','otto','add new part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle,amount=44');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('252','2013-12-20 11:22:57','otto','add new part, barcode=113875563935,name=Sash (Clipper),amount=147');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('253','2013-12-20 11:24:26','otto','del part, barcode=113855784845,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('254','2013-12-20 11:26:17','otto','edit part, barcode=113874838896,name=AC Cable ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('255','2013-12-20 11:30:24','otto','edit part, barcode=113874837101,name=AC Cable Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('256','2013-12-20 11:31:13','otto','edit part, barcode=113875504357,name=Accelerator');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('257','2013-12-20 11:32:43','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('258','2013-12-20 11:34:51','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('259','2013-12-20 11:36:35','otto','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('260','2013-12-20 11:37:36','otto','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('261','2013-12-20 11:37:40','otto','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('262','2013-12-20 11:38:04','otto','edit part, barcode=113875502090,name=Battery Impact Block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('263','2013-12-20 11:38:38','otto','edit part, barcode=113875511107,name=Battery Impact Block Cap');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('264','2013-12-20 11:39:33','otto','edit part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('265','2013-12-20 11:45:06','otto','edit part, barcode=113874845600,name=Charger - DeltaQ 36V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('266','2013-12-20 11:45:12','otto','edit part, barcode=113874844445,name=Charger - DeltaQ 48V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('267','2013-12-20 11:45:17','otto','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('268','2013-12-20 11:45:37','otto','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('269','2013-12-20 11:46:41','otto','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('270','2013-12-20 11:48:01','otto','edit part, barcode=113874833776,name=Combination Switch - Non Golf Cart');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('271','2013-12-20 11:52:23','otto','edit part, barcode=113874809185,name=Controller Curtis 1243-4320');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('272','2013-12-20 11:55:50','otto','edit part, barcode=113874816080,name=Controller Curtis 1244-5461');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('273','2013-12-20 11:57:53','otto','edit part, barcode=113874811211,name=Controller Curtis 1266-5201');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('274','2013-12-20 11:58:34','otto','edit part, barcode=113874816760,name=Converter DC 72V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('275','2013-12-20 12:00:48','otto','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('276','2013-12-20 13:06:24','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('277','2013-12-20 13:09:06','otto','add new part, barcode=113875628522,name=Sash (Clipper) - One piece,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('278','2013-12-20 13:09:33','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('279','2013-12-20 13:10:16','san','edit car, barcode=013849847336,name=Garbage Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('280','2013-12-20 13:11:32','san','edit car, barcode=013849848727,name=HOBBIT 2+2 Ambulance');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('281','2013-12-20 13:17:57','san','edit car, barcode=013849857778,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('282','2013-12-20 13:25:38','san','edit part, barcode=113874855716,name=Light - Front Fog - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('283','2013-12-20 13:29:37','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('284','2013-12-20 13:31:14','otto','edit part, barcode=113874862100,name=Light - Rear assembled - RH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('285','2013-12-20 13:31:18','otto','edit part, barcode=113874862027,name=Light - Rear assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('286','2013-12-20 13:31:28','san','edit car, barcode=013849846414,name=QUANTUM Customize');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('287','2013-12-20 13:32:07','otto','edit part, barcode=113874856197,name=Light - Front Turn Signal - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('288','2013-12-20 13:32:12','otto','edit part, barcode=113874855716,name=Light - Front Fog - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('289','2013-12-20 13:32:34','san','edit car, barcode=013849854684,name=QUANTUM Customize');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('290','2013-12-20 13:32:38','otto','edit part, barcode=113874855314,name=Light - Head - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('291','2013-12-20 13:32:43','otto','edit part, barcode=113874854618,name=Light - Head - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('292','2013-12-20 13:33:42','san','edit car, barcode=013849843167,name=KERNEL');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('293','2013-12-20 13:34:51','san','edit car, barcode=013849845400,name=Motorcycle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('294','2013-12-20 13:35:16','san','edit car, barcode=013849845400,name=Motorcycle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('295','2013-12-20 13:35:52','otto','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('296','2013-12-20 13:35:56','san','edit car, barcode=013849844238,name=HOBBIT 4+2 Customize');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('297','2013-12-20 13:36:37','san','edit car, barcode=013849848035,name=ARGO 14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('298','2013-12-20 13:37:07','san','edit car, barcode=013849848309,name=ARGO 14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('299','2013-12-20 13:37:08','otto','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('300','2013-12-20 13:38:18','san','edit car, barcode=013849850219,name=HOBBIT 6+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('301','2013-12-20 13:38:37','otto','edit part, barcode=113874801718,name=Light - Searching - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('302','2013-12-20 13:39:03','san','edit car, barcode=013849849042,name=HOBBIT 6+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('303','2013-12-20 13:39:29','otto','edit part, barcode=113874813410,name=Light - Tail - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('304','2013-12-20 13:39:35','otto','edit part, barcode=113874815828,name=Light - Tail - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('305','2013-12-20 13:40:03','san','edit car, barcode=013849859041,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('306','2013-12-20 13:40:12','otto','edit part, barcode=113875507516,name=Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('307','2013-12-20 13:40:16','otto','edit part, barcode=113875508403,name=Meter Holder');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('308','2013-12-20 13:40:48','san','edit car, barcode=013849858782,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('309','2013-12-20 13:40:51','otto','edit part, barcode=113875510757,name=Meter Wires - Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('310','2013-12-20 13:40:55','otto','edit part, barcode=113875508802,name=Meter Wires - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('311','2013-12-20 13:40:57','otto','edit part, barcode=113875510340,name=Meter Wires - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('312','2013-12-20 13:41:23','otto','edit part, barcode=113874841056,name=Motor 36V 3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('313','2013-12-20 13:41:28','otto','edit part, barcode=113874841768,name=Motor 48V 3.8kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('314','2013-12-20 13:41:32','otto','edit part, barcode=113874842091,name=Motor 48V 5.3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('315','2013-12-20 13:41:42','san','edit car, barcode=013849851341,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('316','2013-12-20 13:42:30','otto','edit part, barcode=113875523072,name=Motor Access EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('317','2013-12-20 13:42:33','san','edit car, barcode=013849851104,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('318','2013-12-20 13:43:34','san','edit car, barcode=013849854322,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('319','2013-12-20 13:44:06','otto','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('320','2013-12-20 13:44:44','san','edit car, barcode=013849853196,name=CRICKET 2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('321','2013-12-20 13:45:54','san','edit car, barcode=013849855695,name=CRICKET 2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('322','2013-12-20 13:46:46','san','edit car, barcode=013849853756,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('323','2013-12-20 13:47:09','otto','edit part, barcode=113874665250,name=Rear Bracket - 2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('324','2013-12-20 13:47:24','otto','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('325','2013-12-20 13:47:27','san','edit car, barcode=013849843596,name=HULK');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('326','2013-12-20 13:47:55','otto','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('327','2013-12-20 13:48:22','san','edit car, barcode=013849856001,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('328','2013-12-20 13:49:09','san','edit car, barcode=013849858260,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('329','2013-12-20 13:49:14','otto','edit part, barcode=113875563935,name=Sash (Clipper)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('330','2013-12-20 13:49:51','san','edit car, barcode=013849856577,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('331','2013-12-20 13:52:15','san','edit car, barcode=013849859323,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('332','2013-12-20 13:52:33','otto','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('333','2013-12-20 13:52:56','san','edit car, barcode=013849857340,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('334','2013-12-20 13:53:02','otto','edit part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('335','2013-12-20 13:53:26','san','edit car, barcode=013849857969,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('336','2013-12-20 13:53:58','san','edit car, barcode=013849858479,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('337','2013-12-20 13:54:27','san','edit car, barcode=013849857035,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('338','2013-12-20 13:54:52','otto','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('339','2013-12-20 13:55:18','san','edit car, barcode=013849852101,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('340','2013-12-20 13:56:02','san','edit car, barcode=013849856801,name=NUCLEUS');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('341','2013-12-20 13:56:30','otto','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('342','2013-12-20 13:58:07','otto','edit part, barcode=113875517870,name=Side rear view mirror LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('343','2013-12-20 13:58:12','otto','edit part, barcode=113875518830,name=Side rear view mirror LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('344','2013-12-20 13:58:50','otto','edit part, barcode=113874835726,name=Speed Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('345','2013-12-20 13:59:58','otto','edit part, barcode=113875527221,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('346','2013-12-20 14:00:21','otto','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('347','2013-12-20 14:00:57','otto','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('348','2013-12-20 14:01:23','otto','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('349','2013-12-20 14:02:01','otto','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('350','2013-12-20 14:02:11','otto','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('351','2013-12-20 14:02:51','otto','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('352','2013-12-20 14:03:14','otto','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('353','2013-12-20 14:03:19','otto','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('354','2013-12-20 14:03:25','otto','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('355','2013-12-20 14:39:20','otto','add new part, barcode=113875682157,name=Canopy Handle - 2028,amount=36');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('356','2013-12-20 14:41:38','otto','add new part, barcode=113875683616,name=Side Rear View Mirror Bass - L,amount=120');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('357','2013-12-20 14:42:01','otto','add new part, barcode=113875684999,name=Side Rear View Mirror Bass - R,amount=120');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('358','2013-12-20 14:44:39','otto','add new part, barcode=113875685230,name=Jacket For Caddie Handle,amount=150');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('359','2013-12-20 14:46:14','otto','add new part, barcode=113875686804,name=Dustproof cover,amount=58');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('360','2013-12-20 14:48:12','otto','add new part, barcode=113875687755,name=Floor Mat - Short,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('361','2013-12-20 14:48:36','otto','add new part, barcode=113875688937,name=Floor Mat - Long,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('362','2013-12-20 14:56:09','otto','add new part, barcode=113875689178,name=Enclosure for EG6118,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('363','2013-12-20 15:00:23','otto','add new part, barcode=113875693714,name=Underseat Compartment,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('364','2013-12-20 15:01:53','otto','add new part, barcode=113875696246,name=Back Rest Cover - Plastic ,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('365','2013-12-20 15:12:54','otto','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('366','2013-12-20 15:13:58','otto','add new part, barcode=113875703804,name=Canopy Handle - 2028,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('367','2013-12-20 15:14:29','otto','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('368','2013-12-20 15:17:07','otto','add new part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('369','2013-12-20 15:18:37','otto','add new part, barcode=113875706287,name=Arm Rest - Paired,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('370','2013-12-20 15:22:35','otto','add new part, barcode=113875707186,name=Sweater Basket Frame,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('371','2013-12-20 15:25:02','otto','add new part, barcode=113875709563,name=Seat Back Sub-bracket,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('372','2013-12-20 15:36:04','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('373','2013-12-20 15:38:09','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('374','2013-12-20 15:38:12','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('375','2013-12-20 15:57:29','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('376','2013-12-20 16:02:05','otto','add new part, barcode=113875732227,name=Caddie Handle (Old Model),amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('377','2013-12-20 16:03:25','otto','add new part, barcode=113875733270,name=Caddie Handle - 35\" (Old Model),amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('378','2013-12-20 16:04:38','otto','add new part, barcode=113875734063,name=Caddie Handle - 39\",amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('379','2013-12-20 16:05:27','otto','add new part, barcode=113875734794,name=Caddie Handle - 33\",amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('380','2013-12-20 16:06:21','otto','add new part, barcode=113875735287,name=Caddie Handle - 38.5\",amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('381','2013-12-20 16:06:51','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5\" (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('382','2013-12-20 16:07:05','otto','edit part, barcode=113875733270,name=Caddie Handle - 35');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('383','2013-12-20 16:07:32','otto','edit part, barcode=113875734063,name=Caddie Handle - 39');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('384','2013-12-20 16:07:59','otto','edit part, barcode=113875734794,name=Caddie Handle - 33\"');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('385','2013-12-20 16:08:43','otto','edit part, barcode=113875735287,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('386','2013-12-20 16:08:54','otto','edit part, barcode=113875734794,name=Caddie Handle - 33 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('387','2013-12-20 16:09:05','otto','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('388','2013-12-20 16:09:37','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('389','2013-12-20 16:10:12','otto','edit part, barcode=113875733270,name=Caddie Handle - 35 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('390','2013-12-20 16:10:38','otto','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('391','2013-12-20 16:11:13','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('392','2013-12-20 16:13:39','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('393','2013-12-20 16:15:17','otto','add new part, barcode=113875740798,name=Tie Rod,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('394','2013-12-20 16:16:29','otto','add new part, barcode=113875741190,name=Steering Shaft Bushing,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('395','2013-12-20 16:18:02','otto','add new part, barcode=113875741899,name=Hubcap,amount=60');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('396','2013-12-20 16:19:16','otto','add new part, barcode=113875742842,name=Hubcap - Plastic,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('397','2013-12-20 16:19:37','otto','edit part, barcode=113875741899,name=Hubcap - Aluminum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('398','2013-12-20 16:21:22','otto','add new part, barcode=113875744437,name=Enclosure - EG2028KSZ,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('399','2013-12-20 16:22:27','otto','add new part, barcode=113875744839,name=Enclosure - EG6158,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('400','2013-12-20 16:23:52','otto','add new part, barcode=113875745490,name=Enclosure - EG2048K,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('401','2013-12-20 16:24:41','otto','add new part, barcode=113875746339,name=Enclosure - EG6043,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('402','2013-12-20 16:30:21','otto','add new part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired),amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('403','2013-12-20 16:31:06','otto','add new part, barcode=113875750225,name=Front Wheel Trim - Fender Flare (Paired),amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('404','2013-12-20 16:31:19','otto','edit part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('405','2013-12-20 16:34:06','otto','add new part, barcode=113875752178,name=Braking Cable Assembly,amount=19');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('406','2013-12-20 16:36:04','otto','add new part, barcode=113875752475,name=Windshield Wiper,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('407','2013-12-20 16:37:45','otto','add new part, barcode=113875753656,name=Windshield Wiper - EG6118 (Paired),amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('408','2013-12-20 16:38:02','otto','edit part, barcode=113875752475,name=Windshield Wiper - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('409','2013-12-20 16:40:58','otto','add new part, barcode=113875756083,name=Thin Copper Sheath - Thin,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('410','2013-12-20 16:41:42','otto','add new part, barcode=113875756594,name=Copper Sheath - Thick,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('411','2013-12-20 16:41:54','otto','edit part, barcode=113875756083,name=Copper Sheath - Thin');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('412','2013-12-20 16:43:01','otto','add new part, barcode=113875757195,name=Bearing Assembly,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('413','2013-12-20 16:44:04','otto','add new part, barcode=113875757827,name=Bearing 6206-Z,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('414','2013-12-20 16:45:21','otto','add new part, barcode=113875758458,name=Redirector Assembly,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('415','2013-12-20 16:55:36','otto','add new part, barcode=113875764620,name=Wheel Nut - Aluminum Rim,amount=500');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('416','2013-12-20 17:01:20','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('417','2013-12-20 17:04:02','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('418','2013-12-23 09:17:12','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('419','2013-12-23 09:23:59','otto','add new part, barcode=113878082911,name=Seat Belt Set - 2 point,amount=15');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('420','2013-12-23 09:24:47','otto','add new part, barcode=113878086410,name=Seat Belt Set - 3 point,amount=15');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('421','2013-12-23 09:28:18','otto','add new part, barcode=113878088327,name=Front Axle Assembly,amount=11');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('422','2013-12-23 09:30:48','otto','add new part, barcode=113878088998,name=Front Axle Assembly - Semi,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('423','2013-12-23 09:31:36','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('424','2013-12-23 09:35:51','otto','edit part, barcode=113878088327,name=Front Axle Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('425','2013-12-23 09:37:18','otto','add new part, barcode=113878093952,name=Rear Brake assembly RH,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('426','2013-12-23 09:40:48','otto','add new part, barcode=113878094409,name=Rear Brake assembly LH,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('427','2013-12-23 09:40:57','otto','edit part, barcode=113878093952,name=Rear Brake assembly RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('428','2013-12-23 09:42:16','otto','add new part, barcode=113878096654,name=Brake Shoe,amount=46');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('429','2013-12-23 09:46:36','otto','add new part, barcode=113878098067,name=Brake Shoe - Unidentified,amount=48');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('430','2013-12-23 09:48:33','otto','add new part, barcode=113878099978,name=Front Axle Assembly - EG2028,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('431','2013-12-23 09:49:02','otto','edit part, barcode=113878099978,name=Front Axle Assembly - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('432','2013-12-23 09:49:50','otto','edit part, barcode=113878088327,name=Front Axle Assembly - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('433','2013-12-23 09:52:29','otto','add new part, barcode=113878103106,name=Rear Axle Assembly ,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('434','2013-12-23 09:53:51','otto','add new part, barcode=113878103505,name=Rear Bumper - EG2020/ EG2028,amount=13');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('435','2013-12-23 09:54:51','otto','add new part, barcode=113878104320,name=Motor Access - EG2028/ EG2020,amount=48');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('436','2013-12-23 09:56:56','otto','add new part, barcode=113878104955,name=Fender scuffguard - Paired,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('437','2013-12-23 09:57:37','otto','add new part, barcode=113878106177,name=Front Bumper - EG2028,amount=9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('438','2013-12-23 09:59:31','otto','add new part, barcode=113878106590,name=Front Bumper - EG2020 - Plastic,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('439','2013-12-23 10:01:27','otto','add new part, barcode=113878107737,name=Front Shock Absorber Assembly - EG2020,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('440','2013-12-23 10:02:29','otto','add new part, barcode=113878109179,name=Front Shock Absorber Assembly - EG2028,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('441','2013-12-23 10:03:19','otto','add new part, barcode=113878109505,name=Front Shock Absorber Assembly - Unidentified,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('442','2013-12-23 10:07:30','otto','add new part, barcode=113878110008,name=Left Knuckle,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('443','2013-12-23 10:08:12','otto','add new part, barcode=113878112510,name=Right Knuckle,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('444','2013-12-23 10:08:59','otto','add new part, barcode=113878112939,name=Watering System,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('445','2013-12-23 10:10:43','otto','add new part, barcode=113878113414,name=Front Leaf Spring Assembly,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('446','2013-12-23 10:12:18','otto','add new part, barcode=113878114441,name=Rear Leaf Spring Assembly,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('447','2013-12-23 10:12:56','otto','add new part, barcode=113878115393,name=Seat Belt Set - 3 point (Large),amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('448','2013-12-23 10:13:12','otto','edit part, barcode=113878115393,name=Seat Belt Set - 3 point (Large)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('449','2013-12-23 10:18:12','otto','add new part, barcode=113878118605,name=Tie Rod Joint,amount=33');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('450','2013-12-23 10:19:06','otto','add new part, barcode=113878118930,name=Rear Brake Drum,amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('451','2013-12-23 10:19:20','otto','edit part, barcode=113878118930,name=Rear Brake Drum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('452','2013-12-23 10:21:36','otto','add new part, barcode=113878120248,name=Top Canopy Bracket - EG2028KSF/ EG2028KSZ,amount=30');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('453','2013-12-23 10:23:12','otto','add new part, barcode=113878120972,name=Front Bracket - Normal,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('454','2013-12-23 10:25:20','otto','add new part, barcode=113878122294,name=Top Canopy Bracket - EG2048KSF/ 2048KSZ,amount=13');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('455','2013-12-23 10:26:22','otto','add new part, barcode=113878123216,name=Top Canopy Bracket - EG2068KSZ,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('456','2013-12-23 10:28:22','otto','add new part, barcode=113878123902,name=Front Bracket - EG2020ASZ,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('457','2013-12-23 10:28:42','otto','edit part, barcode=113878123216,name=Top Canopy Bracket - EG2068KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('458','2013-12-23 10:28:56','otto','edit part, barcode=113878122294,name=Top Canopy Bracket - EG2048KSF/ 2048KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('459','2013-12-23 10:29:27','otto','edit part, barcode=113878120972,name=Front Bracket - Normal');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('460','2013-12-23 10:29:33','otto','edit part, barcode=113878120248,name=Top Canopy Bracket - EG2028KSF/ EG2028KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('461','2013-12-23 10:42:10','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('462','2013-12-23 10:56:34','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('463','2013-12-23 10:58:52','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('464','2013-12-23 11:00:27','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('465','2013-12-23 11:01:07','otto','edit car, barcode=013849843596,name=HULK');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('466','2013-12-23 11:58:08','otto','add new car, barcode=013878178357,name=HOBBIT 2HCX,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('467','2013-12-23 11:58:52','otto','add new car, barcode=013878179093,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('468','2013-12-23 11:59:10','otto','edit car, barcode=013878178357,name=HOBBIT 2HCX');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('469','2013-12-23 11:59:46','otto','add new car, barcode=013878179678,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('470','2013-12-23 12:02:43','otto','add new car, barcode=013878181388,name=HOBBIT 2HCX,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('471','2013-12-23 12:05:34','otto','add new car, barcode=013878183182,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('472','2013-12-23 12:05:45','otto','edit car, barcode=013878183182,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('473','2013-12-23 13:43:18','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('474','2013-12-23 13:49:07','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('475','2013-12-23 13:55:35','otto','add new car, barcode=013878248948,name=HOBBIT 4+H,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('476','2013-12-23 13:57:13','otto','add new car, barcode=013878250105,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('477','2013-12-23 13:57:44','otto','add new car, barcode=013878250462,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('478','2013-12-23 13:57:58','otto','edit car, barcode=013878250105,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('479','2013-12-23 14:00:42','otto','add new car, barcode=013878252345,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('480','2013-12-23 14:01:09','otto','edit car, barcode=013878252345,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('481','2013-12-23 14:01:59','otto','add new car, barcode=013878252919,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('482','2013-12-23 14:03:27','otto','add new car, barcode=013878253878,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('483','2013-12-23 14:04:13','otto','add new car, barcode=013878254236,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('484','2013-12-23 14:05:35','otto','add new car, barcode=013878255184,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('485','2013-12-23 14:06:16','otto','add new car, barcode=013878255554,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('486','2013-12-23 14:11:19','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('487','2013-12-23 14:11:39','san','edit car, barcode=013878179678,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('488','2013-12-23 14:11:45','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('489','2013-12-23 14:11:51','san','edit car, barcode=013878179093,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('490','2013-12-23 14:11:57','Boyao','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('491','2013-12-23 14:12:08','san','edit car, barcode=013849859659,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('492','2013-12-23 14:12:24','san','edit car, barcode=013849859041,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('493','2013-12-23 14:13:00','san','edit car, barcode=013849858782,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('494','2013-12-23 14:14:39','san','edit car, barcode=013849852101,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('495','2013-12-23 14:14:50','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('496','2013-12-23 14:14:59','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('497','2013-12-23 14:15:25','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('498','2013-12-23 14:16:42','otto','add new car, barcode=013878261696,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('499','2013-12-23 14:16:52','otto','edit car, barcode=013878261696,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('500','2013-12-23 14:17:36','otto','edit car, barcode=013878261696,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('501','2013-12-23 14:18:16','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('502','2013-12-23 14:18:40','otto','add new part, barcode=113878261008,name=Shunt,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('503','2013-12-23 14:20:38','otto','add new part, barcode=113878263216,name=Main Fuse - 425A,amount=29');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('504','2013-12-23 14:22:15','otto','add new part, barcode=113878264399,name=Controller Fuse,amount=88');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('505','2013-12-23 14:23:06','otto','add new part, barcode=113878265368,name=Attach Fuse socket,amount=30');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('506','2013-12-23 14:24:00','otto','add new part, barcode=113878265874,name=Battery Protector,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('507','2013-12-23 14:29:01','otto','add new car, barcode=013878269189,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('508','2013-12-23 14:29:20','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('509','2013-12-23 14:29:23','otto','add new part, barcode=113878266414,name=Reverse Buzzer,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('510','2013-12-23 14:29:37','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('511','2013-12-23 14:29:39','otto','add new car, barcode=013878269640,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('512','2013-12-23 14:30:01','otto','add new car, barcode=013878269848,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('513','2013-12-23 14:30:26','otto','add new car, barcode=013878270074,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('514','2013-12-23 14:30:37','otto','add new part, barcode=113878269647,name=Reverse Buzzer - Golf,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('515','2013-12-23 14:30:41','otto','edit car, barcode=013878269640,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('516','2013-12-23 14:31:03','otto','edit part, barcode=113878266414,name=Reverse Buzzer - Truck/ Bus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('517','2013-12-23 14:32:07','otto','add new part, barcode=113878270780,name=Fuse Box - Golf,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('518','2013-12-23 14:32:11','otto','add new car, barcode=013878271054,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('519','2013-12-23 14:33:37','otto','add new part, barcode=113878271280,name=Electric Horn - Golf,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('520','2013-12-23 14:33:52','otto','add new car, barcode=013878272167,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('521','2013-12-23 14:34:10','otto','edit car, barcode=013878272167,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('522','2013-12-23 14:34:37','otto','add new part, barcode=113878272184,name=Time-lapse Relay - Golf,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('523','2013-12-23 14:34:49','otto','add new car, barcode=013878272679,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('524','2013-12-23 14:35:17','otto','add new car, barcode=013878273016,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('525','2013-12-23 14:36:12','otto','add new car, barcode=013878273573,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('526','2013-12-23 14:36:26','otto','add new part, barcode=113878272791,name=Electronic Flasher,amount=11');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('527','2013-12-23 14:36:38','otto','add new car, barcode=013878273839,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('528','2013-12-23 14:37:14','otto','add new car, barcode=013878274028,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('529','2013-12-23 14:37:41','otto','add new part, barcode=113878273877,name=Auxiliary relay - 48V,amount=12');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('530','2013-12-23 14:37:51','otto','add new car, barcode=013878274540,name=HOBBIT 6+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('531','2013-12-23 14:38:20','otto','add new car, barcode=013878274827,name=HOBBIT 6+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('532','2013-12-23 14:38:56','otto','add new part, barcode=113878274626,name=Main Fuse - 250A,amount=25');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('533','2013-12-23 14:39:28','otto','add new car, barcode=013878275466,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('534','2013-12-23 14:39:51','otto','add new part, barcode=113878275369,name=Tow/Run Switch,amount=17');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('535','2013-12-23 14:39:53','otto','add new car, barcode=013878275778,name=HOBBIT 6+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('536','2013-12-23 14:41:33','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('537','2013-12-23 14:41:37','otto','add new part, barcode=113878275921,name=Brake Light Switch,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('538','2013-12-23 14:42:40','otto','add new part, barcode=113878276989,name=Universal Start Key,amount=25');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('539','2013-12-23 14:43:38','otto','add new part, barcode=113878277615,name=F/R Switch,amount=19');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('540','2013-12-23 14:44:30','otto','add new part, barcode=113878278199,name=Power Meter - 36V,amount=15');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('541','2013-12-23 14:45:15','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('542','2013-12-23 14:45:16','otto','add new part, barcode=113878278718,name=Power Meter - 48V,amount=12');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('543','2013-12-23 14:46:41','otto','add new part, barcode=113878279170,name=Speed Sensor,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('544','2013-12-23 14:48:05','otto','add new part, barcode=113878280024,name=Carbon Brush - Chinese Motor,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('545','2013-12-23 14:48:36','otto','add new part, barcode=113878280863,name=Carbon brush - ADC motor,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('546','2013-12-23 14:49:31','otto','add new part, barcode=113878281176,name=Speed sensor - ADC motor,amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('547','2013-12-23 14:49:51','otto','edit part, barcode=113878281176,name=Speed sensor - ADC motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('548','2013-12-23 14:50:57','otto','add new part, barcode=113878282207,name=Head Light Bulb - EG2028,amount=21');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('549','2013-12-23 14:51:45','otto','add new part, barcode=113878282586,name=Turn Light Bulb - EG2028,amount=21');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('550','2013-12-23 14:53:10','otto','add new part, barcode=113878283060,name=LED light Wire - On board,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('551','2013-12-23 14:54:30','otto','add new part, barcode=113878283910,name=Turn light bulb - EG2020,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('552','2013-12-23 14:56:02','otto','add new part, barcode=113878284719,name=Rear Light Bulb - Golf,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('553','2013-12-23 14:57:19','otto','add new part, barcode=113878285629,name=Reflector,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('554','2013-12-23 14:58:34','otto','add new part, barcode=113878286445,name=Hi-Low Switch,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('555','2013-12-23 15:08:21','otto','add new car, barcode=013878292620,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('556','2013-12-23 15:12:53','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('557','2013-12-23 15:16:02','otto','edit car, barcode=013878292620,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('558','2013-12-23 15:18:10','otto','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('559','2013-12-23 15:18:11','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('560','2013-12-23 15:18:32','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('561','2013-12-23 15:21:04','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('562','2013-12-23 15:21:07','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('563','2013-12-23 15:21:09','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('564','2013-12-23 15:21:37','Boyao-Wang','edit part, barcode=113874660495,name=Inner Rearview Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('565','2013-12-23 15:25:00','Boyao-Wang','edit part, barcode=113874660495,name=Inner Rearview Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('566','2013-12-23 15:27:38','Boyao-Wang','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('567','2013-12-23 15:33:21','Boyao-Wang','edit part, barcode=113874657396,name=Front Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('568','2013-12-23 15:34:46','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('569','2013-12-23 15:36:28','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('570','2013-12-23 15:39:13','Boyao-Wang','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('571','2013-12-23 15:41:17','otto','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('572','2013-12-23 15:42:53','otto','edit part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('573','2013-12-23 15:43:31','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('574','2013-12-23 15:43:40','OTTO','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('575','2013-12-23 15:43:43','OTTO','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('576','2013-12-23 15:43:55','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('577','2013-12-23 15:43:57','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('578','2013-12-23 15:44:06','otto','edit part, barcode=113874676203,name=Rear Bracket - Undefined');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('579','2013-12-23 15:46:09','otto','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('580','2013-12-23 15:46:41','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('581','2013-12-23 15:47:31','otto','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('582','2013-12-23 15:48:29','otto','edit part, barcode=113874665250,name=Rear Bracket - 2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('583','2013-12-23 15:49:51','otto','edit part, barcode=113874667209,name=Front Basket Bracket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('584','2013-12-23 15:51:59','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('585','2013-12-23 15:53:21','otto','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('586','2013-12-23 15:54:43','otto','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('587','2013-12-23 15:55:28','otto','add new part, barcode=113878320669,name=Side Rear View Mirror - RH,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('588','2013-12-23 15:55:59','otto','add new part, barcode=113878321298,name=Side Rear View Mirror - RH,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('589','2013-12-23 15:56:07','otto','edit part, barcode=113874701375,name=Searching Light Bracket 1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('590','2013-12-23 15:57:22','otto','edit part, barcode=113874689510,name=Side Armrest');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('591','2013-12-23 15:58:36','otto','edit part, barcode=113875518830,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('592','2013-12-23 15:58:58','otto','edit part, barcode=113875517870,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('593','2013-12-23 15:59:30','otto','edit part, barcode=113874688608,name=Cargo Box Support Bracket - 2048HCX');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('594','2013-12-23 16:13:49','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('595','2013-12-23 16:14:15','otto','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('596','2013-12-23 16:14:17','otto','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('597','2013-12-23 16:15:15','otto','edit part, barcode=113875523072,name=Motor Access EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('598','2013-12-23 16:16:34','otto','edit part, barcode=113875519554,name=EG6020A4D Battery Cover on Front Body');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('599','2013-12-23 16:19:43','otto','edit part, barcode=113875517870,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('600','2013-12-23 16:20:22','otto','edit part, barcode=113875518830,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('601','2013-12-23 16:23:46','otto','edit part, barcode=113878320669,name=Side Rear View Mirror - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('602','2013-12-23 16:27:53','otto','edit part, barcode=113878321298,name=Side Rear View Mirror - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('603','2013-12-23 16:31:05','otto','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('604','2013-12-23 16:32:26','otto','edit part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('605','2013-12-23 16:34:25','otto','edit part, barcode=113875703804,name=Canopy Handle - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('606','2013-12-23 16:43:13','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('607','2013-12-23 16:58:15','otto','edit part, barcode=113875707186,name=Sweater Basket Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('608','2013-12-23 16:58:17','otto','edit part, barcode=113875707186,name=Sweater Basket Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('609','2013-12-23 16:59:20','otto','edit part, barcode=113875628522,name=Sash (Clipper) - One piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('610','2013-12-23 17:00:10','otto','edit part, barcode=113875563935,name=Sash (Clipper)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('611','2013-12-23 18:13:56','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('612','2013-12-23 18:14:53','otto','edit part, barcode=113874815828,name=Tail Light - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('613','2013-12-23 18:15:43','otto','edit part, barcode=113874813410,name=Tail Light - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('614','2013-12-23 18:16:22','otto','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('615','2013-12-23 18:17:34','otto','edit part, barcode=113874802719,name=Tail Light Assembled - LT - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('616','2013-12-23 18:18:21','otto','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('617','2013-12-23 18:19:14','otto','edit part, barcode=113874804634,name=Tail Light Assembled - RH - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('618','2013-12-23 18:20:15','otto','edit part, barcode=113874801718,name=Searching Light - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('619','2013-12-23 18:21:25','otto','edit part, barcode=113874862955,name=Head Light - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('620','2013-12-23 18:22:01','otto','edit part, barcode=113874862100,name=Tail Light Assembled - RH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('621','2013-12-23 18:22:13','otto','edit part, barcode=113874862027,name=Tail Light Assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('622','2013-12-23 18:22:34','otto','edit part, barcode=113874856197,name=Front Turn Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('623','2013-12-23 18:22:49','otto','edit part, barcode=113874855314,name=Head Light - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('624','2013-12-23 18:23:02','otto','edit part, barcode=113874855716,name=Front Fog Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('625','2013-12-23 18:23:13','otto','edit part, barcode=113874854618,name=Head Light - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('626','2013-12-23 18:33:14','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('627','2013-12-23 20:16:31','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('628','2013-12-24 09:11:33','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('629','2013-12-24 09:57:21','otto','add new part, barcode=113878969596,name=Oil Seal 32*47*8,amount=40');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('630','2013-12-24 10:00:11','otto','add new part, barcode=113878970448,name=Oil Seal 50.3/43.1/9,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('631','2013-12-24 10:01:11','otto','add new part, barcode=113878972137,name=Oil Seal 42/55/7,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('632','2013-12-24 10:02:25','otto','edit part, barcode=113878972137,name=Oil Seal 42/55/7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('633','2013-12-24 10:02:57','otto','edit part, barcode=113878970448,name=Oil Seal 50.3/43.1/9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('634','2013-12-24 10:05:18','otto','edit part, barcode=113878969596,name=Oil Seal 32*47*8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('635','2013-12-24 10:06:03','otto','edit part, barcode=113878969596,name=Oil Seal 32/47/8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('636','2013-12-24 10:20:41','otto','add new part, barcode=113878983894,name=Wheel 21x11-10 CST/ Aluminum Rim F - Damaged,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('637','2013-12-24 10:22:15','otto','edit part, barcode=113878103106,name=Rear Axle Assembly ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('638','2013-12-24 10:31:00','otto','add new part, barcode=113878990073,name=Tyre valve,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('639','2013-12-24 10:32:09','otto','add new part, barcode=113878990619,name=Shackle plate,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('640','2013-12-24 10:33:49','otto','add new part, barcode=113878991309,name=Flip-Flop Seat Rubber Pad,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('641','2013-12-24 10:34:52','otto','add new part, barcode=113878992304,name=Holding Block - Widshield,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('642','2013-12-24 10:43:44','otto','add new part, barcode=113878997974,name=Steering Wheel Cover,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('643','2013-12-24 10:44:28','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('644','2013-12-24 10:54:21','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('645','2013-12-24 10:55:21','otto','add new part, barcode=113879004663,name=Battery - US 2200,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('646','2013-12-24 10:55:48','otto','add new part, barcode=113879005228,name=Battery - Trojan T875,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('647','2013-12-24 10:56:36','otto','add new part, barcode=113879005492,name=Battery - Trojan T105,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('648','2013-12-24 13:42:42','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('649','2013-12-30 14:59:02','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('650','2013-12-30 15:09:52','otto ','edit part, barcode=113878261008,name=Shunt');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('651','2013-12-30 15:16:03','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('652','2013-12-30 15:16:38','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('653','2013-12-30 15:17:43','otto ','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('654','2013-12-30 15:22:25','otto ','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('655','2013-12-30 15:24:42','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('656','2013-12-30 15:25:31','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('657','2013-12-30 15:26:25','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('658','2013-12-30 15:26:57','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('659','2013-12-30 15:30:12','otto ','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('660','2013-12-30 15:37:28','otto ','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('661','2013-12-30 15:38:09','otto ','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('662','2013-12-30 15:44:10','otto ','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('663','2013-12-30 15:45:52','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('664','2013-12-30 15:46:43','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('665','2013-12-30 15:48:04','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('666','2013-12-30 15:48:58','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('667','2013-12-30 15:51:16','otto ','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('668','2013-12-30 15:53:07','otto ','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('669','2013-12-30 15:55:33','otto ','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('670','2013-12-30 16:11:29','otto ','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('671','2013-12-30 16:12:02','otto ','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('672','2013-12-30 16:20:04','otto ','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('673','2013-12-30 16:29:14','otto ','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('674','2013-12-30 16:31:27','otto ','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('675','2013-12-30 16:33:37','otto ','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('676','2014-01-02 09:12:37','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('677','2014-01-02 09:42:17','otto','edit part, barcode=113878992304,name=Holding Block - Widshield');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('678','2014-01-02 09:43:10','otto','edit part, barcode=113878990073,name=Tyre valve');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('679','2014-01-02 09:43:18','otto','edit part, barcode=113878970448,name=Oil Seal 50.3/43.1/9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('680','2014-01-02 09:43:25','otto','edit part, barcode=113878280024,name=Carbon Brush - Chinese Motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('681','2014-01-02 09:43:33','otto','edit part, barcode=113878279170,name=Speed Sensor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('682','2014-01-02 09:43:43','otto','edit part, barcode=113878278199,name=Power Meter - 36V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('683','2014-01-02 09:43:50','otto','edit part, barcode=113878274626,name=Main Fuse - 250A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('684','2014-01-02 09:43:55','otto','edit part, barcode=113878272184,name=Time-lapse Relay - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('685','2014-01-02 09:44:00','otto','edit part, barcode=113878271280,name=Electric Horn - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('686','2014-01-02 09:44:24','otto','edit part, barcode=113879005228,name=Battery - Trojan T875');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('687','2014-01-02 09:44:31','otto','edit part, barcode=113879004663,name=Battery - US 2200');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('688','2014-01-02 09:44:36','otto','edit part, barcode=113879005492,name=Battery - Trojan T105');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('689','2014-01-02 09:45:26','otto','edit part, barcode=113878106590,name=Front Bumper - EG2020 - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('690','2014-01-02 09:45:34','otto','edit part, barcode=113875753656,name=Windshield Wiper - EG6118 (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('691','2014-01-02 09:45:40','otto','edit part, barcode=113875752475,name=Windshield Wiper - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('692','2014-01-02 09:45:47','otto','edit part, barcode=113875746339,name=Enclosure - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('693','2014-01-02 09:46:11','otto','edit part, barcode=113875745490,name=Enclosure - EG2048K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('694','2014-01-02 09:46:16','otto','edit part, barcode=113875740798,name=Tie Rod');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('695','2014-01-02 09:46:20','otto','edit part, barcode=113875687755,name=Floor Mat - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('696','2014-01-02 09:46:37','otto','edit part, barcode=113875527221,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('697','2014-01-02 09:46:50','otto','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('698','2014-01-02 09:47:34','otto','edit part, barcode=113874862027,name=Tail Light Assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('699','2014-01-02 09:47:45','otto','edit part, barcode=113874807834,name=Converter DC 48V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('700','2014-01-02 09:47:54','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('701','2014-01-02 09:48:00','otto','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('702','2014-01-02 09:48:14','otto','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('703','2014-01-02 09:48:21','otto','edit part, barcode=113860008361,name=Central Cover - camouflage - used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('704','2014-01-02 09:48:26','otto','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('705','2014-01-02 09:51:59','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('706','2014-01-02 10:41:43','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('707','2014-01-02 11:13:54','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('708','2014-01-02 11:15:43','otto ','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('709','2014-01-02 11:35:22','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('710','2014-01-02 11:35:56','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('711','2014-01-02 11:36:41','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('712','2014-01-02 11:38:07','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('713','2014-01-02 11:39:13','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('714','2014-01-02 11:40:04','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('715','2014-01-02 11:50:37','otto','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('716','2014-01-02 11:51:07','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('717','2014-01-02 11:51:35','otto','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('718','2014-01-02 11:51:47','otto','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('719','2014-01-02 11:59:25','otto ','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('720','2014-01-02 11:59:54','otto ','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('721','2014-01-02 13:44:40','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('722','2014-01-02 14:41:33','Tracy-Liu','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('723','2014-01-02 14:59:50','otto ','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('724','2014-01-02 15:02:41','otto ','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('725','2014-01-02 15:04:42','Tracy-Liu','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('726','2014-01-02 15:05:03','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('727','2014-01-02 15:05:52','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('728','2014-01-02 15:06:29','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('729','2014-01-02 15:07:22','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('730','2014-01-02 15:10:09','otto ','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('731','2014-01-02 15:10:39','otto ','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('732','2014-01-02 15:12:27','otto ','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('733','2014-01-02 15:36:05','otto ','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('734','2014-01-02 15:37:16','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('735','2014-01-02 15:37:57','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('736','2014-01-02 15:38:41','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('737','2014-01-02 15:39:30','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('738','2014-01-02 15:59:00','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('739','2014-01-02 16:05:33','otto ','edit part, barcode=113874676203,name=Rear Bracket - Undefined');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('740','2014-01-02 16:19:57','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('741','2014-01-02 16:20:29','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('742','2014-01-02 16:20:58','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('743','2014-01-02 16:21:45','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('744','2014-01-02 16:23:05','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('745','2014-01-02 16:25:31','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('746','2014-01-02 16:26:05','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('747','2014-01-02 16:28:46','otto ','edit part, barcode=113874665250,name=Rear Bracket - 2028K - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('748','2014-01-02 16:30:29','otto ','edit part, barcode=113874665250,name=Rear Bracket - 2028K - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('749','2014-01-02 16:33:10','otto ','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('750','2014-01-02 16:33:54','otto ','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('751','2014-01-02 16:36:25','otto ','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('752','2014-01-02 16:37:32','otto ','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('753','2014-01-02 16:39:52','otto ','edit part, barcode=113874667209,name=Front Basket Bracket - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('754','2014-01-02 16:40:57','otto ','edit part, barcode=113874667209,name=Front Basket Bracket - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('755','2014-01-02 16:44:16','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('756','2014-01-02 16:45:45','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('757','2014-01-02 16:45:54','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('758','2014-01-02 16:48:52','otto ','edit part, barcode=113874676661,name=Backrest bracket - EG2028H - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('759','2014-01-03 09:35:17','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('760','2014-01-03 09:41:57','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('761','2014-01-03 09:44:00','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('762','2014-01-03 10:06:01','otto','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('763','2014-01-03 10:08:42','otto','edit part, barcode=113875684999,name=Side Rear View Mirror Bass - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('764','2014-01-03 10:09:38','otto','edit part, barcode=113875684999,name=Side Rear View Mirror Bass - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('765','2014-01-03 10:11:00','otto','edit part, barcode=113875683616,name=Side Rear View Mirror Bass - L');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('766','2014-01-03 10:11:23','otto','del part, barcode=113875683616,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('767','2014-01-03 10:50:11','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('768','2014-01-03 11:03:51','otto','edit part, barcode=113875685230,name=Jacket For Caddie Handle -  Piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('769','2014-01-03 11:05:06','otto','edit part, barcode=113875685230,name=Jacket For Caddie Handle -  Piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('770','2014-01-03 11:09:00','otto','edit part, barcode=113875686804,name=Dustproof cover');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('771','2014-01-03 11:29:47','otto','edit part, barcode=113875741190,name=Steering Shaft Bushing');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('772','2014-01-03 11:31:53','otto','edit part, barcode=113875741899,name=Hubcap - Aluminum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('773','2014-01-03 11:37:52','otto','edit part, barcode=113875742842,name=Hubcap - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('774','2014-01-03 11:50:59','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('775','2014-01-03 13:16:14','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('776','2014-01-03 14:15:36','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('777','2014-01-03 14:24:51','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('778','2014-01-03 14:26:51','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('779','2014-01-03 14:27:23','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('780','2014-01-03 14:28:28','otto','edit part, barcode=113875733270,name=Caddie Handle - 35 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('781','2014-01-03 14:30:14','otto','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('782','2014-01-03 14:30:54','otto','edit part, barcode=113875734794,name=Caddie Handle - 33 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('783','2014-01-03 14:31:37','otto','edit part, barcode=113875735287,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('784','2014-01-03 14:34:04','otto','edit part, barcode=113875709563,name=Seat Back Sub-bracket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('785','2014-01-03 14:35:17','otto','edit part, barcode=113875740798,name=Tie Rod');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('786','2014-01-03 14:38:35','otto','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('787','2014-01-03 14:42:26','otto','edit part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('788','2014-01-03 14:44:42','otto','edit part, barcode=113878990619,name=Shackle plate');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('789','2014-01-03 14:46:06','otto','edit part, barcode=113878997974,name=Steering Wheel Cover');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('790','2014-01-03 14:47:28','otto','edit part, barcode=113878991309,name=Flip-Flop Seat Rubber Pad');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('791','2014-01-03 14:48:30','otto','edit part, barcode=113878990073,name=Tyre valve');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('792','2014-01-03 14:50:50','otto','edit part, barcode=113878992304,name=Holding Block - Widshield');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('793','2014-01-03 14:54:16','otto','edit part, barcode=113875696246,name=Back Rest Cover - Plastic ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('794','2014-01-03 14:55:08','otto','edit part, barcode=113875693714,name=Underseat Compartment');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('795','2014-01-03 14:58:58','otto','edit part, barcode=113875527221,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('796','2014-01-03 15:00:47','otto','edit part, barcode=113875528431,name=Split Windshield - Clipping block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('797','2014-01-03 15:09:43','otto','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('798','2014-01-03 15:10:17','otto','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('799','2014-01-03 15:10:51','otto','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('800','2014-01-03 15:36:27','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('801','2014-01-03 15:42:55','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('802','2014-01-03 15:43:30','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('803','2014-01-03 15:55:15','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('804','2014-01-03 16:22:14','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('805','2014-01-03 16:26:59','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('806','2014-01-06 10:12:01','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('807','2014-01-06 10:14:06','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('808','2014-01-06 10:16:08','otto','add new part, barcode=113890212526,name=Top Basket,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('809','2014-01-06 10:17:55','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('810','2014-01-06 10:19:52','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('811','2014-01-06 10:22:19','otto ','edit part, barcode=113878280024,name=Carbon Brush - Chinese Motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('812','2014-01-06 10:25:15','otto ','edit part, barcode=113878280863,name=Carbon brush - ADC motor');
/*!40000 ALTER TABLE `ew_log` ENABLE KEYS */;


--
-- Create Table `ew_message`
--

DROP TABLE IF EXISTS `ew_message`;
CREATE TABLE `ew_message` (
  `mid` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `path` varchar(40) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_message`
--

/*!40000 ALTER TABLE `ew_message` DISABLE KEYS */;
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('165','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878280024,Carbon Brush - Chinese Motor,1,0.00,0.00<br>','2014-01-06 10:22:40','upload/1389021760932.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('166','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878280863,Carbon brush - ADC motor,15,0.00,0.00<br>','2014-01-06 10:25:37','upload/1389021937744.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('114','san','Original Viso File for Warehouse Map~~~~~','2013-12-20 17:04:41','upload/1387577081332.vsd');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('164','otto','<a href=\"http://192.168.1.175/www/upload/usermanual.pdf\">http://192.168.1.175/www/upload/usermanual.pdf</a>','2014-01-03 15:51:18','upload/usermanual.pdf');
/*!40000 ALTER TABLE `ew_message` ENABLE KEYS */;


--
-- Create Table `ew_part`
--

DROP TABLE IF EXISTS `ew_part`;
CREATE TABLE `ew_part` (
  `barcode` varchar(20) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT 'Name of the part',
  `photo_url` tinytext COMMENT 'Photo URL',
  `part_num` varchar(20) NOT NULL COMMENT 'Part number of the part',
  `category` varchar(20) NOT NULL COMMENT 'Body, Accessory, Tire and Rim, Mechanical, Electrical',
  `sub_category` varchar(20) NOT NULL COMMENT 'Universal, Club car, EZGO, AGT, Yamaha',
  `color` varchar(20) DEFAULT NULL COMMENT 'The color of product',
  `p_price` decimal(10,2) NOT NULL COMMENT 'Purchase price',
  `w_price` decimal(10,2) NOT NULL COMMENT 'Wholesale price',
  `r_price` decimal(10,2) NOT NULL COMMENT 'Retail price',
  `quantity` int(10) NOT NULL COMMENT 'Amount in stock',
  `w_quantity` int(10) NOT NULL COMMENT 'Warning if in stock less than this amount',
  `l_zone` varchar(20) DEFAULT NULL COMMENT 'Location zone',
  `l_column` varchar(20) DEFAULT NULL COMMENT 'Location column',
  `l_level` varchar(20) DEFAULT NULL COMMENT 'Location level',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Latest update date',
  `des` text NOT NULL COMMENT 'Description of item',
  `xsearch` text NOT NULL COMMENT 'Name,part_num,category,sub_category,color,location',
  PRIMARY KEY (`barcode`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_part`
--

/*!40000 ALTER TABLE `ew_part` DISABLE KEYS */;
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855780864','Wheel 155R12C KENDA with Steel Rim','upload/1388693241416.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','4','2','L','1','3_I SKID','2014-01-02 15:07:22','Truck Series','barcode:113855780864, name:wheel 155r12c kenda with steel rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855777806','Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim','upload/1388692789385.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','8','1','L','1','3_I SKID','2014-01-02 14:59:50','EG6040 Series','barcode:113855777806, name:wheel 25x8-12 atx78 wan da with aluminum rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855773834','Wheel 21x11-10 CST/ Aluminum Rim R','upload/1388693545682.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','28','2','L','1','3_II-III SKID','2014-01-02 15:12:27','','barcode:113855773834, name:wheel 21x11-10 cst/ aluminum rim r, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_ii-iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855768358','Wheel 21x11-10 CST/ Aluminum Rim F','upload/1388693438478.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','28','2','L','1','3_II-III SKID','2014-01-02 15:10:39','','barcode:113855768358, name:wheel 21x11-10 cst/ aluminum rim f, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_ii-iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855784845','225115B12 Journey with Aluminum Rim','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','75.00','0.00','0','-1','w','1','1','2013-12-20 13:08:40','','barcode:113855784845, name:225115b12 journey with aluminum rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855786227','Wheel 205150-10 KENDA with Aluminum Rim','upload/1388692959978.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','12','12','L','1','3_I SKID','2014-01-02 15:03:33','EG2028 Series','barcode:113855786227, name:wheel 205150-10 kenda with aluminum rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855787534','Flip-Flop Seat Kit','upload/1388437920928.jpg','PKG','body','AGT','default','0.00','0.00','0.00','40','2','L','1 and 2','2_I-II SKID','2013-12-30 16:12:02','','barcode:113855787534, name:flip-flop seat kit, model:pkg, category:body, sub category:agt, color:default, location:l_1 and 2_2_i-ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855789397','Windshield - Foldable - 2028','upload/1388436249022.jpg','PKG','body','AGT','Tint','0.00','0.00','0.00','69','2','L','3','2_I-II SKID','2013-12-30 15:44:10','','barcode:113855789397, name:windshield - foldable - 2028, model:pkg, category:body, sub category:agt, color:tint, location:l_3_2_i-ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855795797','Windshield - Foldable - 2020','upload/1388436931991.jpg','PKG','body','AGT','Tint','0.00','0.00','0.00','20','2','L','2','2_III SKID','2013-12-30 15:57:03','','barcode:113855795797, name:windshield - foldable - 2020, model:pkg, category:body, sub category:agt, color:tint, location:l_2_2_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856688278','Left Half Axle','upload/1388439086460.jpg','2402100-008','mechanical','AGT','default','0.00','0.00','0.00','49','5','L','2','3_III SKID','2014-01-02 11:51:47','','barcode:113856688278, name:left half axle, model:2402100-008, category:mechanical, sub category:agt, color:default, location:l_2_3_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856688951','Right Half Axle','upload/1388439216069.jpg','2402200-008','mechanical','AGT','default','0.00','0.00','0.00','49','5','L','2','3_III SKID','2014-01-02 11:51:35','','barcode:113856688951, name:right half axle, model:2402200-008, category:mechanical, sub category:agt, color:default, location:l_2_3_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856717210','Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ','upload/1388694963557.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','5','2','L','1','1_I-II SKID','2014-01-02 15:36:05','','barcode:113856717210, name:cargo box carbon steel- manual dump - 1400x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_1_1_i-ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856724550','Cargo Box Aluminum- Manual Dump - 1400x1100x250 ','upload/1388695168775.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','2','2','L','1','1_II SKID','2014-01-02 15:39:30','','barcode:113856724550, name:cargo box aluminum- manual dump - 1400x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_1_1_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856726379','Cargo Box Carbon Steel - Non Standard - 1000x1100x250','upload/1388436675428.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','2','2','L','2','1_I SKID','2013-12-30 15:51:16','','barcode:113856726379, name:cargo box carbon steel - non standard - 1000x1100x250, model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856726477','Cargo Box Aluminium - Non Standard - 1000x1100x250 ','upload/1388436785694.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','2','2','L','2','1_I SKID','2013-12-30 15:53:07','','barcode:113856726477, name:cargo box aluminium - non standard - 1000x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856730198','Cargo Box Aluminum - Standard - 770x1100x250 ','upload/1388435216069.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','2','2','L','2','1_III SKID','2013-12-30 15:26:57','','barcode:113856730198, name:cargo box aluminum - standard - 770x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856732204','Cargo Box Carbon Steel - Standard - 770x1100x250 ','upload/1388436536616.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','3','2','L','2','1_II SKID','2013-12-30 15:48:58','','barcode:113856732204, name:cargo box carbon steel - standard - 770x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856750152','Rear Cover - Metallic Green - Used','upload/default.jpg','5402010-036-A1','body','EZGO,AGT','default','0.00','0.00','0.00','2','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2028 Series','barcode:113856750152, name:rear cover - metallic green - used, model:5402010-036-a1, category:body, sub category:ezgo,agt, color:default, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856751451','Rear Cover - Pure Black - Used','upload/default.jpg','5402010-036-A4','body','EZGO,AGT','default','0.00','0.00','0.00','3','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2020 and EG2028 Series','barcode:113856751451, name:rear cover - pure black - used, model:5402010-036-a4, category:body, sub category:ezgo,agt, color:default, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856751895','Rear Cover - Camouflage - Used','upload/default.jpg','23456543','body','EZGO,AGT','default','0.00','0.00','0.00','1','0','L','2','3_I SKID','2013-12-20 13:08:40','EG6040 Series','barcode:113856751895, name:rear cover - camouflage - used, model:23456543, category:body, sub category:ezgo,agt, color:default, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860002295','Front Cover - Metallic Green - Used','upload/default.jpg','5302010-036-A1','body','AGT','Metallic Green','0.00','0.00','0.00','2','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2028 Series','barcode:113860002295, name:front cover - metallic green - used, model:5302010-036-a1, category:body, sub category:agt, color:metallic green, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860005355','Front Cover - Pure Black - Used','upload/default.jpg','5302010-036-A4','body','AGT','Pure Black','0.00','0.00','0.00','1','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2028 Series','barcode:113860005355, name:front cover - pure black - used, model:5302010-036-a4, category:body, sub category:agt, color:pure black, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860007132','Front Cover - Black - Used','upload/default.jpg','5302010-048','body','AGT','Black','0.00','0.00','0.00','2','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2020 Series','barcode:113860007132, name:front cover - black - used, model:5302010-048, category:body, sub category:agt, color:black, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860007207','Front Cover - Camouflage - Used','upload/default.jpg','3040-5202001-114','body','AGT','camouflage','0.00','0.00','0.00','1','0','L','2','3_I SKID','2014-01-02 09:48:26','EG6040','barcode:113860007207, name:front cover - camouflage - used, model:3040-5202001-114, category:body, sub category:agt, color:camouflage, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860008361','Central Cover - camouflage - used','upload/default.jpg','undefined','body','AGT','camouflage','0.00','0.00','0.00','1','0','L','2','3_I SKID','2014-01-02 09:48:21','EG6040','barcode:113860008361, name:central cover - camouflage - used, model:undefined, category:body, sub category:agt, color:camouflage, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860136683','Seat Back Cushion','upload/1388435411382.jpg','7106100-036','body','AGT','Tan','0.00','0.00','0.00','22','5','L','3','3_I SKID','2013-12-30 15:30:12','Without back plastic cover','barcode:113860136683, name:seat back cushion, model:7106100-036, category:body, sub category:agt, color:tan, location:l_3_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860146106','Seat Cushion','upload/1388434944225.jpg','7101100-036','body','AGT','Tan','0.00','0.00','0.00','24','4','L','3','3_II SKID','2013-12-30 15:22:25','EG2028 Seat Cushion (Battery Seat Cover)\r\nWithout Arm rest and Hinges','barcode:113860146106, name:seat cushion, model:7101100-036, category:body, sub category:agt, color:tan, location:l_3_3_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861020003','Passenger Seat EG6158','upload/1388680803072.jpg','7149000-014','body','AGT','Grey','0.00','0.00','0.00','4','2','L','2','3_II SKID','2014-01-02 11:50:37','PKG included 1 seat and a back rest cushion','barcode:113861020003, name:passenger seat eg6158, model:7149000-014, category:body, sub category:agt, color:grey, location:l_2_3_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861020767','Drivers Seat','upload/1388679341963.jpg','7101000-014','body','AGT','Grey','0.00','0.00','0.00','4','1','L','2','3_II SKID','2014-01-02 11:51:07','PKG included 2 seats (Driver & Passenger) EG6158 and a Back Rest Cushion','barcode:113861020767, name:drivers seat, model:7101000-014, category:body, sub category:agt, color:grey, location:l_2_3_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861036513','Assembly of Cushion','upload/1388434661975.jpg','7101100-040','body','AGT','Tan','0.00','0.00','0.00','10','5','L','3','3_III SKID','2013-12-30 15:17:43','First Row Seat\r\n(Without Plug in holes)','barcode:113861036513, name:assembly of cushion, model:7101100-040, category:body, sub category:agt, color:tan, location:l_3_3_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861699105','Front Axle Assembly','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','0','-1','w','1','1','2013-12-20 13:08:40','Completed front axle assembly','barcode:113861699105, name:front axle assembly, model:pkg, category:mechanical, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874020209','Backrest Cushion','upload/default.jpg','7106100-036 (PKG)','body','AGT','default','0.00','0.00','0.00','10','5','M','1','3_I SKID','2014-01-02 09:48:00','Included Parts:\r\nEG2028K Backrest cover - 7106111-036 - (1)\r\nSeat back sub-bracket - 7127011-037 - (2)','barcode:113874020209, name:backrest cushion, model:7106100-036 (pkg), category:body, sub category:agt, color:default, location:m_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874008674','Front Bumper - Metallic','upload/default.jpg','3040-5207010','body','AGT','default','0.00','0.00','0.00','8','4','M','1','2_II SKID','2014-01-02 09:48:14','','barcode:113874008674, name:front bumper - metallic, model:3040-5207010, category:body, sub category:agt, color:default, location:m_1_2_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874010003','Windshield - Non Foldable - 6040','upload/1388435887538.jpg','2020A-5203001','body','AGT','Clear','0.00','0.00','0.00','11','1','L','3','2_III SKID','2013-12-30 15:38:27','','barcode:113874010003, name:windshield - non foldable - 6040, model:2020a-5203001, category:body, sub category:agt, color:clear, location:l_3_2_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878320669','Side Rear View Mirror - RH','upload/1387833825207.jpg','9002200-005','body','AGT','Black','0.00','0.00','0.00','2','2','S2','1','5_I shelf','2013-12-23 16:23:46','','barcode:113878320669, name:side rear view mirror - rh, model:9002200-005, category:body, sub category:agt, color:black, location:s2_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874033533','Side Rear View Mirror','upload/1387830456785.jpg','9002100-009 (PKG)','body','EZGO,AGT','black','0.00','0.00','0.00','144','25','S1','1','5_I shelf','2013-12-23 20:17:12','','barcode:113874033533, name:side rear view mirror, model:9002100-009 (pkg), category:body, sub category:ezgo,agt, color:black, location:s1_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874657396','Front Basket','upload/1387830800223.jpg','5302100-048','accessory','AGT','black','0.00','0.00','0.00','18','4','S1','2','5_I shelf','2013-12-23 15:33:21','','barcode:113874657396, name:front basket, model:5302100-048, category:accessory, sub category:agt, color:black, location:s1_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874660495','Inner Rearview Mirror','upload/1387830299582.jpg','9001100-001','accessory','AGT','Black','0.00','0.00','0.00','9','2','S1','1','5_II shelf','2013-12-23 15:25:00','Included 9001100-001, 9001010-001','barcode:113874660495, name:inner rearview mirror, model:9001100-001, category:accessory, sub category:agt, color:black, location:s1_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874661256','Rear Bracket - 2020ASZ - paired','upload/1388698651103.jpg','5701021-063','body','AGT','default','0.00','0.00','0.00','2','4','S1','1','3_II shelf','2014-01-02 16:37:32','','barcode:113874661256, name:rear bracket - 2020asz - paired, model:5701021-063, category:body, sub category:agt, color:default, location:s1_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874665250','Rear Bracket - 2028K - paired','upload/1388698228322.jpg','2028-5601011','body','AGT','default','0.00','0.00','0.00','2','2','S1','1','2_I shelf','2014-01-02 16:30:29','','barcode:113874665250, name:rear bracket - 2028k - paired, model:2028-5601011, category:body, sub category:agt, color:default, location:s1_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874666349','Rear Bracket - 2028KSF - paired','upload/1388697963666.jpg','5701021-043','body','AGT','default','0.00','0.00','0.00','7','4','S1','1','3_I shelf','2014-01-02 16:26:05','','barcode:113874666349, name:rear bracket - 2028ksf - paired, model:5701021-043, category:body, sub category:agt, color:default, location:s1_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874667209','Front Basket Bracket - paired','upload/1388698856353.jpg','5302030-048','accessory','AGT','default','0.00','0.00','0.00','3','8','S1','1','2_II shelf','2014-01-02 16:41:23','','barcode:113874667209, name:front basket bracket - paired, model:5302030-048, category:accessory, sub category:agt, color:default, location:s1_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874668190','Rear Standing Board','upload/1388698433213.jpg','5402110-037','accessory','AGT','default','0.00','0.00','0.00','2','2','S1','1','1_I floor','2014-01-02 16:33:54','','barcode:113874668190, name:rear standing board, model:5402110-037, category:accessory, sub category:agt, color:default, location:s1_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874669055','Sweater Basket - Carbon Steel','upload/1387832082754.jpg','5405200-036','body','AGT','default','0.00','0.00','0.00','2','1','S1','1','1_II Floor','2013-12-23 15:54:43','','barcode:113874669055, name:sweater basket - carbon steel, model:5405200-036, category:body, sub category:agt, color:default, location:s1_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874676203','Rear Bracket - Undefined','upload/1388696732135.jpg','undefined','body','AGT','default','0.00','0.00','0.00','4','0','S1','1','4_I shelf','2014-01-02 16:05:33','','barcode:113874676203, name:rear bracket - undefined, model:undefined, category:body, sub category:agt, color:default, location:s1_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874676661','Backrest bracket - EG2028H - Paired','upload/1388699331010.jpg','7107011-039','body','AGT','default','0.00','0.00','0.00','3','2','S1','1','2_III shelf','2014-01-02 16:48:52','','barcode:113874676661, name:backrest bracket - eg2028h - paired, model:7107011-039, category:body, sub category:agt, color:default, location:s1_1_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874694069','Cargo Box Bracket Support','upload/1387831151645.jpg','8115010-039','accessory','AGT','default','0.00','0.00','0.00','12','4','S1','2','4_II shelf','2014-01-03 09:52:52','','barcode:113874694069, name:cargo box bracket support, model:8115010-039, category:accessory, sub category:agt, color:default, location:s1_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874688608','Cargo Box Support Bracket - 2048HCX','upload/1387832369457.jpg','8115210-044','accessory','AGT','default','0.00','0.00','0.00','5','4','S1','2','2_II shelf','2013-12-23 15:59:30','','barcode:113874688608, name:cargo box support bracket - 2048hcx, model:8115210-044, category:accessory, sub category:agt, color:default, location:s1_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874689510','Side Armrest','upload/1387832241926.jpg','5401141-037','accessory','AGT','default','0.00','0.00','0.00','2','4','S1','2','2_III shelf','2013-12-23 15:57:22','','barcode:113874689510, name:side armrest, model:5401141-037, category:accessory, sub category:agt, color:default, location:s1_2_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874690781','Seat Frame','upload/1387831276254.jpg','5401130-037','accessory','AGT','default','0.00','0.00','0.00','6','2','S1','2','3_II shelf','2013-12-23 15:41:17','','barcode:113874690781, name:seat frame, model:5401130-037, category:accessory, sub category:agt, color:default, location:s1_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874694562','Seat Belt Mounting Bar - 2 point','upload/1387831372785.jpg','7001210-048','accessory','AGT','default','0.00','0.00','0.00','105','5','S1','2','3_I shelf','2013-12-24 10:14:12','','barcode:113874694562, name:seat belt mounting bar - 2 point, model:7001210-048, category:accessory, sub category:agt, color:default, location:s1_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874701375','Searching Light Bracket 1','upload/1387832166785.jpg','5111032-033','body','AGT','default','0.00','0.00','0.00','3','2','S1','2','2_I shelf','2013-12-23 15:56:07','','barcode:113874701375, name:searching light bracket 1, model:5111032-033, category:body, sub category:agt, color:default, location:s1_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874801718','Searching Light - 4X4','upload/default.jpg','3107200-001','electrical','AGT','default','0.00','0.00','0.00','20','4','S3','1','5_I shelf','2013-12-23 18:20:15','','barcode:113874801718, name:searching light - 4x4, model:3107200-001, category:electrical, sub category:agt, color:default, location:s3_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874802719','Tail Light Assembled - LT - Golf','upload/default.jpg','3126100-003','electrical','AGT','default','0.00','0.00','0.00','9','5','S3','1','5_II shelf','2013-12-23 18:17:34','','barcode:113874802719, name:tail light assembled - lt - golf, model:3126100-003, category:electrical, sub category:agt, color:default, location:s3_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874804634','Tail Light Assembled - RH - Golf','upload/default.jpg','3126200-003','electrical','AGT','default','0.00','0.00','0.00','9','5','S3','1','5_III shelf','2013-12-23 18:19:14','','barcode:113874804634, name:tail light assembled - rh - golf, model:3126200-003, category:electrical, sub category:agt, color:default, location:s3_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874805471','Head Light - LH EG2028','upload/default.jpg','3117100-002','electrical','AGT','default','0.00','0.00','0.00','8','5','S3','1','5_IV shelf','2013-12-23 18:16:22','','barcode:113874805471, name:head light - lh eg2028, model:3117100-002, category:electrical, sub category:agt, color:default, location:s3_1_5_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874806896','Head Light - RH EG2028','upload/default.jpg','3117200-002','electrical','AGT','default','0.00','0.00','0.00','8','5','S3','1','5_IV shelf','2013-12-23 18:18:21','','barcode:113874806896, name:head light - rh eg2028, model:3117200-002, category:electrical, sub category:agt, color:default, location:s3_1_5_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874807201','Combination Switch','upload/default.jpg','3024100-005','electrical','AGT','default','0.00','0.00','0.00','30','10','S3','1','4_I shelf','2013-12-20 13:08:40','','barcode:113874807201, name:combination switch, model:3024100-005, category:electrical, sub category:agt, color:default, location:s3_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874807834','Converter DC 48V-12V','upload/default.jpg','3048100-001','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','11','5','S3','1','4_II shelf','2014-01-02 09:47:45','','barcode:113874807834, name:converter dc 48v-12v, model:3048100-001, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_1_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874808788','Converter DC 36V-12V','upload/default.jpg','3048100-002','electrical','AGT','default','0.00','0.00','0.00','14','5','S3','1','4_III shelf','2013-12-20 13:08:40','','barcode:113874808788, name:converter dc 36v-12v, model:3048100-002, category:electrical, sub category:agt, color:default, location:s3_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874809185','Controller Curtis 1243-4320','upload/default.jpg','1005100-012','electrical','CLUB,EZGO,AGT','default','0.00','0.00','0.00','3','3','S3','1','4_IV shelf','2013-12-24 11:17:04','','barcode:113874809185, name:controller curtis 1243-4320, model:1005100-012, category:electrical, sub category:club,ezgo,agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874811211','Controller Curtis 1266-5201','upload/default.jpg','1005100-013','electrical','CLUB,EZGO,AGT','default','0.00','0.00','0.00','5','2','S3','1','4_IV shelf','2013-12-20 11:57:53','','barcode:113874811211, name:controller curtis 1266-5201, model:1005100-013, category:electrical, sub category:club,ezgo,agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874812661','Controller Curtis 1268-5403','upload/default.jpg','1005100-007','electrical','CLUB,EZGO,AGT','default','0.00','0.00','0.00','3','4','S3','1','4_IV shelf','2013-12-20 13:08:40','','barcode:113874812661, name:controller curtis 1268-5403, model:1005100-007, category:electrical, sub category:club,ezgo,agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874813410','Tail Light - LT - EG6118','upload/default.jpg','PKG','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','1','5_III shelf','2013-12-23 18:15:43','','barcode:113874813410, name:tail light - lt - eg6118, model:pkg, category:electrical, sub category:agt, color:default, location:s3_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874815828','Tail Light - RT - EG6118','upload/default.jpg','PKG','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','1','5_III shelf','2013-12-23 18:14:53','','barcode:113874815828, name:tail light - rt - eg6118, model:pkg, category:electrical, sub category:agt, color:default, location:s3_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874816080','Controller Curtis 1244-5461','upload/default.jpg','1005100-006','electrical','AGT','default','0.00','0.00','0.00','5','2','S3','1','4_IV shelf','2013-12-20 11:55:50','','barcode:113874816080, name:controller curtis 1244-5461, model:1005100-006, category:electrical, sub category:agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874816760','Converter DC 72V-12V','upload/default.jpg','3048100-006','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','1','4_II shelf','2013-12-20 11:58:34','','barcode:113874816760, name:converter dc 72v-12v, model:3048100-006, category:electrical, sub category:agt, color:default, location:s3_1_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874833776','Combination Switch - Non Golf Cart','upload/default.jpg','3024100-004','electrical','AGT','default','0.00','0.00','0.00','3','2','S3','1','2_I shelf','2013-12-20 11:48:01','','barcode:113874833776, name:combination switch - non golf cart, model:3024100-004, category:electrical, sub category:agt, color:default, location:s3_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874835726','Speed Meter','upload/default.jpg','PKG','electrical','AGT','default','0.00','0.00','0.00','4','3','S3','1','2_I shelf','2013-12-20 13:58:50','','barcode:113874835726, name:speed meter, model:pkg, category:electrical, sub category:agt, color:default, location:s3_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874837101','AC Cable Extension','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','2','25','S3','1','2_II shelf','2013-12-23 20:27:23','','barcode:113874837101, name:ac cable extension, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874838896','AC Cable ','upload/default.jpg','2024-3022104','electrical','AGT','default','0.00','0.00','0.00','81','25','S3','1','2_III-IV shelf','2013-12-24 11:04:54','','barcode:113874838896, name:ac cable , model:2024-3022104, category:electrical, sub category:agt, color:default, location:s3_1_2_iii-iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874840236','Motor 48V 5KW','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','1','1','S3','1','1_I floor','2013-12-20 13:08:40','','barcode:113874840236, name:motor 48v 5kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874841056','Motor 36V 3kw','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','1','1','S3','1','1_II Floor','2013-12-20 13:41:23','','barcode:113874841056, name:motor 36v 3kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874841768','Motor 48V 3.8kw','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','1','1','S3','1','1_II Floor','2013-12-20 13:41:28','','barcode:113874841768, name:motor 48v 3.8kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874842091','Motor 48V 5.3kw','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','1','1','S3','1','1_II Floor','2013-12-20 13:41:32','','barcode:113874842091, name:motor 48v 5.3kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874843125','Charger - Smart 36V-120V','upload/default.jpg','1103100-002','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','2','1','S3','1','1_III floor','2013-12-20 13:08:40','','barcode:113874843125, name:charger - smart 36v-120v, model:1103100-002, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_1_1_iii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874843531','Windshield Wiper Motor Assembly','upload/default.jpg','3006110-010','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','1','1_III floor','2013-12-20 13:08:40','','barcode:113874843531, name:windshield wiper motor assembly, model:3006110-010, category:electrical, sub category:agt, color:default, location:s3_1_1_iii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874844445','Charger - DeltaQ 48V-110','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','2','3','S3','1','1_IV floor','2013-12-20 11:45:12','','barcode:113874844445, name:charger - deltaq 48v-110, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_iv floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874845600','Charger - DeltaQ 36V-110','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','3','2','S3','1','1_IV floor','2013-12-20 11:45:06','','barcode:113874845600, name:charger - deltaq 36v-110, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_iv floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874845946','Charger - DeltaQ 72V-110V','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','4','2','S3','1','1_IV floor','2013-12-20 11:46:41','Expect Stock : 2','barcode:113874845946, name:charger - deltaq 72v-110v, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_iv floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874854618','Head Light - LH EG6118','upload/default.jpg','3101100-002','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','2','5_I shelf','2013-12-23 18:23:13','','barcode:113874854618, name:head light - lh eg6118, model:3101100-002, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874855314','Head Light - RH EG6118','upload/default.jpg','3101200-002','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','2','5_I shelf','2013-12-23 18:22:49','','barcode:113874855314, name:head light - rh eg6118, model:3101200-002, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874855716','Front Fog Light - EG6118','upload/default.jpg','3113100-001','electrical','AGT','default','0.00','0.00','0.00','2','3','S3','2','5_I shelf','2013-12-23 18:23:02','','barcode:113874855716, name:front fog light - eg6118, model:3113100-001, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874856197','Front Turn Light - EG6118','upload/default.jpg','3109100-002','electrical','AGT','default','0.00','0.00','0.00','4','3','S3','2','5_I shelf','2013-12-23 18:22:34','','barcode:113874856197, name:front turn light - eg6118, model:3109100-002, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874862027','Tail Light Assembled - LH - Truck','upload/default.jpg','PKG','body','EZGO,AGT','default','0.00','0.00','0.00','5','2','S3','2','5_II shelf','2014-01-02 09:47:34','','barcode:113874862027, name:tail light assembled - lh - truck, model:pkg, category:body, sub category:ezgo,agt, color:default, location:s3_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874862100','Tail Light Assembled - RH - Truck','upload/default.jpg','PKG','electrical','AGT','default','0.00','0.00','0.00','5','2','S3','2','5_II shelf','2013-12-23 18:22:01','','barcode:113874862100, name:tail light assembled - rh - truck, model:pkg, category:electrical, sub category:agt, color:default, location:s3_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874862955','Head Light - EG2020','upload/default.jpg','3101100-008','electrical','AGT','default','0.00','0.00','0.00','18','5','S3','2','5_III shelf','2013-12-23 18:21:25','','barcode:113874862955, name:head light - eg2020, model:3101100-008, category:electrical, sub category:agt, color:default, location:s3_2_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874863430','Battery Cable Jacket - Black','upload/default.jpg','1101014-002','electrical','CLUB,EZGO,AGT,YAMAHA','Black','0.00','0.00','0.00','120','30','S3','2','4_I shelf','2013-12-19 16:51:16','','barcode:113874863430, name:battery cable jacket - black, model:1101014-002, category:electrical, sub category:club,ezgo,agt,yamaha, color:black, location:s3_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874864521','Battery Cable Jacket - Red','upload/default.jpg','1101014-002','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','120','30','S3','2','4_I shelf','2013-12-19 16:31:38','','barcode:113874864521, name:battery cable jacket - red, model:1101014-002, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874880273','Connect Wire 25x130mm ','upload/default.jpg','3313010-001','electrical','AGT','default','0.00','0.00','0.00','111','20','S3','2','4_II shelf','2013-12-23 18:42:36','','barcode:113874880273, name:connect wire 25x130mm , model:3313010-001, category:electrical, sub category:agt, color:default, location:s3_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875495207','Connect Wire 25x200mm ','upload/default.jpg','3313010-003','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','132','30','S3','2','4_II shelf','2013-12-23 18:42:59','','barcode:113875495207, name:connect wire 25x200mm , model:3313010-003, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875495845','Connect Wire 25Ã—300mm ','upload/default.jpg','3313010-005 ','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','42','20','S3','2','4_IV shelf','2013-12-23 18:49:50','','barcode:113875495845, name:connect wire 25Ã—300mm , model:3313010-005 , category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875496561','Connect Wire 25Ã—440mm ','upload/default.jpg','3313010-006 ','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','49','20','S3','2','4_III shelf','2013-12-23 18:45:43','','barcode:113875496561, name:connect wire 25Ã—440mm , model:3313010-006 , category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875499828','Battery Dead Lever - L End','upload/default.jpg','1101011-004','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','42','10','S3','2','4_IV shelf','2013-12-23 18:48:11','','barcode:113875499828, name:battery dead lever - l end, model:1101011-004, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875502090','Battery Impact Block','upload/default.jpg','1101012-003','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','28','10','S3','2','4_IV shelf','2013-12-23 18:47:59','','barcode:113875502090, name:battery impact block, model:1101012-003, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875502687','Battery Dead Lever - S End','upload/default.jpg','1101011-005','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','21','10','S3','2','4_IV shelf','2013-12-23 18:46:00','','barcode:113875502687, name:battery dead lever - s end, model:1101011-005, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875504357','Accelerator','upload/default.jpg','1007100-004','electrical','AGT','default','0.00','0.00','0.00','7','3','S3','2','3_I shelf','2013-12-20 11:31:13','','barcode:113875504357, name:accelerator, model:1007100-004, category:electrical, sub category:agt, color:default, location:s3_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875505132','Main Contactor - 36V 200A','upload/default.jpg','1005200','electrical','AGT','default','0.00','0.00','0.00','5','2','S3','2','3_II shelf','2013-12-20 09:43:58','','barcode:113875505132, name:main contactor - 36v 200a, model:1005200, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875506414','Main Contactor - 48V 150A','upload/default.jpg','1005200','electrical','AGT','default','0.00','0.00','0.00','4','2','S3','2','3_II shelf','2013-12-20 09:44:31','','barcode:113875506414, name:main contactor - 48v 150a, model:1005200, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875506733','Main Contactor - 48V 300A','upload/default.jpg','1005200','electrical','AGT','default','0.00','0.00','0.00','1','2','S3','2','3_II shelf','2013-12-20 09:44:58','','barcode:113875506733, name:main contactor - 48v 300a, model:1005200, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875506994','Main Contactor - 48V 100A FSIP','upload/default.jpg','FSIP','electrical','AGT','default','0.00','0.00','0.00','4','0','S3','2','3_II shelf','2013-12-20 09:45:50','','barcode:113875506994, name:main contactor - 48v 100a fsip, model:fsip, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875507516','Meter','upload/default.jpg','3212100-033','electrical','AGT','default','0.00','0.00','0.00','22','5','S3','2','3_III shelf','2013-12-24 13:45:24','','barcode:113875507516, name:meter, model:3212100-033, category:electrical, sub category:agt, color:default, location:s3_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875508403','Meter Holder','upload/default.jpg','5305180-036','electrical','AGT','Black','0.00','0.00','0.00','22','5','S3','2','3_III shelf','2013-12-20 13:40:16','','barcode:113875508403, name:meter holder, model:5305180-036, category:electrical, sub category:agt, color:black, location:s3_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875508802','Meter Wires - Long','upload/default.jpg','SE-91','electrical','AGT','default','0.00','0.00','0.00','16','5','S3','2','2_III shelf','2013-12-20 13:40:55','','barcode:113875508802, name:meter wires - long, model:se-91, category:electrical, sub category:agt, color:default, location:s3_2_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875510340','Meter Wires - Short','upload/default.jpg','SE-91','electrical','AGT','default','0.00','0.00','0.00','18','5','S3','2','2_IV shelf','2013-12-20 13:40:57','','barcode:113875510340, name:meter wires - short, model:se-91, category:electrical, sub category:agt, color:default, location:s3_2_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875510757','Meter Wires - Extension','upload/default.jpg','SE-91','electrical','AGT','default','0.00','0.00','0.00','4','5','S3','2','2_II shelf','2013-12-20 13:40:51','','barcode:113875510757, name:meter wires - extension, model:se-91, category:electrical, sub category:agt, color:default, location:s3_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875511107','Battery Impact Block Cap','upload/default.jpg','1101012-003','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','39','10','S3','2','1_II Floor','2013-12-20 11:38:38','','barcode:113875511107, name:battery impact block cap, model:1101012-003, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875517870','Side rear view mirror - LH','upload/1387833581988.jpg','9002100-005','body','AGT','Black','0.00','0.00','0.00','4','2','S2','1','5_II shelf','2013-12-23 16:19:43','','barcode:113875517870, name:side rear view mirror - lh, model:9002100-005, category:body, sub category:agt, color:black, location:s2_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875518830','Side rear view mirror - LH','upload/1387833621067.jpg','9002100-005','body','AGT','silver','0.00','0.00','0.00','4','2','S2','1','5_II shelf','2013-12-23 16:20:22','','barcode:113875518830, name:side rear view mirror - lh, model:9002100-005, category:body, sub category:agt, color:silver, location:s2_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875519554','EG6020A4D Battery Cover on Front Body','upload/1387833393520.jpg','SE-199','electrical','AGT','default','0.00','0.00','0.00','2','1','S2','1','5_III shelf','2013-12-23 16:16:34','','barcode:113875519554, name:eg6020a4d battery cover on front body, model:se-199, category:electrical, sub category:agt, color:default, location:s2_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875523072','Motor Access EG6158','upload/1387833314645.jpg','5103051-014','mechanical','AGT','default','0.00','0.00','0.00','2','1','S2','1','5_III shelf','2013-12-23 16:15:15','','barcode:113875523072, name:motor access eg6158, model:5103051-014, category:mechanical, sub category:agt, color:default, location:s2_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875525170','Motor Cover - EG6040A4D','upload/1387833256613.jpg','PKG','body','AGT','default','0.00','0.00','0.00','2','1','S2','1','5_III shelf','2014-01-02 09:46:50','','barcode:113875525170, name:motor cover - eg6040a4d, model:pkg, category:body, sub category:agt, color:default, location:s2_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875527221','Split Windshield - Slip block','upload/1388779137213.jpg','PKG','body','AGT','default','0.00','0.00','0.00','100','4','S2','1','4_I shelf','2014-01-03 15:01:04','','barcode:113875527221, name:split windshield - slip block, model:pkg, category:body, sub category:agt, color:default, location:s2_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875528431','Split Windshield - Clipping block','upload/1388779246088.jpg','PKG','body','AGT','default','0.00','0.00','0.00','100','10','S2','1','4_I shelf','2014-01-03 15:01:04','','barcode:113875528431, name:split windshield - clipping block, model:pkg, category:body, sub category:agt, color:default, location:s2_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875562993','Cargo Box - Manual Dump - Handle','upload/1388778145963.jpg','undefined','body','AGT','default','0.00','0.00','0.00','44','5','S2','1','4_II shelf','2014-01-03 14:42:26','','barcode:113875562993, name:cargo box - manual dump - handle, model:undefined, category:body, sub category:agt, color:default, location:s2_1_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875563935','Sash (Clipper)','upload/1387836009629.jpg','5303021-012','body','EZGO,AGT','default','0.00','0.00','0.00','150','4','S2','1','3_I-III shelf','2014-01-03 11:51:20','','barcode:113875563935, name:sash (clipper), model:5303021-012, category:body, sub category:ezgo,agt, color:default, location:s2_1_3_i-iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875628522','Sash (Clipper) - One piece','upload/1387835959223.jpg','5303021-011','body','AGT','default','0.00','0.00','0.00','16','2','S2','1','3_III shelf','2014-01-03 13:06:54','','barcode:113875628522, name:sash (clipper) - one piece, model:5303021-011, category:body, sub category:agt, color:default, location:s2_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875682157','Canopy Handle - 2028 - 4 Passenger Plus','upload/1388761560447.jpg','5708010-014','body','AGT','default','0.00','0.00','0.00','36','5','S2','1','2_I shelf','2014-01-03 10:06:01','','barcode:113875682157, name:canopy handle - 2028 - 4 passenger plus, model:5708010-014, category:body, sub category:agt, color:default, location:s2_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875683616','Side Rear View Mirror Bass - L','upload/default.jpg','undefined','body','AGT','default','0.00','0.00','0.00','0','-1','S2','1','2_II shelf','2014-01-03 10:11:23','','barcode:113875683616, name:side rear view mirror bass - l, model:undefined, category:body, sub category:agt, color:default, location:s2_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875684999','Side Rear View Mirror Bass - Paired','upload/1388761777869.jpg','undefined','body','AGT','default','0.00','0.00','0.00','148','25','S2','1','2_II shelf','2014-01-03 10:41:00','','barcode:113875684999, name:side rear view mirror bass - paired, model:undefined, category:body, sub category:agt, color:default, location:s2_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875685230','Jacket For Caddie Handle -  Piece','upload/1388765105260.jpg','570104','body','AGT','default','0.00','0.00','0.00','660','20','S2','1','2_III shelf','2014-01-03 11:05:06','Included:\r\n5701041-036 #1 jacket for caddie handle (2)\r\n5701042-036 #2 jacket for caddie handle (2)','barcode:113875685230, name:jacket for caddie handle -  piece, model:570104, category:body, sub category:agt, color:default, location:s2_1_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875686804','Dustproof cover','upload/1388765339463.jpg','2701112-008','body','AGT','default','0.00','0.00','0.00','58','5','S2','1','2_IV shelf','2014-01-03 11:09:00','','barcode:113875686804, name:dustproof cover, model:2701112-008, category:body, sub category:agt, color:default, location:s2_1_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875687755','Floor Mat - Short','upload/default.jpg','2028-5106006','body','AGT','default','0.00','0.00','0.00','5','2','S2','1','1_I floor','2014-01-02 09:46:20','','barcode:113875687755, name:floor mat - short, model:2028-5106006, category:body, sub category:agt, color:default, location:s2_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875688937','Floor Mat - Long','upload/default.jpg','5107010-040','body','AGT','default','0.00','0.00','0.00','5','2','S2','1','1_I floor','2013-12-20 14:48:36','','barcode:113875688937, name:floor mat - long, model:5107010-040, category:body, sub category:agt, color:default, location:s2_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875689178','Enclosure for EG6118','upload/default.jpg','9015110-004','accessory','AGT','default','0.00','0.00','0.00','1','1','S2','1','1_II Floor','2013-12-20 14:56:09','','barcode:113875689178, name:enclosure for eg6118, model:9015110-004, category:accessory, sub category:agt, color:default, location:s2_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875693714','Underseat Compartment','upload/1388778907103.jpg','2028-9015022','body','AGT','default','0.00','0.00','0.00','7','2','S2','2','5_I shelf','2014-01-03 14:55:08','','barcode:113875693714, name:underseat compartment, model:2028-9015022, category:body, sub category:agt, color:default, location:s2_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875696246','Back Rest Cover - Plastic ','upload/1388778855385.jpg','7106111-036','body','AGT','default','0.00','0.00','0.00','20','2','S2','2','5_II shelf','2014-01-03 14:54:16','','barcode:113875696246, name:back rest cover - plastic , model:7106111-036, category:body, sub category:agt, color:default, location:s2_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875703804','Canopy Handle - 2028','upload/1387834464238.jpg','5702021-036','body','AGT','default','0.00','0.00','0.00','10','0','S2','2','4_III shelf','2013-12-23 16:34:25','','barcode:113875703804, name:canopy handle - 2028, model:5702021-036, category:body, sub category:agt, color:default, location:s2_2_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875705210','Seat back support - carbon steel - EG2028K','upload/1387834345801.jpg','7107011-036','body','AGT','default','0.00','0.00','0.00','2','0','S2','2','4_II shelf','2013-12-23 16:32:26','','barcode:113875705210, name:seat back support - carbon steel - eg2028k, model:7107011-036, category:body, sub category:agt, color:default, location:s2_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875706287','Arm Rest - Paired','upload/1388777914932.jpg','7109100-036','body','AGT','default','0.00','0.00','0.00','2','2','S2','2','4_I shelf','2014-01-03 14:38:35','','barcode:113875706287, name:arm rest - paired, model:7109100-036, category:body, sub category:agt, color:default, location:s2_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875707186','Sweater Basket Frame','upload/1387835896832.jpg','5405110-036 (PKG)','body','AGT','default','0.00','0.00','0.00','2','1','S2','2','3_I shelf','2013-12-23 16:58:17','Included\r\n405130-036 Bag Strap Clip (2)\r\n5405110-036 Sweater Basket frame (1)\r\n5405121-036 Basket frame rubber strip (1)\r\n5405122-036 Bag strap (1)\r\n5405123-036 Bag strap plate (1)\r\nQ2140655-304H\r\nBlack nickel cross slot pan head bolt M6Ã—55 (2)\r\nQ40206-304H \r\nBlack nickel big washer M6 (10)','barcode:113875707186, name:sweater basket frame, model:5405110-036 (pkg), category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875709563','Seat Back Sub-bracket','upload/1388777643041.jpg','7127011-037','body','AGT','default','0.00','0.00','0.00','10','10','S2','2','3_II shelf','2014-01-03 14:34:04','','barcode:113875709563, name:seat back sub-bracket, model:7127011-037, category:body, sub category:agt, color:default, location:s2_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875732227','Caddie Handle - 38.5 inches (Old Model)','upload/1388777242260.jpg','5701031-039','body','AGT','default','0.00','0.00','0.00','4','0','S2','2','3_I shelf','2014-01-03 14:27:23','2028KSZ','barcode:113875732227, name:caddie handle - 38.5 inches (old model), model:5701031-039, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875733270','Caddie Handle - 35 inches (Old Model)','upload/1388777307478.jpg','5701031-036','body','AGT','default','0.00','0.00','0.00','1','0','S2','2','3_I shelf','2014-01-03 14:28:28','2028K','barcode:113875733270, name:caddie handle - 35 inches (old model), model:5701031-036, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875734063','Caddie Handle - 39 inches','upload/1388777413369.jpg','5701031-047','body','AGT','default','0.00','0.00','0.00','2','2','S2','2','3_I shelf','2014-01-03 14:30:14','2040KSZ, 2048KSZ','barcode:113875734063, name:caddie handle - 39 inches, model:5701031-047, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875734794','Caddie Handle - 33 inches','upload/1388777453697.jpg','5701031-055','body','AGT','default','0.00','0.00','0.00','3','2','S2','2','3_I shelf','2014-01-03 14:30:54','2020ASZ','barcode:113875734794, name:caddie handle - 33 inches, model:5701031-055, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875735287','Caddie Handle - 38.5 inches','upload/1388777496510.jpg','5701031-039','body','AGT','default','0.00','0.00','0.00','1','2','S2','2','3_I shelf','2014-01-03 14:31:37','2028KSZ','barcode:113875735287, name:caddie handle - 38.5 inches, model:5701031-039, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875740798','Tie Rod','upload/1388777716932.jpg','2706100-036','body','AGT','default','0.00','0.00','0.00','18','0','S2','2','3_III shelf','2014-01-03 14:35:17','','barcode:113875740798, name:tie rod, model:2706100-036, category:body, sub category:agt, color:default, location:s2_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875741190','Steering Shaft Bushing','upload/1388766586025.jpg','2712011-036','body','AGT','default','0.00','0.00','0.00','50','5','S2','2','2_I shelf','2014-01-03 11:29:47','','barcode:113875741190, name:steering shaft bushing, model:2712011-036, category:body, sub category:agt, color:default, location:s2_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875741899','Hubcap - Aluminum','upload/1388766712432.jpg','2024-2301002A','body','AGT','default','0.00','0.00','0.00','200','20','S2','2','2_II shelf','2014-01-03 11:36:11','','barcode:113875741899, name:hubcap - aluminum, model:2024-2301002a, category:body, sub category:agt, color:default, location:s2_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875742842','Hubcap - Plastic','upload/1388767071728.jpg','2600114-048','body','AGT','default','0.00','0.00','0.00','118','2','S2','2','2_IV shelf','2014-01-03 11:41:49','','barcode:113875742842, name:hubcap - plastic, model:2600114-048, category:body, sub category:agt, color:default, location:s2_2_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875744437','Enclosure - EG2028KSZ','upload/default.jpg','9015110-037','body','AGT','default','0.00','0.00','0.00','10','3','S2','2','1_I floor','2013-12-20 16:21:22','','barcode:113875744437, name:enclosure - eg2028ksz, model:9015110-037, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875744839','Enclosure - EG6158','upload/default.jpg','9015110-002','body','AGT','default','0.00','0.00','0.00','1','1','S2','2','1_I floor','2013-12-20 16:22:27','','barcode:113875744839, name:enclosure - eg6158, model:9015110-002, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875745490','Enclosure - EG2048K','upload/default.jpg','9015110-040','body','AGT','default','0.00','0.00','0.00','2','3','S2','2','1_I floor','2014-01-02 09:46:11','','barcode:113875745490, name:enclosure - eg2048k, model:9015110-040, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875746339','Enclosure - EG6043','upload/default.jpg','9021100-006','body','AGT','default','0.00','0.00','0.00','2','1','S2','2','1_I floor','2014-01-02 09:45:47','','barcode:113875746339, name:enclosure - eg6043, model:9021100-006, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875749549','Rear Wheel Trim - Fender Flare (Paired)','upload/default.jpg','2020A-5502001','accessory','AGT','default','0.00','0.00','0.00','6','3','S4','1','5_II shelf','2013-12-20 16:31:19','','barcode:113875749549, name:rear wheel trim - fender flare (paired), model:2020a-5502001, category:accessory, sub category:agt, color:default, location:s4_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875750225','Front Wheel Trim - Fender Flare (Paired)','upload/default.jpg','2020A-5402001','accessory','AGT','default','0.00','0.00','0.00','7','3','S4','1','5_I shelf','2013-12-20 16:31:06','','barcode:113875750225, name:front wheel trim - fender flare (paired), model:2020a-5402001, category:accessory, sub category:agt, color:default, location:s4_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875752178','Braking Cable Assembly','upload/default.jpg','undefined','body','AGT','default','0.00','0.00','0.00','19','3','S4','1','4_I shelf','2013-12-20 16:34:06','','barcode:113875752178, name:braking cable assembly, model:undefined, category:body, sub category:agt, color:default, location:s4_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875752475','Windshield Wiper - EG6043','upload/default.jpg','6042-30160','body','AGT','default','0.00','0.00','0.00','1','1','S4','1','3_I shelf','2014-01-02 09:45:40','Included:\r\n6042-3016020 Windshield wiper arm (1)\r\n6042-3016030 Wiper brush (1)','barcode:113875752475, name:windshield wiper - eg6043, model:6042-30160, category:body, sub category:agt, color:default, location:s4_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875753656','Windshield Wiper - EG6118 (Paired)','upload/default.jpg','38340','body','AGT','default','0.00','0.00','0.00','2','2','S4','1','3_I shelf','2014-01-02 09:45:34','','barcode:113875753656, name:windshield wiper - eg6118 (paired), model:38340, category:body, sub category:agt, color:default, location:s4_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875756083','Copper Sheath - Thin','upload/default.jpg','2302112-008','body','AGT','default','0.00','0.00','0.00','10','0','S4','1','3_II shelf','2013-12-20 16:41:54','','barcode:113875756083, name:copper sheath - thin, model:2302112-008, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875756594','Copper Sheath - Thick','upload/default.jpg','2302113-008','body','AGT','default','0.00','0.00','0.00','10','0','S4','1','3_II shelf','2013-12-20 16:41:42','','barcode:113875756594, name:copper sheath - thick, model:2302113-008, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875757195','Bearing Assembly','upload/default.jpg','L44643','mechanical','AGT','default','0.00','0.00','0.00','1','0','S4','1','3_III shelf','2013-12-20 16:43:01','','barcode:113875757195, name:bearing assembly, model:l44643, category:mechanical, sub category:agt, color:default, location:s4_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875757827','Bearing 6206-Z','upload/default.jpg','6206','mechanical','AGT','default','0.00','0.00','0.00','20','0','S4','1','3_III shelf','2013-12-20 16:44:04','','barcode:113875757827, name:bearing 6206-z, model:6206, category:mechanical, sub category:agt, color:default, location:s4_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875758458','Redirector Assembly','upload/default.jpg','2701100-008','mechanical','AGT','default','0.00','0.00','0.00','2','0','S4','1','3_III shelf','2013-12-20 16:45:21','','barcode:113875758458, name:redirector assembly, model:2701100-008, category:mechanical, sub category:agt, color:default, location:s4_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875764620','Wheel Nut - Aluminum Rim','upload/default.jpg','2600012-012','body','AGT','default','0.00','0.00','0.00','500','100','S4','1','3_II shelf','2013-12-20 16:55:36','','barcode:113875764620, name:wheel nut - aluminum rim, model:2600012-012, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878082911','Seat Belt Set - 2 point','upload/default.jpg','PKG','accessory','EZGO,AGT','default','0.00','0.00','0.00','41','3','S4','1','3_IV shelf','2013-12-23 09:25:46','','barcode:113878082911, name:seat belt set - 2 point, model:pkg, category:accessory, sub category:ezgo,agt, color:default, location:s4_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878086410','Seat Belt Set - 3 point','upload/default.jpg','PKG','accessory','EZGO,AGT','default','0.00','0.00','0.00','15','3','S4','1','3_IV shelf','2013-12-23 09:24:47','','barcode:113878086410, name:seat belt set - 3 point, model:pkg, category:accessory, sub category:ezgo,agt, color:default, location:s4_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878088327','Front Axle Assembly - EG2020','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','11','2','S4','2','1_I floor','2013-12-23 09:49:50','Included:\r\n2300000-008 Front axle assembly (1)\r\nQ52110130 King pinÐ¤12Ã—130 (2)\r\nQ40212 Big gasket M12 (4)\r\n2302114-008 King pin pipe (2)\r\nQ40112 Gasket M12 (2)\r\nQ32612 Nut M12 (2)\r\nOiliness copper bush (4)\r\n2302100-015 Left knuckle (include item 2-7) (1)\r\n2302200-015 Right knuckle (include item 2-7) (1)\r\n\r\nFront Hub\r\n2600111-036 Front hub (2)\r\n44643/10 Bearing assembly (4)\r\nQ38324 Slotted nut M24 (2)\r\n2600114-048 Spindle cap (for steel wheel) (2)\r\n2024-2301002A Spindle cap (for aluminum\r\nwheel) (2)\r\nChromeplate 2600113-036 Oil seal (2)\r\n2302100-008 Spindle assembly LH (1)\r\n2600011-012 Tyre bolt M12Ã—45 (8)\r\n2302200-008 Spindle assembly RH (1)','barcode:113878088327, name:front axle assembly - eg2020, model:pkg, category:mechanical, sub category:agt, color:default, location:s4_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878088998','Front Axle Assembly - Semi','upload/default.jpg','2300000-008','mechanical','AGT','default','0.00','0.00','0.00','2','0','S4','1','2_I shelf','2013-12-23 09:30:48','Included:\r\n2300000-008 solely','barcode:113878088998, name:front axle assembly - semi, model:2300000-008, category:mechanical, sub category:agt, color:default, location:s4_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878093952','Rear Brake assembly RH','upload/default.jpg','2802200-007','mechanical','AGT','default','0.00','0.00','0.00','20','5','S4','2','2_II shelf','2013-12-23 09:40:57','Included:\r\n2802110-007 Brake shoe (2) \r\nMotherboard assembly (2)\r\nAdjusting screw LH (1)\r\nAdjusting screw RH (1)\r\nRatchet wheel LH (1)\r\nRatchet wheel RH (1)\r\nMandril head (2)\r\nQ150B0825 Bolt M8Ã—25 (8)\r\nQ32608 Self-lock nut M8 (8)\r\nBearing peg (4)\r\nSpring and cuppy restrainer (4)\r\nUpside return spring (2)\r\nUnderside return spring (2)\r\nAdjusting spring (2)\r\nDialing clip LH (1)\r\nDialing clip RH (1)','barcode:113878093952, name:rear brake assembly rh, model:2802200-007, category:mechanical, sub category:agt, color:default, location:s4_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878094409','Rear Brake assembly LH','upload/default.jpg','2802100-007','mechanical','AGT','default','0.00','0.00','0.00','20','5','S4','1','2_III shelf','2013-12-23 09:40:48','Included:\r\n2802110-007 Brake shoe (2) \r\nMotherboard assembly (2)\r\nAdjusting screw LH (1)\r\nAdjusting screw RH (1)\r\nRatchet wheel LH (1)\r\nRatchet wheel RH (1)\r\nMandril head (2)\r\nQ150B0825 Bolt M8Ã—25 (8)\r\nQ32608 Self-lock nut M8 (8)\r\nBearing peg (4)\r\nSpring and cuppy restrainer (4)\r\nUpside return spring (2)\r\nUnderside return spring (2)\r\nAdjusting spring (2)\r\nDialing clip LH (1)\r\nDialing clip RH (1)','barcode:113878094409, name:rear brake assembly lh, model:2802100-007, category:mechanical, sub category:agt, color:default, location:s4_1_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878096654','Brake Shoe','upload/default.jpg','2802110-007','mechanical','AGT','default','0.00','0.00','0.00','46','0','S4','1','2_IV shelf','2013-12-23 09:42:16','','barcode:113878096654, name:brake shoe, model:2802110-007, category:mechanical, sub category:agt, color:default, location:s4_1_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878098067','Brake Shoe - Unidentified','upload/default.jpg','6082-2801080/ 280111','mechanical','AGT','default','0.00','0.00','0.00','48','0','S4','1','2_IV shelf','2013-12-23 09:46:36','','barcode:113878098067, name:brake shoe - unidentified, model:6082-2801080/ 2801110-007, category:mechanical, sub category:agt, color:default, location:s4_1_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878099978','Front Axle Assembly - EG2028','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','0','2','S4','1','1_I floor','2013-12-23 09:49:02','Included:\r\n2300000-008 Front axle assembly (1)\r\nQ52110130 King pinÐ¤12Ã—130 (2)\r\nQ40212 Big gasket M12 (4)\r\n2302114-008 King pin pipe (2)\r\nQ40112 Gasket M12 (2)\r\nQ32612 Nut M12 (2)\r\nOiliness copper bush (4)\r\n2302100-015 Left knuckle (include item 2-7) (1)\r\n2302200-015 Right knuckle (include item 2-7) (1)\r\n\r\nFront Hub\r\n2600111-036 Front hub (2)\r\n44643/10 Bearing assembly (4)\r\nQ38324 Slotted nut M24 (2)\r\n2600114-048 Spindle cap (for steel wheel) (2)\r\n2024-2301002A Spindle cap (for aluminum\r\nwheel) (2)\r\nChromeplate 2600113-036 Oil seal (2)\r\n2302100-008 Spindle assembly LH (1)\r\n2600011-012 Tyre bolt M12Ã—45 (8)\r\n2302200-008 Spindle assembly RH (1)','barcode:113878099978, name:front axle assembly - eg2028, model:pkg, category:mechanical, sub category:agt, color:default, location:s4_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878103106','Rear Axle Assembly ','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','1','1','h','1','0','2013-12-24 10:22:15','','barcode:113878103106, name:rear axle assembly , model:pkg, category:mechanical, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878103505','Rear Bumper - EG2020/ EG2028','upload/default.jpg','5406110-010','body','AGT','default','0.00','0.00','0.00','12','3','S4','2','5_I shelf','2013-12-23 16:51:33','','barcode:113878103505, name:rear bumper - eg2020/ eg2028, model:5406110-010, category:body, sub category:agt, color:default, location:s4_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878104320','Motor Access - EG2028/ EG2020','upload/default.jpg','5402041-036','body','AGT','default','0.00','0.00','0.00','48','4','S4','2','5_II shelf','2013-12-23 09:54:51','','barcode:113878104320, name:motor access - eg2028/ eg2020, model:5402041-036, category:body, sub category:agt, color:default, location:s4_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878104955','Fender scuffguard - Paired','upload/default.jpg','5402021-036','body','AGT','default','0.00','0.00','0.00','7','1','S4','2','4_I shelf','2013-12-23 09:56:56','','barcode:113878104955, name:fender scuffguard - paired, model:5402021-036, category:body, sub category:agt, color:default, location:s4_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878106177','Front Bumper - EG2028','upload/default.jpg','5307110-007','body','AGT','default','0.00','0.00','0.00','9','2','S4','2','4_II shelf','2013-12-23 09:57:37','','barcode:113878106177, name:front bumper - eg2028, model:5307110-007, category:body, sub category:agt, color:default, location:s4_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878106590','Front Bumper - EG2020 - Plastic','upload/default.jpg','5307110-008','body','AGT','default','0.00','0.00','0.00','3','2','S4','2','4_III shelf','2014-01-02 09:45:26','','barcode:113878106590, name:front bumper - eg2020 - plastic, model:5307110-008, category:body, sub category:agt, color:default, location:s4_2_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878107737','Front Shock Absorber Assembly - EG2020','upload/default.jpg','2504100-005','mechanical','AGT','default','0.00','0.00','0.00','8','2','S4','2','3_II shelf','2013-12-23 10:01:27','','barcode:113878107737, name:front shock absorber assembly - eg2020, model:2504100-005, category:mechanical, sub category:agt, color:default, location:s4_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878109179','Front Shock Absorber Assembly - EG2028','upload/default.jpg','2504100-003','mechanical','AGT','default','0.00','0.00','0.00','2','2','S4','2','3_III shelf','2013-12-23 10:02:29','','barcode:113878109179, name:front shock absorber assembly - eg2028, model:2504100-003, category:mechanical, sub category:agt, color:default, location:s4_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878109505','Front Shock Absorber Assembly - Unidentified','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','2','2','S4','2','3_II shelf','2013-12-23 10:03:19','','barcode:113878109505, name:front shock absorber assembly - unidentified, model:pkg, category:mechanical, sub category:agt, color:default, location:s4_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878110008','Left Knuckle','upload/default.jpg','2302100-008','mechanical','AGT','default','0.00','0.00','0.00','8','0','S4','2','3_III shelf','2013-12-23 10:07:30','Included:\r\n2302112-008 Oiliness copper bushï¼ˆthickï¼‰(1)\r\n2302113-008 Oiliness copper bush (thin) (1)','barcode:113878110008, name:left knuckle, model:2302100-008, category:mechanical, sub category:agt, color:default, location:s4_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878112510','Right Knuckle','upload/default.jpg','2302200-008','mechanical','AGT','default','0.00','0.00','0.00','7','0','S4','2','3_III shelf','2013-12-23 10:08:12','Included:\r\n2302112-008 Oiliness copper bushï¼ˆthickï¼‰(1)\r\n2302113-008 Oiliness copper bush (thin) (1)','barcode:113878112510, name:right knuckle, model:2302200-008, category:mechanical, sub category:agt, color:default, location:s4_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878112939','Watering System','upload/default.jpg','PKG','accessory','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','2','2','S4','2','3_IV shelf','2013-12-23 10:08:59','','barcode:113878112939, name:watering system, model:pkg, category:accessory, sub category:club,ezgo,agt,yamaha, color:default, location:s4_2_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878113414','Front Leaf Spring Assembly','upload/default.jpg','2501100-008','mechanical','AGT','default','0.00','0.00','0.00','3','2','S4','2','2_I shelf','2013-12-23 10:10:43','','barcode:113878113414, name:front leaf spring assembly, model:2501100-008, category:mechanical, sub category:agt, color:default, location:s4_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878114441','Rear Leaf Spring Assembly','upload/default.jpg','2508100-013','mechanical','AGT','default','0.00','0.00','0.00','3','2','S4','2','2_I shelf','2013-12-23 10:12:18','','barcode:113878114441, name:rear leaf spring assembly, model:2508100-013, category:mechanical, sub category:agt, color:default, location:s4_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878115393','Seat Belt Set - 3 point (Large)','upload/default.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','10','2','S4','2','2_II shelf','2013-12-23 10:13:12','','barcode:113878115393, name:seat belt set - 3 point (large), model:pkg, category:accessory, sub category:agt, color:default, location:s4_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878118605','Tie Rod Joint','upload/default.jpg','2706120-036','mechanical','AGT','default','0.00','0.00','0.00','33','0','S4','2','2_III shelf','2013-12-23 10:18:12','','barcode:113878118605, name:tie rod joint, model:2706120-036, category:mechanical, sub category:agt, color:default, location:s4_2_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878118930','Rear Brake Drum','upload/default.jpg','2802210-007','mechanical','AGT','default','0.00','0.00','0.00','6','0','S4','2','1_II Floor','2013-12-23 10:19:20','','barcode:113878118930, name:rear brake drum, model:2802210-007, category:mechanical, sub category:agt, color:default, location:s4_2_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878120248','Top Canopy Bracket - EG2028KSF/ EG2028KSZ','upload/default.jpg','5701061-037','body','AGT','default','0.00','0.00','0.00','30','0','H','4','0','2013-12-23 10:29:33','','barcode:113878120248, name:top canopy bracket - eg2028ksf/ eg2028ksz, model:5701061-037, category:body, sub category:agt, color:default, location:h_4_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878120972','Front Bracket - Normal','upload/default.jpg','5701011-039','body','AGT','default','0.00','0.00','0.00','10','0','H','2','0','2013-12-23 10:29:27','','barcode:113878120972, name:front bracket - normal, model:5701011-039, category:body, sub category:agt, color:default, location:h_2_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878122294','Top Canopy Bracket - EG2048KSF/ 2048KSZ','upload/default.jpg','5701061-040','body','AGT','default','0.00','0.00','0.00','13','0','H','1','0','2013-12-23 10:28:56','','barcode:113878122294, name:top canopy bracket - eg2048ksf/ 2048ksz, model:5701061-040, category:body, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878123216','Top Canopy Bracket - EG2068KSZ','upload/default.jpg','PKG','body','AGT','default','0.00','0.00','0.00','3','0','H','1','0','2013-12-23 10:28:42','','barcode:113878123216, name:top canopy bracket - eg2068ksz, model:pkg, category:body, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878123902','Front Bracket - EG2020ASZ','upload/default.jpg','3041-5601001','body','AGT','default','0.00','0.00','0.00','3','0','H','3','0','2013-12-23 10:28:22','','barcode:113878123902, name:front bracket - eg2020asz, model:3041-5601001, category:body, sub category:agt, color:default, location:h_3_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878261008','Shunt','upload/1388434190647.jpg','1005310-002','electrical','AGT','default','0.00','0.00','0.00','1','5','S3','1','3_I shelf','2013-12-30 15:09:52','','barcode:113878261008, name:shunt, model:1005310-002, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878263216','Main Fuse - 425A','upload/default.jpg','F26-ANL-425A','electrical','AGT','default','0.00','0.00','0.00','30','10','S3','1','3_II shelf','2013-12-24 10:28:31','','barcode:113878263216, name:main fuse - 425a, model:f26-anl-425a, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878264399','Controller Fuse','upload/default.jpg','1005410-001','electrical','AGT','default','0.00','0.00','0.00','88','20','S3','1','3_IV shelf','2013-12-23 14:22:15','','barcode:113878264399, name:controller fuse, model:1005410-001, category:electrical, sub category:agt, color:default, location:s3_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878265368','Attach Fuse socket','upload/default.jpg','1005420-001','electrical','AGT','default','0.00','0.00','0.00','30','5','S3','1','3_IV shelf','2013-12-23 14:23:06','','barcode:113878265368, name:attach fuse socket, model:1005420-001, category:electrical, sub category:agt, color:default, location:s3_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878265874','Battery Protector','upload/default.jpg','1102100-003','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','1','3_II shelf','2013-12-23 14:24:00','','barcode:113878265874, name:battery protector, model:1102100-003, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878266414','Reverse Buzzer - Truck/ Bus','upload/default.jpg','3211010-001','electrical','AGT','default','0.00','0.00','0.00','1','2','S3','1','3_I shelf','2013-12-23 14:31:03','','barcode:113878266414, name:reverse buzzer - truck/ bus, model:3211010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878269647','Reverse Buzzer - Golf','upload/default.jpg','3211010-003','electrical','AGT','default','0.00','0.00','0.00','18','5','S3','1','3_I shelf','2013-12-23 14:30:37','','barcode:113878269647, name:reverse buzzer - golf, model:3211010-003, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878270780','Fuse Box - Golf','upload/default.jpg','3308100-002','body','AGT','default','0.00','0.00','0.00','10','5','S3','1','3_II shelf','2013-12-23 14:32:07','','barcode:113878270780, name:fuse box - golf, model:3308100-002, category:body, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878271280','Electric Horn - Golf','upload/default.jpg','3004010-001','electrical','AGT','default','0.00','0.00','0.00','10','10','S3','1','3_I shelf','2014-01-02 09:44:00','','barcode:113878271280, name:electric horn - golf, model:3004010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878272184','Time-lapse Relay - Golf','upload/default.jpg','3040010-003','electrical','AGT','default','0.00','0.00','0.00','1','5','S3','1','3_V shelf','2014-01-02 09:43:55','','barcode:113878272184, name:time-lapse relay - golf, model:3040010-003, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878272791','Electronic Flasher','upload/default.jpg','3129010-002','electrical','AGT','default','0.00','0.00','0.00','11','10','S3','1','3_III shelf','2013-12-23 14:36:26','','barcode:113878272791, name:electronic flasher, model:3129010-002, category:electrical, sub category:agt, color:default, location:s3_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878273877','Auxiliary relay - 48V','upload/default.jpg','3040010-002','electrical','AGT','default','0.00','0.00','0.00','12','10','S3','1','3_III shelf','2013-12-23 14:37:41','','barcode:113878273877, name:auxiliary relay - 48v, model:3040010-002, category:electrical, sub category:agt, color:default, location:s3_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878274626','Main Fuse - 250A','upload/default.jpg','F26-ANL-250A','body','AGT','default','0.00','0.00','0.00','25','5','S3','1','3_II shelf','2014-01-02 09:43:50','','barcode:113878274626, name:main fuse - 250a, model:f26-anl-250a, category:body, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878275369','Tow/Run Switch','upload/default.jpg','3032020-001','electrical','AGT','default','0.00','0.00','0.00','17','5','S3','1','3_II shelf','2013-12-23 14:39:51','','barcode:113878275369, name:tow/run switch, model:3032020-001, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878275921','Brake Light Switch','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','18','10','S3','1','3_II shelf','2013-12-23 14:41:37','','barcode:113878275921, name:brake light switch, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878276989','Universal Start Key','upload/default.jpg','3001010-003','electrical','AGT','default','0.00','0.00','0.00','25','10','S3','1','3_III shelf','2013-12-23 14:42:40','','barcode:113878276989, name:universal start key, model:3001010-003, category:electrical, sub category:agt, color:default, location:s3_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878277615','F/R Switch','upload/default.jpg','3032010-001','electrical','AGT','default','0.00','0.00','0.00','19','10','S3','1','3_V shelf','2013-12-23 14:43:38','','barcode:113878277615, name:f/r switch, model:3032010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878278199','Power Meter - 36V','upload/default.jpg','3217010-001','electrical','AGT','default','0.00','0.00','0.00','15','10','S3','1','3_VI shelf','2014-01-02 09:43:43','','barcode:113878278199, name:power meter - 36v, model:3217010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878278718','Power Meter - 48V','upload/default.jpg','3217010-002','electrical','AGT','default','0.00','0.00','0.00','12','10','S3','1','3_VI shelf','2013-12-23 14:45:16','','barcode:113878278718, name:power meter - 48v, model:3217010-002, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878279170','Speed Sensor','upload/default.jpg','3202020-005','electrical','AGT','default','0.00','0.00','0.00','8','5','S3','1','3_V shelf','2014-01-02 09:43:33','','barcode:113878279170, name:speed sensor, model:3202020-005, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878280024','Carbon Brush - Chinese Motor','upload/1389021738119.jpg','XQ-3-4/020','electrical','AGT','default','0.00','0.00','0.00','6','2','S3','1','3_I shelf','2014-01-06 10:22:40','','barcode:113878280024, name:carbon brush - chinese motor, model:xq-3-4/020, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878280863','Carbon brush - ADC motor','upload/1389021914088.jpg','ZQS48-3.8-T/020','electrical','AGT','default','0.00','0.00','0.00','25','2','S3','1','3_I shelf','2014-01-06 10:25:37','','barcode:113878280863, name:carbon brush - adc motor, model:zqs48-3.8-t/020, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878281176','Speed sensor - ADC motor','upload/default.jpg','3202020-004','electrical','AGT','default','0.00','0.00','0.00','6','5','S3','1','3_V shelf','2013-12-23 14:49:31','','barcode:113878281176, name:speed sensor - adc motor, model:3202020-004, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878282207','Head Light Bulb - EG2028','upload/default.jpg','3117130-002','electrical','AGT','default','0.00','0.00','0.00','21','10','S3','1','3_V shelf','2013-12-23 14:50:57','','barcode:113878282207, name:head light bulb - eg2028, model:3117130-002, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878282586','Turn Light Bulb - EG2028','upload/default.jpg','3126140-003','electrical','AGT','default','0.00','0.00','0.00','21','10','S3','1','3_V shelf','2013-12-23 14:51:45','','barcode:113878282586, name:turn light bulb - eg2028, model:3126140-003, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878283060','LED light Wire - On board','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','4','2','S3','1','3_VI shelf','2013-12-23 14:53:10','','barcode:113878283060, name:led light wire - on board, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878283910','Turn light bulb - EG2020','upload/default.jpg','3109100-005','electrical','AGT','default','0.00','0.00','0.00','8','10','S3','1','3_VI shelf','2013-12-23 14:54:30','','barcode:113878283910, name:turn light bulb - eg2020, model:3109100-005, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878284719','Rear Light Bulb - Golf','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','18','10','S3','1','3_VI shelf','2013-12-23 14:56:02','','barcode:113878284719, name:rear light bulb - golf, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878285629','Reflector','upload/default.jpg','undefined','accessory','AGT','default','0.00','0.00','0.00','10','2','S3','1','3_VI shelf','2013-12-23 14:57:19','','barcode:113878285629, name:reflector, model:undefined, category:accessory, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878286445','Hi-Low Switch','upload/default.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','20','5','S3','1','3_V shelf','2013-12-23 14:58:34','','barcode:113878286445, name:hi-low switch, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878321298','Side Rear View Mirror - RH','upload/1387834072442.jpg','9002200-005','body','AGT','Silver','0.00','0.00','0.00','2','2','S2','1','5_I shelf','2013-12-23 16:27:53','','barcode:113878321298, name:side rear view mirror - rh, model:9002200-005, category:body, sub category:agt, color:silver, location:s2_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878969596','Oil Seal 32/47/8','upload/default.jpg','Undefined','body','AGT','default','0.00','0.00','0.00','40','5','S4','1','3_II shelf','2013-12-24 10:06:03','Oil Seal (1st shaft of retcuder)','barcode:113878969596, name:oil seal 32/47/8, model:undefined, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878970448','Oil Seal 50.3/43.1/9','upload/default.jpg','Undefined','body','AGT','default','0.00','0.00','0.00','20','5','S4','1','3_II shelf','2014-01-02 09:43:18','Oil Seal (Steering Knuckle)','barcode:113878970448, name:oil seal 50.3/43.1/9, model:undefined, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878972137','Oil Seal 42/55/7','upload/default.jpg','Undefined','mechanical','AGT','default','0.00','0.00','0.00','20','5','S4','1','3_II shelf','2013-12-24 10:02:25','Oil Seal (Half Shaft)','barcode:113878972137, name:oil seal 42/55/7, model:undefined, category:mechanical, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878983894','Wheel 21x11-10 CST/ Aluminum Rim F - Damaged','upload/default.jpg','PKG','tire_and_rim','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','2','0','S4','1','1_I floor','2013-12-24 10:20:41','','barcode:113878983894, name:wheel 21x11-10 cst/ aluminum rim f - damaged, model:pkg, category:tire_and_rim, sub category:club,ezgo,agt,yamaha, color:default, location:s4_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878990073','Tyre valve','upload/1388778509557.jpg','2601210-004','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','39','0','S2','1','4_III shelf','2014-01-03 14:48:30','','barcode:113878990073, name:tyre valve, model:2601210-004, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878990619','Shackle plate','upload/1388778281744.jpg','5402121-037','body','EZGO,AGT','default','0.00','0.00','0.00','19','0','S2','1','4_III shelf','2014-01-03 14:44:59','','barcode:113878990619, name:shackle plate, model:5402121-037, category:body, sub category:ezgo,agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878991309','Flip-Flop Seat Rubber Pad','upload/1388778447650.jpg','Undefined','body','AGT','default','0.00','0.00','0.00','18','0','S2','1','4_III shelf','2014-01-03 14:47:28','','barcode:113878991309, name:flip-flop seat rubber pad, model:undefined, category:body, sub category:agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878992304','Holding Block - Widshield','upload/1388778649432.jpg','5303022-011','body','AGT','default','0.00','0.00','0.00','70','0','S2','1','4_III shelf','2014-01-03 14:52:17','','barcode:113878992304, name:holding block - widshield, model:5303022-011, category:body, sub category:agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878997974','Steering Wheel Cover','upload/1388778365416.jpg','2024-2704017','body','AGT','default','0.00','0.00','0.00','5','2','S2','1','4_III shelf','2014-01-03 14:46:17','','barcode:113878997974, name:steering wheel cover, model:2024-2704017, category:body, sub category:agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113879004663','Battery - US 2200','upload/default.jpg','PKG','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','424','0','L','3-4','1','2014-01-02 09:44:31','','barcode:113879004663, name:battery - us 2200, model:pkg, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:l_3-4_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113879005228','Battery - Trojan T875','upload/default.jpg','PKG','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','28','0','L','3-4','1','2014-01-02 09:44:24','','barcode:113879005228, name:battery - trojan t875, model:pkg, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:l_3-4_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113879005492','Battery - Trojan T105','upload/default.jpg','PKG','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','232','0','L','3-4','1','2014-01-02 09:44:36','','barcode:113879005492, name:battery - trojan t105, model:pkg, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:l_3-4_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113890212526','Top Basket','upload/default.jpg','5702100-048','accessory','AGT','default','0.00','0.00','0.00','2','1','h','1','0','2014-01-06 10:16:08','','barcode:113890212526, name:top basket, model:5702100-048, category:accessory, sub category:agt, color:default, location:h_1_0');
/*!40000 ALTER TABLE `ew_part` ENABLE KEYS */;


--
-- Create Table `ew_pending`
--

DROP TABLE IF EXISTS `ew_pending`;
CREATE TABLE `ew_pending` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user` varchar(20) CHARACTER SET utf8 NOT NULL,
  `client` varchar(40) CHARACTER SET utf8 NOT NULL,
  `quantity` int(10) NOT NULL,
  `table` varchar(20) CHARACTER SET utf8 NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_pending`
--

/*!40000 ALTER TABLE `ew_pending` DISABLE KEYS */;
/*!40000 ALTER TABLE `ew_pending` ENABLE KEYS */;


--
-- Create Table `ew_relation`
--

DROP TABLE IF EXISTS `ew_relation`;
CREATE TABLE `ew_relation` (
  `rid` int(20) NOT NULL AUTO_INCREMENT,
  `main_part` varchar(20) CHARACTER SET utf8 NOT NULL,
  `attach_part` varchar(20) CHARACTER SET utf8 NOT NULL,
  `amount` int(20) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_relation`
--

/*!40000 ALTER TABLE `ew_relation` DISABLE KEYS */;
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('7','113855786227','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('8','113855773834','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('9','113855768358','113875764620','4');
/*!40000 ALTER TABLE `ew_relation` ENABLE KEYS */;


--
-- Create Table `ew_transaction`
--

DROP TABLE IF EXISTS `ew_transaction`;
CREATE TABLE `ew_transaction` (
  `tid` int(20) NOT NULL AUTO_INCREMENT COMMENT 'unique transection id',
  `user` varchar(20) NOT NULL COMMENT 'Who made this transection',
  `barcode` varchar(20) NOT NULL COMMENT 'UPC-A 12 digits barcode',
  `type` varchar(20) NOT NULL COMMENT 'Enter, pending, depart',
  `quantity` int(10) NOT NULL COMMENT 'Amount of items being trans',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Transaction time stamp',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=1049 DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_transaction`
--

/*!40000 ALTER TABLE `ew_transaction` DISABLE KEYS */;
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1','san','013849843167','car','1','2013-11-20 21:52:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('2','san','013849843596','car','1','2013-11-20 21:52:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('3','san','013849844238','car','1','2013-11-20 21:54:40');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('4','san','013849845400','car','1','2013-11-20 21:56:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('5','san','013849846414','car','1','2013-11-20 21:57:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('6','san','013849847336','car','1','2013-11-20 21:59:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('7','san','013849848035','car','1','2013-11-20 22:00:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('8','san','013849848309','car','1','2013-11-20 22:00:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('9','san','013849848727','car','1','2013-11-20 22:01:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('10','san','013849849042','car','1','2013-11-20 22:01:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('11','san','013849850219','car','1','2013-11-20 22:03:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('12','san','013849851104','car','1','2013-11-20 22:05:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('13','san','013849851341','car','1','2013-11-20 22:06:05');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('14','san','013849852101','car','1','2013-11-20 22:07:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('15','san','013849852326','car','1','2013-11-20 22:07:37');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('16','san','013849852676','car','1','2013-11-20 22:08:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('17','san','013849853196','car','1','2013-11-20 22:08:58');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('18','san','013849853756','car','1','2013-11-20 22:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('19','san','013849854322','car','1','2013-11-20 22:10:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('20','san','013849854684','car','1','2013-11-20 22:11:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('21','san','013849855695','car','1','2013-11-20 22:13:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('22','san','013849856001','car','1','2013-11-20 22:13:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('23','san','013849856394','car','1','2013-11-20 22:14:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('24','san','013849856577','car','1','2013-11-20 22:14:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('25','san','013849856801','car','1','2013-11-20 22:14:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('26','san','013849857035','car','1','2013-11-20 22:15:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('27','san','013849857340','car','1','2013-11-20 22:15:57');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('28','san','013849857778','car','1','2013-11-20 22:16:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('29','san','013849857969','car','1','2013-11-20 22:16:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('30','san','013849858260','car','1','2013-11-20 22:17:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('31','san','013849858479','car','1','2013-11-20 22:17:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('32','san','013849858782','car','1','2013-11-20 22:18:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('33','san','013849859041','car','1','2013-11-20 22:18:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('34','san','013849859323','car','1','2013-11-20 22:19:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('35','san','013849859659','car','1','2013-11-20 22:19:45');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('36','san','013849859999','car','1','2013-11-20 22:20:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('457','otto','013859994784','car','1','2013-12-02 10:54:10');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('977','otto','013859994784','car','-1','2013-12-23 16:35:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('976','san','113878321298','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('975','san','113878286445','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('974','san','113878285629','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('973','san','113878284719','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('972','san','113878283910','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('971','san','113878283060','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('970','san','113878282586','part','21','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('969','san','113878282207','part','21','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('968','san','113878281176','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('967','san','113878280863','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('966','san','113878280024','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('965','san','113878279170','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('964','san','113878278718','part','12','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('963','san','113878278199','part','15','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('962','san','113878277615','part','19','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('961','san','113878276989','part','25','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('960','san','113878275921','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('959','san','113878275369','part','17','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('958','san','113878274626','part','25','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('957','san','113878273877','part','12','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('956','san','113878272791','part','11','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('955','san','113878272184','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('954','san','113878271280','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('953','san','113878270780','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('952','san','113878269647','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('951','san','113878266414','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('950','san','113878265874','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('949','san','113878265368','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('948','san','113878264399','part','88','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('947','san','113878263216','part','29','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('946','san','113878261008','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('945','san','113878123902','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('944','san','113878123216','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('943','san','113878122294','part','13','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('942','san','113878120972','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('941','san','113878120248','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('940','san','113878118930','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('939','san','113878118605','part','33','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('938','san','113878115393','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('937','san','113878114441','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('936','san','113878113414','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('935','san','113878112939','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('934','san','113878112510','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('933','san','113878110008','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('932','san','113878109505','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('931','san','113878109179','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('930','san','113878107737','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('929','san','113878106590','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('928','san','113878106177','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('927','san','113878104955','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('926','san','113878104320','part','48','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('925','san','113878103505','part','13','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('924','san','113878103106','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('923','san','113878098067','part','48','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('922','san','113878096654','part','46','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('921','san','113878094409','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('920','san','113878093952','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('919','san','113878088998','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('918','san','113878088327','part','11','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('917','san','113878086410','part','15','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('916','san','113878082911','part','41','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('915','san','113875764620','part','500','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('914','san','113875758458','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('913','san','113875757827','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('912','san','113875757195','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('911','san','113875756594','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('910','san','113875756083','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('909','san','113875753656','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('908','san','113875752475','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('907','san','113875752178','part','19','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('906','san','113875750225','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('905','san','113875749549','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('904','san','113875746339','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('903','san','113875745490','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('902','san','113875744839','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('901','san','113875744437','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('900','san','113875742842','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('899','san','113875741899','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('898','san','113875741190','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('897','san','113875740798','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('896','san','113875735287','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('895','san','113875734794','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('894','san','113875734063','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('893','san','113875733270','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('892','san','113875732227','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('891','san','113875709563','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('890','san','113875707186','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('889','san','113875706287','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('888','san','113875705210','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('887','san','113875703804','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('886','san','113875696246','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('885','san','113875693714','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('884','san','113875689178','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('883','san','113875688937','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('882','san','113875687755','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('881','san','113875686804','part','58','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('880','san','113875685230','part','150','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('879','san','113875684999','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('878','san','113875683616','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('877','san','113875682157','part','36','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('876','san','113875628522','part','14','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('875','san','113875563935','part','147','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('874','san','113875562993','part','44','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('873','san','113875528431','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('872','san','113875527221','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('871','san','113875525170','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('870','san','113875523072','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('869','san','113875519554','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('868','san','113875518830','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('867','san','113875517870','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('866','san','113875511107','part','39','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('815','san','113874804634','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('865','san','113875510757','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('864','san','113875510340','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('863','san','113875508802','part','16','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('862','san','113875508403','part','22','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('861','san','113875507516','part','24','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('860','san','113875506994','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('859','san','113875506733','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('858','san','113875506414','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('857','san','113875505132','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('856','san','113875504357','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('855','san','113875502687','part','16','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('854','san','113875502090','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('853','san','113875499828','part','40','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('852','san','113875496561','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('851','san','113875495845','part','35','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('850','san','113875495207','part','66','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('849','san','113874880273','part','40','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('848','san','113874864521','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('847','san','113874863430','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('846','san','113874862955','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('845','san','113874862100','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('844','san','113874862027','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('843','san','113874856197','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('842','san','113874855716','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('841','san','113874855314','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('840','san','113874854618','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('839','san','113874845946','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('838','san','113874845600','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('837','san','113874844445','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('836','san','113874843531','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('835','san','113874843125','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('834','san','113874842091','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('833','san','113874841768','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('832','san','113874841056','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('831','san','113874840236','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('830','san','113874838896','part','80','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('829','san','113874835726','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('828','san','113874833776','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('827','san','113874816760','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('826','san','113874816080','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('825','san','113874815828','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('824','san','113874813410','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('823','san','113874812661','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('822','san','113874811211','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('821','san','113874809185','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('820','san','113874808788','part','14','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('819','san','113874807834','part','11','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('818','san','113874807201','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('817','san','113874806896','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('816','san','113874805471','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('814','san','113874802719','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('813','san','113874801718','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('812','san','113874701375','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('811','san','113874694562','part','100','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('810','san','113874690781','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('809','san','113874689510','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('808','san','113874688608','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('807','san','113874694069','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('806','san','113874676661','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('805','san','113874676203','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('804','san','113874669055','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('803','san','113874668190','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('802','san','113874667209','part','12','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('801','san','113874666349','part','14','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('800','san','113874665250','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('799','san','113874661256','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('798','san','113874660495','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('797','san','113874657396','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('796','san','113874033533','part','143','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('795','san','113878320669','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('794','san','113874010003','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('793','san','113874008674','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('698','otto','013878178357','car','1','2013-12-23 11:58:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('699','otto','013878179093','car','1','2013-12-23 11:58:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('700','otto','013878179678','car','1','2013-12-23 11:59:46');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('701','otto','013878181388','car','1','2013-12-23 12:02:43');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('702','otto','013878183182','car','1','2013-12-23 12:05:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('703','otto','013878248948','car','1','2013-12-23 13:55:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('704','otto','013878250105','car','1','2013-12-23 13:57:13');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('705','otto','013878250462','car','1','2013-12-23 13:57:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('706','otto','013878252345','car','1','2013-12-23 14:00:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('707','otto','013878252919','car','1','2013-12-23 14:01:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('708','otto','013878253878','car','1','2013-12-23 14:03:27');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('709','otto','013878254236','car','1','2013-12-23 14:04:13');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('710','otto','013878255184','car','1','2013-12-23 14:05:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('711','otto','013878255554','car','1','2013-12-23 14:06:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('712','otto','013878261696','car','1','2013-12-23 14:16:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('792','san','113874020209','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('791','san','113861036513','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('790','san','113861020767','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('789','san','113861020003','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('788','san','113860146106','part','24','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('718','otto','013878269189','car','1','2013-12-23 14:29:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('787','san','113860136683','part','22','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('720','otto','013878269640','car','1','2013-12-23 14:29:39');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('721','otto','013878269848','car','1','2013-12-23 14:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('722','otto','013878270074','car','1','2013-12-23 14:30:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('786','san','113860008361','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('785','san','113860007207','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('725','otto','013878271054','car','1','2013-12-23 14:32:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('784','san','113860007132','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('727','otto','013878272167','car','1','2013-12-23 14:33:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('783','san','113860005355','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('729','otto','013878272679','car','1','2013-12-23 14:34:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('730','otto','013878273016','car','1','2013-12-23 14:35:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('731','otto','013878273573','car','1','2013-12-23 14:36:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('782','san','113860002295','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('733','otto','013878273839','car','1','2013-12-23 14:36:38');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('734','otto','013878274028','car','1','2013-12-23 14:37:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('781','san','113856751895','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('736','otto','013878274540','car','1','2013-12-23 14:37:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('737','otto','013878274827','car','1','2013-12-23 14:38:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('780','san','113856751451','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('739','otto','013878275466','car','1','2013-12-23 14:39:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('779','san','113856750152','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('741','otto','013878275778','car','1','2013-12-23 14:39:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('778','san','113856732204','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('777','san','113856730198','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('776','san','113856726477','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('775','san','113856726379','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('774','san','113856724550','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('773','san','113856717210','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('772','san','113856688951','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('771','san','113856688278','part','47','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('770','san','113855795797','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('769','san','113855789397','part','62','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('768','san','113855787534','part','40','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('767','san','113855786227','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('766','san','113855768358','part','28','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('765','san','113855773834','part','28','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('764','san','113855777806','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('763','san','113855780864','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('758','otto','013878292620','car','1','2013-12-23 15:08:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('978','otto','113874838896','part','-2','2013-12-23 16:51:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('979','otto','113878103505','part','-1','2013-12-23 16:51:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('980','otto','113874880273','part','71','2013-12-23 18:42:36');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('981','otto','113875495207','part','66','2013-12-23 18:42:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('982','otto','113875496561','part','19','2013-12-23 18:45:43');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('983','otto','113875502687','part','5','2013-12-23 18:46:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('984','otto','113875502090','part','8','2013-12-23 18:47:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('985','otto','113875499828','part','2','2013-12-23 18:48:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('986','otto','113875495845','part','7','2013-12-23 18:49:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('987','otto','113874033533','part','1','2013-12-23 20:17:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('988','otto','113874838896','part','2','2013-12-23 20:27:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('989','otto','113875563935','part','1','2013-12-23 20:27:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('990','otto','113874837101','part','2','2013-12-23 20:27:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('991','otto','113878969596','part','40','2013-12-24 09:57:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('992','otto','113878970448','part','20','2013-12-24 10:00:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('993','otto','113878972137','part','20','2013-12-24 10:01:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('994','otto','113874694562','part','5','2013-12-24 10:14:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('995','otto','113878983894','part','2','2013-12-24 10:20:41');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('996','otto','113878263216','part','1','2013-12-24 10:28:31');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('997','otto','113878990073','part','0','2013-12-24 10:31:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('998','otto','113878990619','part','0','2013-12-24 10:32:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('999','otto','113878991309','part','0','2013-12-24 10:33:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1000','otto','113878992304','part','0','2013-12-24 10:34:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1001','otto','113878990619','part','17','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1002','otto','113878990073','part','39','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1003','otto','113878991309','part','18','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1004','otto','113878992304','part','59','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1005','otto','113878997974','part','4','2013-12-24 10:43:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1006','otto','113879004663','part','0','2013-12-24 10:55:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1007','otto','113879005228','part','0','2013-12-24 10:55:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1008','otto','113879005492','part','0','2013-12-24 10:56:36');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1009','otto','113855795797','part','1','2013-12-24 10:57:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1010','otto','113874694069','part','1','2013-12-24 11:02:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1011','otto','113874838896','part','1','2013-12-24 11:04:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1012','otto','113875742842','part','1','2013-12-24 11:04:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1013','otto','113879004663','part','424','2013-12-24 11:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1014','otto','113879005228','part','28','2013-12-24 11:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1015','otto','113879005492','part','232','2013-12-24 11:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1016','otto','113874809185','part','1','2013-12-24 11:17:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1017','otto','113856688278','part','2','2013-12-24 11:25:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1018','otto','113875507516','part','-2','2013-12-24 13:45:24');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1019','otto','113878992304','part','10','2013-12-24 13:47:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1020','otto ','113874010003','part','1','2013-12-30 15:38:27');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1021','otto ','113855789397','part','7','2013-12-30 15:40:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1022','otto ','113855795797','part','-1','2013-12-30 15:57:03');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1023','otto','113856688951','part','1','2014-01-02 10:44:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1024','otto','113856688951','part','-2','2014-01-02 10:58:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1025','otto ','113855786227','part','4','2014-01-02 15:03:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1026','otto ','113874666349','part','-7','2014-01-02 16:23:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1027','otto ','113874665250','part','-2','2014-01-02 16:29:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1028','otto ','113874661256','part','-2','2014-01-02 16:36:41');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1029','otto ','113874667209','part','-9','2014-01-02 16:41:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1030','otto','113874676661','part','-1','2014-01-02 16:45:24');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1031','otto ','113874676661','part','-1','2014-01-02 16:47:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1032','otto ','113874676661','part','1','2014-01-02 16:47:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1033','otto','113874694069','part','1','2014-01-03 09:52:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1034','otto','113875683616','part','-120','2014-01-03 10:11:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1035','otto','113875684999','part','28','2014-01-03 10:41:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1036','otto','113875685230','part','510','2014-01-03 11:04:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1037','otto','113875741899','part','80','2014-01-03 11:36:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1038','otto','113875742842','part','67','2014-01-03 11:41:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1039','otto','113875563935','part','2','2014-01-03 11:51:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1040','otto','113875628522','part','2','2014-01-03 13:06:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1041','otto','113878990619','part','2','2014-01-03 14:44:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1042','otto','113878997974','part','1','2014-01-03 14:46:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1043','otto','113878992304','part','1','2014-01-03 14:52:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1044','otto','113875527221','part','50','2014-01-03 15:01:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1045','otto','113875528431','part','50','2014-01-03 15:01:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1046','otto','113890212526','part','2','2014-01-06 10:16:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1047','otto ','113878280024','part','1','2014-01-06 10:22:40');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1048','otto ','113878280863','part','15','2014-01-06 10:25:37');
/*!40000 ALTER TABLE `ew_transaction` ENABLE KEYS */;


--
-- Create Table `ew_user`
--

DROP TABLE IF EXISTS `ew_user`;
CREATE TABLE `ew_user` (
  `user` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'User name',
  `pass` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'Password',
  `type` int(1) NOT NULL COMMENT '0. admin, 1.superuser, 2.user',
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_user`
--

/*!40000 ALTER TABLE `ew_user` DISABLE KEYS */;
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Allen-Cai','0000','2');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('otto','123','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Luke-Li','0000','2');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Boyao-Wang','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Otto-Lau','0000','2');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Tracy-Liu','0000','2');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Guo-Tuo','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Christal-Usiosefe','0000','1');
/*!40000 ALTER TABLE `ew_user` ENABLE KEYS */;


--
-- Create Table `transaction_view`
--

DROP VIEW IF EXISTS `transaction_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transaction_view` AS select `ew_transaction`.`tid` AS `tid`,`ew_transaction`.`user` AS `user`,`ew_transaction`.`barcode` AS `barcode`,(select `barcode_view`.`name` AS `name` from `barcode_view` where (`ew_transaction`.`barcode` = `barcode_view`.`barcode`)) AS `name`,`ew_transaction`.`type` AS `type`,`ew_transaction`.`quantity` AS `quantity`,`ew_transaction`.`time` AS `time` from `ew_transaction`;


SET FOREIGN_KEY_CHECKS=1;
-- EOB

