-- Status:16:3365:MP_0:eware:php:1.24.4::5.5.32:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|barcode_view|307|0||
-- TABLE|ec_commlog|21|9956|2014-04-11 13:09:35|MyISAM
-- TABLE|ec_company|1|4336|2014-01-06 11:28:33|MyISAM
-- TABLE|ec_contact|5|2432|2014-02-19 17:47:00|MyISAM
-- TABLE|ec_customer|21|12048|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_admin|1|2072|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_car|73|25236|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_cart|1|2092|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_log|1645|136644|2014-04-11 13:06:33|MyISAM
-- TABLE|ew_message|67|13776|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_part|234|88624|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_pending|1|2104|2014-04-11 13:09:35|MyISAM
-- TABLE|ew_relation|70|4848|2014-02-03 16:03:59|MyISAM
-- TABLE|ew_transaction|455|25540|2014-04-11 13:09:31|MyISAM
-- TABLE|ew_user|8|2244|2014-04-11 13:09:35|MyISAM
-- TABLE|transaction_view|455|0||
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-04-11 19:09

--
-- Create Table `barcode_view`
--

DROP VIEW IF EXISTS `barcode_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `barcode_view` AS select `ew_car`.`barcode` AS `barcode`,`ew_car`.`name` AS `name` from `ew_car` union all select `ew_part`.`barcode` AS `barcode`,`ew_part`.`name` AS `name` from `ew_part`;



--
-- Create Table `ec_commlog`
--

DROP TABLE IF EXISTS `ec_commlog`;
CREATE TABLE `ec_commlog` (
  `lid` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(40) CHARACTER SET utf8 NOT NULL,
  `client` varchar(20) CHARACTER SET utf8 NOT NULL,
  `title` varchar(100) CHARACTER SET utf8 NOT NULL,
  `content` text,
  `log_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `event_time` timestamp NULL DEFAULT NULL,
  `location` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `photo_url` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Data for Table `ec_commlog`
--

/*!40000 ALTER TABLE `ec_commlog` DISABLE KEYS */;
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('22','san','2','8970m benchmarks compared to 780m','Before I go buy my laptop this week, I was wondering if anyone can provide any benchmarks scores for the 8970m. I&rsquo;ve been looking at some 3dmark11, and the 8790m received a GPU score of ~6500, while the 780m was able to obtain ~8000. That&rsquo;s is a big performance gap, and seeing how well the 7970m did, I&rsquo;ve been left with some doubt that the 8970m can&rsquo;t possibly be that slow compared to its rival. So I was wondering if anyone else has any benchmarks of the 8970m proving otherwise, if so, please do post them. I wouldn&rsquo;t mind sacrificing 500 points between the 8970m and 780m to save some money.','2014-01-05 09:01:22','2014-01-06 09:00:00','AGT OFFICE','upload/1388930482234.jpg');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('23','san','2','Re: 8970m benchmarks compared to 780m','Wow this is confusing. \r\n\r\nSaw in an article that the 8970m scored nearly 8000, and according those benchmarks, how did it score below 7000?\r\n\r\nAnyways, when it comes to gaming and benchmarking performances can vary. I was wondering how far behind is the 8970m compared to the 780m when it comes to 1080p gaming on ultra settings, such as crysis 3, metro last light, and any other demanding games.','2014-01-05 09:02:04','2014-01-06 09:01:00','AGT OFFICE','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('25','san','2','780m will be 20-25% faster','I&rsquo;d throw out there that basing a purchase decision off by comparing these gpus with synthetic benchmarks is rather ridiculous. Look at game comparisons. ...unless your expressly buying the system for benchmarking in which case I have some lovely seaside property in Idaho that may interest you.\r\n\r\nPutting an 8970m even in the same category as the 780m is just wrong: it&rsquo;s like a mid-range chip vs a high-end chip. Think about it this way: you&rsquo;re essentially looking at a desktop 7870 vs a gtx 680. In games I.e. what really matters the 780m will be 20-25% faster.','2014-01-05 09:04:26','2014-01-04 09:03:00','Tesla Motor Head Office','upload/1388930666484.jpg');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('26','san','2','7970m was a fair slice slower then 680m','I&rsquo;m not 100% sure if your aware or not, so apologies if I&rsquo;m talking down to you... although we&rsquo;re fairly short on real benchmarks we can draw some conclusions based on part knowledge of various cards and prices,\r\n\r\nThe 7970m was a fair slice slower then 680m, and the 8970m is identical to the 7970m in every way bar 50mhz clock, therefore I expect it will be closer to the performance of the 7970m than the GTX 680m - forget comparing to a 780m\r\n\r\nmoving towards the GTX 780 in question here, it&rsquo;s about 25% quicker some say 30% quicker than a GTX 680m! \r\n\r\nThere have been various \"fluffly\" benchmarks online of the 8970m stating its 30% faster than a 7970m, which puts it in the same class as the 780m, but it is exactly the same hardware as the 7970m, so AMD really have to make changes to the hardware, or perform miracles to pull those figures out of the bag.\r\n\r\nI would say wait until the 8970m is actually out if your in any doubt, then check actual hard in game evidence in the games you specifically want to play, as AMD pull ahead in certain games, and Nvidia in others so it&rsquo;s as much as question of what you play.\r\n\r\nAlso until official prices come out, we won&rsquo;t know how much value for money the 8970m is, if it&rsquo;s equal to the 770m, its a fair competitor (to the 770m - as I expect it to perform on this level) if it&rsquo;s any cheaper than the 770m, then it&rsquo;s a winner in my book. If it&rsquo;s going to cost the same as the 780m, it needs to prove why 1st hand in the flash with the various reviewers out there','2014-01-05 09:05:59','2013-12-05 09:05:00','Anywhere','upload/1388930759656.jpg');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('27','san','2','950/1250 8970m','950/1250 8970m\r\n\r\nAMD Radeon HD 8970M video card benchmark result - Intel(R) Core(TM) i7-4900MQ CPU @ 2.80GHz,Terrans Force X511\r\n\r\nAMD Radeon HD 8970M video card benchmark result - Intel Core i7-3615QM Processor,Terrans Force X711EM\r\n\r\nWe know that GTX 780M is 32% faster than 7970M in games.\r\n\r\n8970M is 6% faster than 7970M (900MHz vs 850MHz)\r\n\r\n7970M as baseline (100FPS)\r\n\r\nGTX780M:\r\n100FPS x 1.32 = 132FPS\r\n\r\n8970M\r\n100FPS x 1.06 = 106FPS\r\n\r\nGTX 780M is 25% faster than 8970M','2014-01-05 09:08:12','2014-02-05 09:07:00','office','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('29','san','2','WYSIWYG editor for websites','NicEdit is a WYSIWYG editor for websites. Its goal is to be as simple and fast as possible for users of your application. NicEdit is extremely lightweight and can be easily integrated in any site with minimal impact while providing visitors an effective means to express themselves in rich text.','2014-01-06 10:15:01','2014-01-06 11:14:00','Tesla moter head office','upload/1389021301250.jpg');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('33','san','2','WHAT THIS GOLF COURSE SAYS','Since 1997, Golf Dorval has been offering the Quebec and the Royal Canadian Golf Associationâ€™s handicap card, as well as the \"Future Links\" training program for youth aged 7 to 12. In 1998, the millionth golfer set foot on the first tee. Golf Dorval was granted the magazine Golf Internationalâ€™s award for excellence in the category \"quality for price.\" - See more at: http://scoregolf.com/golf-dorval-dorval-quebec-canada#sthash.3KYqChSY.dpuf','2014-01-06 13:37:57','2014-01-08 19:36:00','agt office','upload/1389033477416.jpg');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('35','Boyao-Wang','9','Meeting with Ryan','Meeting with Ryan and his new sale manager in their office. Bring a Hulk with off-road tires on it.','2014-01-08 10:45:25','2014-01-15 11:00:00','Bennett Office','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('36','Boyao-Wang','8','Meeting with Jeff','Meeting with Jeff, discuss the City of Ajax tender and new commission plan for Jeff.','2014-01-08 10:47:23','2014-01-09 08:45:00','Albion Office','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('34','Boyao-Wang','8','Ajax City Tender Deadline','I have contacted Jeff and ask him to follow up the city tender for electric UTV, he is going to follow up and give me feedback this week. The tender deadline is Jan 14th 2014.','2014-01-06 14:07:43','2014-01-14 09:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('37','Otto-Lau','17','New Truck','I have to follow up with David for the shipping status of the new truck.','2014-01-08 11:09:57','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('38','Boyao-Wang','19','Dealership','They want us to contact them again around end of Feb, confirm the details of dealership agreement new price and delivery date. They said they are willing to buy 1 hobbit2+2 Black 1 Nomad Red, and we are going to give them 1 orange ramble and 1 sliver Hobbit 4+2. ','2014-01-13 13:14:33','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('39','Boyao-Wang','20','Agro 14','Roger from seaspan is testing one of our agro 14 bus in Vancouver now. he is willing to buy 5 of them. we need to follow up with him.','2014-01-23 16:38:49','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('40','Boyao-Wang','20','Hobbit 2H01','Vera Tatko from difference office of seaspan Vancouver is asking price of 3 hobbit 2H01. I have email her the price and spec list, waiting for the answer now.','2014-01-23 16:40:38','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('41','otto-lau','4','27/01/2014 Visiting','Topics Discussed:\r\n\r\nElectric Bike - \r\nMike may come to our office on next Wednesday to look at the New Arrival Bike.\r\n\r\nOpen House Event Planning - \r\nIn the month of MAY would be a good time to host open house event with Birdie Golf Cart\r\n\r\nOutstanding Balance Collecting Attempts - \r\nContact Mike by next Tuesday to follow up.','2014-01-30 09:50:27','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('42','otto-lau','11','27/01/2014 Visiting','Topics Discussed:\r\n\r\nOpen House Event - AGT is welcomed to join their open house event which will be held at the end of March/ beginning of April. (Same day with Duke)\r\n\r\nUpcoming Inventory planning - Glenn said that he has been working on his inventory planning for next up coming season, order requests will be placed if carts are needed from AGT.','2014-01-30 09:55:27','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('43','otto-lau','21','28/01/2014 Phone Call','Ron, the owner, shows no interest in golf cart nor off road cart. However, our new electric bike sparks his curiosity. Otterville shop is currently closed, will be re-open in late Feb or March.','2014-01-30 10:24:09','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('44','Boyao-Wang','8','Jeff Meeting','Take a 2028-windshield, 20 catalogs ','2014-02-03 14:41:54','2014-02-04 11:00:00','Albion Office','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('45','Boyao-Wang','19','Price List','personal email abi@abibaba.ca before delivery on April 1st. ','2014-03-03 14:54:00','0000-00-00 00:00:00','','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('46','Boyao-Wang','19','Delivery and meeting','Deliver the 4 cars they have ordered, and meet with Abi and his sales manager. ','2014-03-25 14:06:18','2014-04-04 14:00:00','Abibaba','');
INSERT INTO `ec_commlog` (`lid`,`user`,`client`,`title`,`content`,`log_time`,`event_time`,`location`,`photo_url`) VALUES ('47','Boyao-Wang','9','Pick up time for red 6+2 and Hulk','Ryan wants to pick up the red 6+2 and Hulk around April 23rd 2014','2014-04-02 14:50:25','0000-00-00 00:00:00','','');
/*!40000 ALTER TABLE `ec_commlog` ENABLE KEYS */;


--
-- Create Table `ec_company`
--

DROP TABLE IF EXISTS `ec_company`;
CREATE TABLE `ec_company` (
  `name` varchar(80) CHARACTER SET utf8 NOT NULL,
  `slogan` varchar(100) CHARACTER SET utf8 NOT NULL,
  `tax_number` varchar(40) CHARACTER SET utf8 NOT NULL,
  `address1` varchar(100) CHARACTER SET utf8 NOT NULL,
  `address2` varchar(100) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fax` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(80) CHARACTER SET utf8 NOT NULL,
  `web` varchar(40) CHARACTER SET utf8 NOT NULL,
  `logo_url` varchar(40) CHARACTER SET utf8 NOT NULL,
  `tax_rate` decimal(4,2) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ec_company`
--

/*!40000 ALTER TABLE `ec_company` DISABLE KEYS */;
INSERT INTO `ec_company` (`name`,`slogan`,`tax_number`,`address1`,`address2`,`phone`,`fax`,`email`,`web`,`logo_url`,`tax_rate`) VALUES ('AGT Electric Cars','Our parent company can benefit all mankind.','82270 4896 RT0001','1185 Corporate Drive, Unit #2','Burlington, Ontario, Canada L7L 5V5','1-905-331-0491','1-905-331-3504','info@agtecars.com','www.agtecars.com','images/companylogo.png','0.13');
/*!40000 ALTER TABLE `ec_company` ENABLE KEYS */;


--
-- Create Table `ec_contact`
--

DROP TABLE IF EXISTS `ec_contact`;
CREATE TABLE `ec_contact` (
  `contact_id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 NOT NULL,
  `title` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(80) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Data for Table `ec_contact`
--

/*!40000 ALTER TABLE `ec_contact` DISABLE KEYS */;
INSERT INTO `ec_contact` (`contact_id`,`cid`,`name`,`title`,`phone`,`email`) VALUES ('7','2','Boyao Wang','Sales Manager','6473386589','boyaowang@hotmail.com');
INSERT INTO `ec_contact` (`contact_id`,`cid`,`name`,`title`,`phone`,`email`) VALUES ('6','2','Sam','Software Designer','9059025341','sam@9876.ca');
INSERT INTO `ec_contact` (`contact_id`,`cid`,`name`,`title`,`phone`,`email`) VALUES ('8','8','Bill Harris','Shipping & Parts','905-815-3591','bill@albiongolfcars.com');
INSERT INTO `ec_contact` (`contact_id`,`cid`,`name`,`title`,`phone`,`email`) VALUES ('9','8','Kelly Hooper','Office Manager &Accountant','416-737-6455','Kelly@albiongolfcars.com');
INSERT INTO `ec_contact` (`contact_id`,`cid`,`name`,`title`,`phone`,`email`) VALUES ('10','8','Peter Butler','Vice -President','647-272-4386','peter@albiongolfcars.com');
/*!40000 ALTER TABLE `ec_contact` ENABLE KEYS */;


--
-- Create Table `ec_customer`
--

DROP TABLE IF EXISTS `ec_customer`;
CREATE TABLE `ec_customer` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `logo_url` varchar(40) CHARACTER SET utf8 NOT NULL DEFAULT 'upload/defaultlogo.jpg',
  `name` varchar(100) CHARACTER SET utf8 NOT NULL,
  `contact` varchar(40) CHARACTER SET utf8 NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8 NOT NULL,
  `fax` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(80) CHARACTER SET utf8 DEFAULT NULL,
  `web` varchar(80) CHARACTER SET utf8 DEFAULT NULL,
  `address1` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address2` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `des` text CHARACTER SET utf8,
  `interact` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `type` varchar(20) CHARACTER SET utf8 NOT NULL,
  `status` varchar(20) CHARACTER SET utf8 NOT NULL,
  `xsearch` text CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Data for Table `ec_customer`
--

/*!40000 ALTER TABLE `ec_customer` DISABLE KEYS */;
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('2','upload/1387533447466.png','AGT Electric Cars','Reception','9053310491','9053313504','info@agtecars.com','www.agtecars.com','1185 Corporate Drive, Unit #2,','Burlington, Ontario, Canada, L7L 5V5','Home Company','2014-01-06 13:37:57','partner','potential','company:agt electric cars, type:partner, status:potential, contact:reception, phone:9053310491, fax:9053313504, web:www.agtecars.com, email:info@agtecars.com , address:1185 corporate drive, unit #2, burlington, ontario, canada, l7l 5v5');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('3','upload/defaultlogo.jpg','Armada Golf Cars','Bill Heaps','9057133525','9057133526','armadacorp@bellnet.ca','www.armadagolfcars.ca','36 Industrial Parkway South,','Aurora, Ontario, Canada L4G 3W2','Bill Heaps(President)','2014-01-06 11:13:41','dealer','existing','company:armada golf cars, type:dealer, status:existing, contact:bill heaps, phone:9057133525, fax:9057133526, web:www.armadagolfcars.ca, email:armadacorp@bellnet.ca , address:36 industrial parkway south, aurora, ontario, canada l4g 3w2');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('4','upload/defaultlogo.jpg','Birdie Golf Cart','Mike Macdonald','9058943113','9058949985','mike@birdiegolfcarts.com','www.birdiegolfcarts.com','4915 Ontario #3','Ridgeway, Ontario, Canada, L0S 1N0','','2014-01-30 09:50:27','dealer','existing','company:birdie golf cart, type:dealer, status:existing, contact:mike macdonald, phone:9058943113, fax:9058949985, web:www.birdiegolfcarts.com, email:mike@birdiegolfcarts.com , address:4915 ontario #3 ridgeway, ontario, canada, l0s 1n0');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('5','upload/defaultlogo.jpg','Calgary Golf Cart Centre','Kelly Gurnsey','4032795025','4032034233','calgarygolfcar@rogers.com','www.calgarygolfcentre.com','Bay 7, 4115 - 64th Avenue S.E.,','Calgary, Alberta, Canada, T2C 2C8','','2013-12-20 05:40:06','dealer','existing','company:calgary golf cart centre, type:dealer, status:existing, contact:kelly gurnsey, phone:4032795025, fax:4032034233, web:www.calgarygolfcentre.com, email:calgarygolfcar@rogers.com , address:bay 7, 4115 - 64th avenue s.e., calgary, alberta, t2c 2c8');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('6','upload/defaultlogo.jpg','Canadian Cart Sales','Perry Stover','5193492300','5193492221','perrys@turfcare.ca','www.canadiancartsales.com','P.O Box 159, 4 Given Road,','St. Marys, Ontario, Canada, N4X 1B1','','2014-01-05 02:59:42','dealer','existing','company:canadian cart sales, type:dealer, status:existing, contact:perry stover, phone:5193492300, fax:5193492221, web:www.canadiancartsales.com, email:perrys@turfcare.ca , address:p.o box 159, 4 given road, st. marys, ontario, n4x 1b1');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('7','upload/defaultlogo.jpg','Cart Guy','Chris/Jamie/Kim','18889052278','18663532278','sales@cartguy.ca','www.cartguy.ca','2933 Hwy #35 S., Box 105,','Lindsay, Ontario, Canada, K9V 4R4','Chris (President & Sales)\r\nJamie (President & Repair & Parts) Jamie@cartguy.ca\r\nKim (Accountant)	\r\n','2014-01-06 11:22:12','dealer','existing','company:cart guy, type:dealer, status:existing, contact:chris/jamie/kim, phone:18889052278, fax:18663532278, web:www.cartguy.ca, email:sales@cartguy.ca , address:2933 hwy #35 s., box 105, lindsay, ontario, canada, k9v 4r4');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('8','upload/defaultlogo.jpg','Albion Golf Cars','Bill Harris',' 4162361001',' 4162364654','bill@albiongolfcars.com','www.albiongolfcars.com','29 Advance Road, Toronto,','Ontario, Canada M8Z 2S6','','2014-02-19 16:47:03','dealer','existing','company:albion golf cars, type:dealer, status:existing, contact:bill harris, phone: 4162361001, fax: 4162364654, web:www.albiongolfcars.com, email:bill@albiongolfcars.com , address:29 advance road, toronto, ontario, canada m8z 2s6');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('22','upload/defaultlogo.jpg','Scottcitywheels','Dan','5193511870','','scottcitywheels@outlook.com','www.scottcityfun.com','','','want to be our dealer','2014-03-12 13:53:25','dealer','potential','company:scottcitywheels, type:dealer, status:potential, contact:dan, phone:5193511870, fax:, web:www.scottcityfun.com, email:scottcitywheels@outlook.com , address: ');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('9','upload/defaultlogo.jpg','Bennett Golf Carts','Ryan McCutcheon','905-640-7822','905-640-7820','Ryan@bennettgolfcars.ca','www.bennettgolfcars.ca','4 Paisley Lane, Stoufville-Uxbridge,','Ontario, Canada L4A 7X4','Ryan McCutcheon (President)	416-706-7895	Ryan@bennettgolfcars.ca\r\nNeil (Parts and sales)		\r\n','2014-04-02 14:50:25','dealer','existing','company:bennett golf carts, type:dealer, status:existing, contact:ryan mccutcheon, phone:905-640-7822, fax:905-640-7820, web:www.bennettgolfcars.ca, email:ryan@bennettgolfcars.ca , address:4 paisley lane, stoufville-uxbridge, ontario, canada l4a 7x4');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('10','upload/defaultlogo.jpg','Classic Carts ','Division Frank Machan','5197850956','5197852157','frank@classiccarts.biz','www.classiccarts.biz','12678 Furnival Road, Rodney,','Ontario, Canada,  N0L 2C0','Classic Carts (1079245 On Ltd) Division Frank Machan (President)	cell 519-902-9761\r\n	\r\n','2014-01-06 11:27:54','dealer','existing','company:classic carts , type:dealer, status:existing, contact:division frank machan, phone:5197850956, fax:5197852157, web:www.classiccarts.biz, email:frank@classiccarts.biz , address:12678 furnival road, rodney, ontario, canada,  n0l 2c0');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('11','upload/defaultlogo.jpg','Skyway Lawn Equipment Ltd','Glenn Burgess','9056622663','9056622253','gburgess@skywaygroup.ca','www.skywaygroup.ca','154 Upper Centennial Pkwy. Stoney Creek,','Ontario, Canada,  L8J 2T7','Glenn Burgess (President)	905-971-6573	gburgess@skywaygroup.ca\r\nKevin Ottman (Salesman)	519-212-1327	kottman@skywaygroup.ca\r\n','2014-01-30 09:55:27','dealer','existing','company:skyway lawn equipment ltd, type:dealer, status:existing, contact:glenn burgess, phone:9056622663, fax:9056622253, web:www.skywaygroup.ca, email:gburgess@skywaygroup.ca , address:154 upper centennial pkwy. stoney creek, ontario, canada,  l8j 2t7');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('12','upload/defaultlogo.jpg','Tilbury Auto Sales &RV','Lindsay Belanger','5196822407','5196822683','lindsay@tilburyautosales.com','www.tilburyautosales.com','20600 County Road 42, Tilbury','Ontario, Canada, N0P 2L0','Lindsay Belanger (President)	519-360-6163	\r\n		\r\n','2014-01-06 11:37:33','dealer','existing','company:tilbury auto sales &rv, type:dealer, status:existing, contact:lindsay belanger, phone:5196822407, fax:5196822683, web:www.tilburyautosales.com, email:lindsay@tilburyautosales.com , address:20600 county road 42, tilbury ontario, canada, n0p 2l0');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('13','upload/defaultlogo.jpg','Wayne Morrow Auto','Kevin Morrow','18774427162','','kevin.morrow@bellnet.ca','www.morrowauto.ca','359 Franktown Rd, Carleton Place,','Ontario, Canada,  K7C 2N4','Kevin Morrow (President) cell 613-257-1919	\r\n		\r\n','2014-01-06 11:41:32','dealer','existing','company:wayne morrow auto, type:dealer, status:existing, contact:kevin morrow, phone:18774427162, fax:, web:www.morrowauto.ca, email:kevin.morrow@bellnet.ca , address:359 franktown rd, carleton place, ontario, canada,  k7c 2n4');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('14','upload/defaultlogo.jpg','Webster Beacon','John Webster','5196762288','5196765160','beacon@vianet.ca','','2588-1 35 Hwy, Dwight,','Ontario, Canada, P0A1H0','John Webster (President)	cell 519-350-7993		\r\n','2014-01-06 11:46:07','dealer','existing','company:webster beacon, type:dealer, status:existing, contact:john webster, phone:5196762288, fax:5196765160, web:, email:beacon@vianet.ca , address:2588-1 35 hwy, dwight, ontario, canada, p0a1h0');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('15','upload/defaultlogo.jpg','Diabo Auto Wholesale','Robert','4506389009','','kimberleythompson@sympatico.ca','www.diabo.ca','Route 138, Khanata Plaza','Quebec, Canada, J0L 1B0','Chad (Vice President)	cell 514-444-4373	\r\nRobert (President) cell 514-231-5542	\r\n','2014-01-06 11:50:09','dealer','existing','company:diabo auto wholesale, type:dealer, status:existing, contact:robert, phone:4506389009, fax:, web:www.diabo.ca, email:kimberleythompson@sympatico.ca , address:route 138, khanata plaza quebec, canada, j0l 1b0');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('16','upload/defaultlogo.jpg','Golf Car Quebec','Martin Murphy','5146313775','5196470200','martinmurphy@sympatico.ca','','165 Ave Lake, Dorval,','Quebec, Canada, H9S 2J2','Martin Murphy (President)	cell 514-500-3012\r\n	\r\n','2014-01-06 11:56:21','dealer','existing','company:golf car quebec, type:dealer, status:existing, contact:martin murphy, phone:5146313775, fax:5196470200, web:, email:martinmurphy@sympatico.ca , address:165 ave lake, dorval, quebec, canada, h9s 2j2');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('17','upload/defaultlogo.jpg','Real East Import','David Gylland','902-468-8255','902-468-7266','davidgylland@hotmail.com','www.realeastimports.com','30 Crooked stick pass, Beaver Bank,','Nova Scotia, Canada, B4G 1G9','David Gylland (President)	cell 902-229-9104','2014-01-08 11:09:57','dealer','existing','company:real east import, type:dealer, status:existing, contact:david gylland, phone:902-468-8255, fax:902-468-7266, web:www.realeastimports.com, email:davidgylland@hotmail.com , address:30 crooked stick pass, beaver bank, nova scotia, canada, b4g 1g9');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('18','upload/defaultlogo.jpg','Trailer Trash Toyz','Ricky','7059371411','','trailertrashtoyz@gmail.com','www.trailertrashtoyz.com','2241 Old Fort Road Midland,','Ontario, Canada','Ricky (President)	cell 705-937-1411	\r\nBobby (Vice President)	cell 705-529-4552	\r\n','2014-01-06 12:02:36','dealer','existing','company:trailer trash toyz, type:dealer, status:existing, contact:ricky, phone:7059371411, fax:, web:www.trailertrashtoyz.com, email:trailertrashtoyz@gmail.com , address:2241 old fort road midland, ontario, canada');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('19','upload/defaultlogo.jpg','Abibaba Wholesale Inc.','Abi','19056690305','','sales@abibaba.ca','','17315 Yonge Str.','Newmarket, Ontario L3Y 7R5','','2014-03-25 14:06:18','dealer','potential','company:abibaba wholesale inc., type:dealer, status:potential, contact:abi, phone:19056690305, fax:, web:, email:sales@abibaba.ca , address:17315 yonge str. newmarket, ontario l3y 7r5');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('20','upload/defaultlogo.jpg','Seaspan Ferries','Todd Roger, Vera Tatko','6049407239','6049841613','rtodd@seaspan.com','www.seaspan.com',' 7700 Hopcott Rd,','Delta, BC V4G 1B6','','2014-02-10 15:53:31','enterprise','potential','company:seaspan ferries, type:enterprise, status:potential, contact:todd roger, vera tatko, phone:6049407239, fax:6049841613, web:www.seaspan.com, email:rtodd@seaspan.com , address: 7700 hopcott rd, delta, bc v4g 1b6');
INSERT INTO `ec_customer` (`cid`,`logo_url`,`name`,`contact`,`phone`,`fax`,`email`,`web`,`address1`,`address2`,`des`,`interact`,`type`,`status`,`xsearch`) VALUES ('21','upload/defaultlogo.jpg','Otterville Custom Golf Carts','Ron','519-468-3617','','info@ottervillecustomgolfcarts.com','ottervillecustomgolfcarts.com','92 North St. East ','Otterville Ontario N0J 1R0 ','First Approach was back in 2013, in April.\r\nHad one time visit in 2013.\r\nBack and forth phone calls after visit, but no major achievement. ','2014-02-19 16:56:51','dealer','potential','company:otterville custom golf carts, type:dealer, status:potential, contact:ron, phone:519-468-3617, fax:, web:ottervillecustomgolfcarts.com, email:info@ottervillecustomgolfcarts.com , address:92 north st. east  otterville ontario n0j 1r0 ');
/*!40000 ALTER TABLE `ec_customer` ENABLE KEYS */;


--
-- Create Table `ew_admin`
--

DROP TABLE IF EXISTS `ew_admin`;
CREATE TABLE `ew_admin` (
  `user` varchar(40) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(40) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_admin`
--

/*!40000 ALTER TABLE `ew_admin` DISABLE KEYS */;
INSERT INTO `ew_admin` (`user`,`pass`) VALUES ('admin','agtEcars222');
/*!40000 ALTER TABLE `ew_admin` ENABLE KEYS */;


--
-- Create Table `ew_car`
--

DROP TABLE IF EXISTS `ew_car`;
CREATE TABLE `ew_car` (
  `barcode` varchar(20) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT 'Name of the car',
  `photo_url` varchar(200) DEFAULT 'upload\\default.jpg' COMMENT 'Photo URL',
  `model` varchar(40) NOT NULL COMMENT 'Model of the car',
  `vin` varchar(40) DEFAULT NULL,
  `year` int(10) NOT NULL DEFAULT '2013',
  `category` varchar(20) NOT NULL COMMENT 'Finished/Semi finished',
  `color` varchar(20) DEFAULT NULL COMMENT 'The color of product',
  `condition` varchar(20) NOT NULL COMMENT 'New, used, demo, damaged',
  `p_price` decimal(10,2) NOT NULL COMMENT 'Purchase price',
  `w_price` decimal(10,2) NOT NULL COMMENT 'Wholesale price',
  `r_price` decimal(10,2) NOT NULL COMMENT 'Retail price',
  `quantity` int(10) NOT NULL COMMENT 'Amount in stock',
  `w_quantity` int(10) NOT NULL COMMENT 'Warning if in stock less than this amount',
  `l_zone` varchar(20) DEFAULT NULL COMMENT 'Location zone',
  `l_column` varchar(20) DEFAULT NULL COMMENT 'Location column',
  `l_level` varchar(20) DEFAULT NULL COMMENT 'Location level',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Latest update date',
  `des` text COMMENT 'Description of item',
  `xsearch` text NOT NULL COMMENT 'name,barcode,model,category,color,location,condition',
  PRIMARY KEY (`barcode`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_car`
--

/*!40000 ALTER TABLE `ew_car` DISABLE KEYS */;
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849843167','KERNEL','upload/1387564421160.jpg','EG6020X','Null','2013','finish','orange','new','0.00','10999.00','13999.00','1','5','n','1','1','2013-12-20 13:33:42','										','barcode:013849843167, name:kernel, model:eg6020x, category:finish, color:orange, location:n_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849843596','HULK','upload/1387814466567.jpg','EG6020A4D','Null','2013','finish','camo','new','0.00','9850.00','12999.00','0','0','n','1','1','2014-01-15 09:50:45','Delivery to Bennett Golf Carts as a demo on Jan 14th 2014.','barcode:013849843596, name:hulk, model:eg6020a4d, category:finish, color:camo, location:n_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849844238','HOBBIT 4+2 Customize','upload/1387564555098.jpg','EG2048KSZ','Null','2013','finish','blue','new','0.00','5750.00','7699.00','1','0','n','1','1','2013-12-20 13:35:56','No Cover','barcode:013849844238, name:hobbit 4+2 customize, model:eg2048ksz, category:finish, color:blue, location:n_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849845400','Motorcycle','upload/1387564515817.jpg','Customize','123','2013','finish','white','damaged','0.00','0.00','0.00','1','0','n','1','1','2013-12-20 13:35:16','no battery','barcode:013849845400, name:motorcycle, model:customize, category:finish, color:white, location:n_1_1, condition:damaged, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849846414','QUANTUM Customize','upload/1387564287707.jpg','EG6043K01','Null','2013','finish','white','new','0.00','8499.00','10999.00','1','0','c','1','1','2013-12-20 13:31:28','This car is sealed.','barcode:013849846414, name:quantum customize, model:eg6043k01, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849847336','Garbage Truck','upload/1387563015035.jpg','Customize','Undefined ','2013','finish','green','new','0.00','0.00','0.00','1','0','c','1','1','2013-12-20 13:10:16','','barcode:013849847336, name:garbage truck, model:customize, category:finish, color:green, location:c_1_1, condition:new, year:2013, vin:undefined ');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848035','ARGO 14','upload/1387564596238.jpg','EG6158K01','Null','2013','finish','black','new','0.00','13599.00','17999.00','1','0','c','1','1','2013-12-20 13:36:37','','barcode:013849848035, name:argo 14, model:eg6158k01, category:finish, color:black, location:c_1_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848309','ARGO 14','upload/1387564626801.jpg','EG6158K01','L4F65BZK2C0030018','2013','finish','white','new','0.00','13599.00','17999.00','0','0','c','1','1','2014-02-12 11:33:40','','barcode:013849848309, name:argo 14, model:eg6158k01, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:l4f65bzk2c0030018');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848727','HOBBIT 2+2 Ambulance','upload/1387563091145.jpg','EG2028KSZ01','Undefine','2013','finish','red','new','0.00','4599.00','6199.00','1','0','c','2','1','2013-12-20 13:11:32','','barcode:013849848727, name:hobbit 2+2 ambulance, model:eg2028ksz01, category:finish, color:red, location:c_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849849042','HOBBIT 6+2','upload/1387564742801.jpg','EG2068KSZ','Null','2013','finish','red','new','0.00','6999.00','9150.00','1','0','c','2','1','2013-12-20 13:39:03','','barcode:013849849042, name:hobbit 6+2, model:eg2068ksz, category:finish, color:red, location:c_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849850219','HOBBIT 6+2','upload/1387564697738.jpg','EG2068KSZ','Null','2013','finish','silver','demo','0.00','6999.00','9150.00','1','0','c','2','1','2013-12-20 13:38:18','','barcode:013849850219, name:hobbit 6+2, model:eg2068ksz, category:finish, color:silver, location:c_2_1, condition:demo, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849851104','HOBBIT 4+2','upload/1387564952770.jpg','EG2048KSZ','Null','2013','finish','green','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-12-20 13:42:33','','barcode:013849851104, name:hobbit 4+2, model:eg2048ksz, category:finish, color:green, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849851341','HOBBIT 4+2','upload/1387564901957.jpg','EG2048KSZ','Null','2013','finish','black','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-12-20 13:41:42','										','barcode:013849851341, name:hobbit 4+2, model:eg2048ksz, category:finish, color:black, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852101','RAMBLER','upload/1387565717598.jpg','EG2040ASZ','123','2013','finish','black','damaged','0.00','6199.00','8299.00','0','0','c','4','1','2014-03-21 15:23:44','','barcode:013849852101, name:rambler, model:eg2040asz, category:finish, color:black, location:c_4_1, condition:damaged, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852326','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','semi','silver','new','0.00','5950.00','7499.00','1','0','c','4','1','2013-11-20 17:08:14','','barcode:013849852326, name:nomad, model:eg2020asz, category:semi, color:silver, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852676','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','semi','gold','new','0.00','5950.00','7499.00','1','0','c','4','1','2013-11-20 17:08:04','','barcode:013849852676, name:nomad, model:eg2020asz, category:semi, color:gold, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849853196','CRICKET 2','upload/1387565083332.jpg','EG2028K','Null','2013','semi','white','demo','0.00','4299.00','5799.00','1','0','c','5','1','2013-12-20 13:44:44','','barcode:013849853196, name:cricket 2, model:eg2028k, category:semi, color:white, location:c_5_1, condition:demo, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849853756','HOBBIT 2+2','upload/1387565205926.jpg','EG2028KSZ01','L4F2558K0D005010','2013','semi','black','new','0.00','4599.00','6199.00','0','0','s','1','1','2014-04-09 15:42:42','sold to Albion','barcode:013849853756, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:black, location:s_1_1, condition:new, year:2013, vin:l4f2558k0d005010');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849854322','HOBBIT 4+2','upload/1387565013754.jpg','EG2048KSZ','Null','2013','finish','black','new','0.00','5750.00','7699.00','1','0','s','2','1','2013-12-20 13:43:34','','barcode:013849854322, name:hobbit 4+2, model:eg2048ksz, category:finish, color:black, location:s_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849854684','QUANTUM Customize','upload/1387564353160.jpg','EG6043K01','Null','2013','finish','white','new','0.00','8499.00','10999.00','1','0','s','2','1','2013-12-20 13:32:34','This car has a cargo box~','barcode:013849854684, name:quantum customize, model:eg6043k01, category:finish, color:white, location:s_2_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849855695','CRICKET 2','upload/1387565153395.jpg','EG2028K','Null','2013','semi','green','used','0.00','4299.00','5799.00','1','0','e','6','1','2013-12-20 13:45:54','','barcode:013849855695, name:cricket 2, model:eg2028k, category:semi, color:green, location:e_6_1, condition:used, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856001','NOMAD','upload/1387565301223.jpg','EG2020ASZ','Null','2013','finish','black','new','0.00','5950.00','7499.00','1','0','e','5','1','2013-12-20 13:48:22','','barcode:013849856001, name:nomad, model:eg2020asz, category:finish, color:black, location:e_5_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856394','CRICKET 2','upload/sample/cricket2.jpg','EG2028K',NULL,'2013','finish','red','new','0.00','4299.00','5799.00','0','0','e','5','1','2014-02-04 14:27:28','','barcode:013849856394, name:cricket 2, model:eg2028k, category:finish, color:red, location:e_5_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856577','NOMAD','upload/1387565390020.jpg','EG2020ASZ','Null','2013','finish','black','new','0.00','5950.00','7499.00','1','0','c','5','1','2013-12-20 13:49:51','','barcode:013849856577, name:nomad, model:eg2020asz, category:finish, color:black, location:c_5_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856801','NUCLEUS','upload/1387565761363.jpg','EG6021H','Null','2013','finish','orange','new','0.00','7199.00','9599.00','1','0','c','4','1','2013-12-20 13:56:02','','barcode:013849856801, name:nucleus, model:eg6021h, category:finish, color:orange, location:c_4_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857035','HOBBIT 2+2','upload/1387565666192.jpg','EG2028KSZ01','L4F2558K7D0080009','2013','finish','black','new','0.00','4599.00','6199.00','0','0','e','4','1','2014-04-04 10:51:34','Lossing bolt on left front hub. Repaired. sold to Cart guy','barcode:013849857035, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:e_4_1, condition:new, year:2013, vin:l4f2558k7d0080009');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857340','HOBBIT 2+2','upload/1387565575863.jpg','EG2028KSZ01','L4F2558K0B0070130','2013','finish','red','damaged','0.00','4599.00','6199.00','1','0','c','3','1','2014-04-01 16:33:12','Rear pass side scratch','barcode:013849857340, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:red, location:c_3_1, condition:damaged, year:2013, vin:l4f2558k0b0070130');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857778','HOBBIT 4+2','upload/1387563476723.jpg','EG2048KSZ','123','2013','finish','green','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-12-20 13:17:57','','barcode:013849857778, name:hobbit 4+2, model:eg2048ksz, category:finish, color:green, location:c_3_1, condition:new, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857969','HOBBIT 2+2','upload/1387565605895.jpg','EG2028KSZ01','Null','2013','finish','green','new','0.00','4599.00','6199.00','1','0','c','3','1','2013-12-20 13:53:26','','barcode:013849857969, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:green, location:c_3_1, condition:new, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858260','NOMAD','upload/1387565348410.jpg','EG2020ASZ','L4F2550AXC0030013','2013','finish','red','new','0.00','5950.00','7499.00','0','0','c','2','1','2014-04-09 11:39:54','','barcode:013849858260, name:nomad, model:eg2020asz, category:finish, color:red, location:c_2_1, condition:new, year:2013, vin:l4f2550axc0030013');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858479','HOBBIT 2+2','upload/1387565637832.jpg','EG2028KSZ01','Null','2013','finish','blue','damaged','0.00','4599.00','6199.00','1','0','e','2','1','2013-12-20 13:53:58','','barcode:013849858479, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:blue, location:e_2_1, condition:damaged, year:2013, vin:null');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858782','RAMBLER','upload/1387564847832.jpg','EG2040ASZ','L4f25A0A5D0050003','2013','finish','silver','new','0.00','6199.00','8299.00','0','0','e','2','1','2014-03-21 15:22:53','','barcode:013849858782, name:rambler, model:eg2040asz, category:finish, color:silver, location:e_2_1, condition:new, year:2013, vin:l4f25a0a5d0050003');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859041','RAMBLER','upload/1387564802192.jpg','EG2040ASZ','L4F25A0A5D0030012','2013','finish','blue','new','0.00','6199.00','8299.00','0','0','c','2','1','2014-03-26 09:48:38','','barcode:013849859041, name:rambler, model:eg2040asz, category:finish, color:blue, location:c_2_1, condition:new, year:2013, vin:l4f25a0a5d0030012');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859323','HOBBIT 2+2','upload/1387565534410.jpg','EG2028KSZ01','L4F2558K6D0030167','2013','finish','black','new','0.00','4599.00','6199.00','0','0','c','2','1','2014-03-26 09:48:38','','barcode:013849859323, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:c_2_1, condition:new, year:2013, vin:l4f2558k6d0030167');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859659','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','321','2013','semi','black','new','0.00','6199.00','8299.00','1','0','c','4','1','2013-12-23 14:12:08','','barcode:013849859659, name:rambler, model:eg2040asz, category:semi, color:black, location:c_4_1, condition:new, year:2013, vin:321');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859999','HOBBIT 4+2','upload/1392063259203.jpg','EG2048KSZ','123','2013','semi','silver','new','0.00','5750.00','7699.00','1','0','c','4','1','2014-02-10 15:14:20','','barcode:013849859999, name:hobbit 4+2, model:eg2048ksz, category:semi, color:silver, location:c_4_1, condition:new, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013853546558','ARGO 11','upload/sample/argo11.jpg','EG6118KA','3C3CFFAR1DT546508','2013','finish','black','new','0.00','12299.00','15599.00','0','0','c','1','1','2013-11-25 10:44:00','Assembly by otto;','barcode:013853546558, name:argo 11, model:eg6118ka, category:finish, color:black, location:c_1_1, condition:new, year:2013, vin:3c3cffar1dt546508');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013859994784','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','finish','White','new','0.00','5850.00','7899.00','0','0','c','1','1','2013-12-23 16:35:01','Serial Number: 13080079\r\nController Number: 12261P060690','barcode:013859994784, name:hobbit 2hcx, model:eg2048hcx, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878178357','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','semi','Green','new','0.00','5850.00','7899.00','0','0','W','3','1','2014-03-12 09:17:17','','barcode:013878178357, name:hobbit 2hcx, model:eg2048hcx, category:semi, color:green, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878179093','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','finish','Silver','new','0.00','6199.00','8299.00','1','0','W','3','1','2014-04-09 15:21:41','','barcode:013878179093, name:rambler, model:eg2040asz, category:finish, color:silver, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878179678','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Red','new','0.00','6199.00','8299.00','1','0','W','3','1','2013-12-23 14:11:39','','barcode:013878179678, name:rambler, model:eg2040asz, category:semi, color:red, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878181388','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','semi','Black','new','0.00','5850.00','7899.00','1','0','W','3','1','2013-12-23 12:02:43','','barcode:013878181388, name:hobbit 2hcx, model:eg2048hcx, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878183182','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','undefine','2013','semi','Red','new','0.00','5750.00','7699.00','1','0','W','3','1','2013-12-23 12:05:45','','barcode:013878183182, name:hobbit 4+2, model:eg2048ksz, category:semi, color:red, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878248948','HOBBIT 4+H','upload/1389111597135.jpg','EG2048H','undefine','2013','semi','Black','new','0.00','5750.00','7699.00','1','0','W','3','1','2014-01-07 11:19:57','','barcode:013878248948, name:hobbit 4+h, model:eg2048h, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878250105','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Silver','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 13:57:58','','barcode:013878250105, name:nomad, model:eg2020asz, category:semi, color:silver, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878250462','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Blue','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 13:57:44','','barcode:013878250462, name:nomad, model:eg2020asz, category:semi, color:blue, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878252345','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Black','new','0.00','4599.00','6199.00','1','0','W','3','1','2013-12-23 14:01:09','','barcode:013878252345, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878252919','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Silver','new','0.00','4599.00','6199.00','1','0','W','3','1','2013-12-23 14:01:59','','barcode:013878252919, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:silver, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878253878','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Orange','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 14:03:27','','barcode:013878253878, name:nomad, model:eg2020asz, category:semi, color:orange, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878254236','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Green','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 14:04:13','','barcode:013878254236, name:nomad, model:eg2020asz, category:semi, color:green, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878255184','NOMAD','upload/sample/nomad.jpg','EG2020ASZ','undefine','2013','semi','Black','new','0.00','5950.00','7499.00','1','0','W','3','1','2013-12-23 14:05:35','','barcode:013878255184, name:nomad, model:eg2020asz, category:semi, color:black, location:w_3_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878255554','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','L4F25A8K4D0050037','2013','semi','Silver','new','0.00','5750.00','7699.00','0','0','W','2','1','2014-04-11 13:09:20','Demo at Abibaba','barcode:013878255554, name:hobbit 4+2, model:eg2048ksz, category:semi, color:silver, location:w_2_1, condition:new, year:2013, vin:l4f25a8k4d0050037');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878261696','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Black','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:17:36','','barcode:013878261696, name:rambler, model:eg2040asz, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878269189','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Black','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:29:01','','barcode:013878269189, name:rambler, model:eg2040asz, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878269640','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Orange','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:30:41','','barcode:013878269640, name:rambler, model:eg2040asz, category:semi, color:orange, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878269848','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','L4F25A0AXD0030006','2013','semi','Orange','new','0.00','6199.00','8299.00','0','0','W','2','1','2014-04-09 15:42:42','Demo at Abibaba','barcode:013878269848, name:rambler, model:eg2040asz, category:semi, color:orange, location:w_2_1, condition:new, year:2013, vin:l4f25a0axd0030006');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878270074','RAMBLER','upload/sample/rambler.jpg','EG2040ASZ','undefine','2013','semi','Green','new','0.00','6199.00','8299.00','1','0','W','2','1','2013-12-23 14:30:26','','barcode:013878270074, name:rambler, model:eg2040asz, category:semi, color:green, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878271054','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','White','new','0.00','4599.00','6199.00','1','0','W','2','1','2014-01-22 15:39:35','','barcode:013878271054, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:white, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878272167','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ','undefine','2013','semi','Black','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:34:10','','barcode:013878272167, name:hobbit 2+2, model:eg2028ksz, category:semi, color:black, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878272679','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Red','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:34:49','','barcode:013878272679, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:red, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878273016','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Silver','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:35:17','','barcode:013878273016, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:silver, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878273573','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','L4F2558K000050110','2013','finish','Red','new','0.00','4599.00','6199.00','0','0','W','2','1','2014-04-10 14:00:13','','barcode:013878273573, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:red, location:w_2_1, condition:new, year:2013, vin:l4f2558k000050110');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878273839','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','L4F2558KX00050115','2013','finish','Black','new','0.00','4599.00','6199.00','0','0','W','2','1','2014-04-09 15:46:14','','barcode:013878273839, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:w_2_1, condition:new, year:2013, vin:l4f2558kx00050115');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878274028','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01','undefine','2013','semi','Silver','new','0.00','4599.00','6199.00','1','0','W','2','1','2013-12-23 14:37:14','','barcode:013878274028, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:silver, location:w_2_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878274540','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ','undefine','2013','semi','White','new','0.00','6999.00','9150.00','1','0','W','1','1','2013-12-23 14:37:51','','barcode:013878274540, name:hobbit 6+2, model:eg2068ksz, category:semi, color:white, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878274827','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ','undefine','2013','semi','Black','new','0.00','6999.00','9150.00','1','0','W','1','1','2013-12-23 14:38:20','','barcode:013878274827, name:hobbit 6+2, model:eg2068ksz, category:semi, color:black, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878275466','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','undefine','2013','semi','White','new','0.00','5750.00','7699.00','1','0','W','1','1','2013-12-23 14:39:28','','barcode:013878275466, name:hobbit 4+2, model:eg2048ksz, category:semi, color:white, location:w_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878275778','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ','L4F25A8K4C0070013','2013','finish','Silver','new','0.00','6999.00','9150.00','0','0','W','1','1','2014-04-04 10:51:34','','barcode:013878275778, name:hobbit 6+2, model:eg2068ksz, category:finish, color:silver, location:w_1_1, condition:new, year:2013, vin:l4f25a8k4c0070013');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013878292620','HOBBIT 4+2','upload/1387829760988.jpg','EG2048KSZ','undefine','2013','semi','Red','new','0.00','5750.00','7699.00','1','0','P','1','1','2013-12-23 15:16:02','','barcode:013878292620, name:hobbit 4+2, model:eg2048ksz, category:semi, color:red, location:p_1_1, condition:new, year:2013, vin:undefine');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013904144693','CRICKET 2','upload/1390415215947.jpg','EG2028K','L4F2558K0B0120086','2012','finish','Red','demo','3155.00','4299.00','5799.00','1','0','P','0','0','2014-02-04 14:26:41','Demo Car pulled back from Cart Guy on 1/21/2014','barcode:013904144693, name:cricket 2, model:eg2028k, category:finish, color:red, location:p_0_0, condition:demo, year:2012, vin:l4f2558k0b0120086');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013924049396','Kernel (Hard Door)','upload/1392406348584.jpg','EG6020XT','N/A','2013','finish','Green','new','7730.00','13389.00','0.00','0','0','P','P','P','2014-02-24 09:46:59','Modification on vehicle:\r\n\r\n1.Hard Doors\r\n2.Rear window enlargement to 32\" X 14\"\r\n3. Battery up grade to T-105 (2012)\r\n4. Battery Watering System\r\n5. 2 Extra Keys\r\n6. electric Heater (Purchased from U.S.)\r\n\r\nCar ordered by David (real east import)','barcode:013924049396, name:kernel (hard door), model:eg6020xt, category:finish, color:green, location:p_p_p, condition:new, year:2013, vin:n/a');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013963845512','Hulk','upload/default.jpg','EG6040A4D','L4F6550A290070015','2009','finish','camouflage','used','0.00','0.00','0.00','1','0','x','x','x','2014-04-01 16:36:00','Returned from Classic Cart','barcode:013963845512, name:hulk, model:eg6040a4d, category:finish, color:camouflage, location:x_x_x, condition:used, year:2009, vin:l4f6550a290070015');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013963845620','Hulk (W/Cargo Box)','upload/default.jpg','EG6040A4D','L4F6550A1C0030001','2012','finish','camouflage','used','0.00','0.00','0.00','1','0','x','x','x','2014-04-01 16:38:56','Returned from Classic Cart, Has been sold to public customer but refunded and returned to Classic Cart.\r\nComplaint on Driving Range doesnt match with information provided','barcode:013963845620, name:hulk (w/cargo box), model:eg6040a4d, category:finish, color:camouflage, location:x_x_x, condition:used, year:2012, vin:l4f6550a1c0030001');
/*!40000 ALTER TABLE `ew_car` ENABLE KEYS */;


--
-- Create Table `ew_cart`
--

DROP TABLE IF EXISTS `ew_cart`;
CREATE TABLE `ew_cart` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user` varchar(20) CHARACTER SET utf8 NOT NULL,
  `table` varchar(20) CHARACTER SET utf8 NOT NULL,
  `quantity` int(10) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=349 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_cart`
--

/*!40000 ALTER TABLE `ew_cart` DISABLE KEYS */;
INSERT INTO `ew_cart` (`cid`,`barcode`,`user`,`table`,`quantity`) VALUES ('258','013904144693','Tracy-Liu','ew_car','-1');
/*!40000 ALTER TABLE `ew_cart` ENABLE KEYS */;


--
-- Create Table `ew_log`
--

DROP TABLE IF EXISTS `ew_log`;
CREATE TABLE `ew_log` (
  `log_id` int(20) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Log time',
  `user` varchar(20) NOT NULL COMMENT 'Who made this transaction',
  `msg` tinytext NOT NULL COMMENT 'Log message',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1646 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_log`
--

/*!40000 ALTER TABLE `ew_log` DISABLE KEYS */;
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1','2013-12-05 11:16:17','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('2','2013-12-10 10:01:18','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('3','2013-12-12 11:34:00','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('4','2013-12-12 15:35:55','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('5','2013-12-13 10:41:07','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('6','2013-12-13 10:41:20','otto','del part, barcode=113855784845,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('7','2013-12-13 16:48:23','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('8','2013-12-16 09:50:35','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('9','2013-12-16 10:04:19','si','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('10','2013-12-16 11:08:22','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('11','2013-12-16 11:45:54','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('12','2013-12-16 11:48:11','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('13','2013-12-16 11:49:27','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('14','2013-12-16 13:27:34','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('15','2013-12-18 09:43:53','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('16','2013-12-18 12:34:40','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('17','2013-12-18 12:35:22','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('18','2013-12-18 12:35:47','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('19','2013-12-18 13:18:42','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('20','2013-12-18 13:19:49','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('21','2013-12-18 13:23:43','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('22','2013-12-18 13:25:36','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('23','2013-12-18 13:26:03','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('24','2013-12-18 13:26:27','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('25','2013-12-18 13:27:18','otto','edit part, barcode=113861020003,name=Passenger Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('26','2013-12-18 13:28:54','otto','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('27','2013-12-18 13:29:13','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('28','2013-12-18 13:32:02','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('29','2013-12-18 13:34:12','otto','edit part, barcode=113861020003,name=Passenger Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('30','2013-12-18 13:38:26','otto','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('31','2013-12-18 13:56:09','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('32','2013-12-18 13:56:13','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('33','2013-12-18 13:57:55','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('34','2013-12-18 14:58:10','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('35','2013-12-18 15:10:58','otto','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('36','2013-12-18 15:12:11','otto','edit part, barcode=113860008361,name=Central Cover - camouflage - used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('37','2013-12-18 15:12:49','otto','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('38','2013-12-18 15:13:55','otto','edit part, barcode=113860007132,name=Front Cover - Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('39','2013-12-18 15:14:18','otto','edit part, barcode=113860008361,name=Central Cover - camouflage - used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('40','2013-12-18 15:14:43','otto','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('41','2013-12-18 15:15:20','otto','edit part, barcode=113860005355,name=Front Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('42','2013-12-18 15:15:47','otto','edit part, barcode=113860002295,name=Front Cover - Metallic Green - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('43','2013-12-18 15:16:46','otto','edit part, barcode=113856751895,name=Rear Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('44','2013-12-18 15:17:11','otto','edit part, barcode=113856751451,name=Rear Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('45','2013-12-18 15:19:02','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('46','2013-12-18 15:19:25','otto','edit part, barcode=113856750152,name=Rear Cover - Metallic Green - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('47','2013-12-18 15:20:43','otto','edit part, barcode=113856751451,name=Rear Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('48','2013-12-18 15:21:38','otto','edit part, barcode=113856751451,name=Rear Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('49','2013-12-18 15:26:30','otto','edit part, barcode=113856732204,name=770x1100x250 Carbon Steel Cargo Box- Standard');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('50','2013-12-18 15:26:55','otto','edit part, barcode=113856732204,name=770x1100x250 Carbon Steel Cargo Box- Standard');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('51','2013-12-18 15:27:44','otto','edit part, barcode=113856730198,name=770x1100x250 Aluminum Cargo Box- Standard');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('52','2013-12-18 15:28:25','otto','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('53','2013-12-18 15:29:55','otto','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('54','2013-12-18 15:33:08','otto','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('55','2013-12-18 15:33:40','otto','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('56','2013-12-18 15:34:59','otto','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('57','2013-12-18 15:36:35','otto','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('58','2013-12-18 15:37:56','otto','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('59','2013-12-18 15:38:35','otto','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('60','2013-12-18 15:38:50','otto','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('61','2013-12-18 15:39:34','otto','edit part, barcode=113856717210,name=1400x1100x250 Carbon Steel Cargo Box- Manual Dump');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('62','2013-12-18 15:40:51','otto','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('63','2013-12-18 15:41:31','otto','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('64','2013-12-18 15:42:13','otto','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('65','2013-12-18 15:45:26','otto','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('66','2013-12-18 15:47:03','otto','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('67','2013-12-18 15:49:51','otto','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('68','2013-12-18 15:50:39','otto','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('69','2013-12-18 15:51:56','otto','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('70','2013-12-18 15:55:21','otto','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('71','2013-12-18 15:58:55','otto','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('72','2013-12-18 15:59:41','otto','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('73','2013-12-18 16:00:22','otto','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('74','2013-12-18 16:00:46','otto','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('75','2013-12-18 16:01:35','otto','edit part, barcode=113855777806,name=25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('76','2013-12-18 16:04:35','otto','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('77','2013-12-18 16:05:11','otto','edit part, barcode=113855768358,name=21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('78','2013-12-18 16:09:58','otto','add new part, barcode=113874008674,name=Front Bumper - Metallic,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('79','2013-12-18 16:14:28','otto','add new part, barcode=113874010003,name=Windshield - Non Foldable - 6040,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('80','2013-12-18 16:16:07','otto','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('81','2013-12-18 16:17:18','otto','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('82','2013-12-18 16:18:07','otto','edit part, barcode=113861699105,name=Front Axle Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('83','2013-12-18 16:30:02','otto','add new part, barcode=113874020209,name=Backrest Cushion,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('84','2013-12-18 16:33:34','otto','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('85','2013-12-18 16:38:24','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('86','2013-12-18 16:40:07','san','add new part, barcode=113874027780,name=sads,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('87','2013-12-18 16:52:01','otto','add new part, barcode=113874033533,name=Side Rear View Mirror,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('88','2013-12-18 16:52:54','otto','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('89','2013-12-19 09:30:20','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('90','2013-12-19 09:31:19','otto','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('91','2013-12-19 09:31:44','otto','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('92','2013-12-19 10:07:47','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('93','2013-12-19 10:12:16','otto','add new part, barcode=113874657396,name=Front Basket,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('94','2013-12-19 10:15:24','otto','add new part, barcode=113874660495,name=Inner Rearview Mirror,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('95','2013-12-19 10:21:01','otto','add new part, barcode=113874661256,name=Rear Bracket,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('96','2013-12-19 10:23:53','otto','add new part, barcode=113874665250,name=Rear Bracket - 2028K,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('97','2013-12-19 10:25:19','otto','add new part, barcode=113874666349,name=Rear Bracket - 2028KSF,amount=14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('98','2013-12-19 10:26:57','otto','add new part, barcode=113874667209,name=Front Basket Bracket,amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('99','2013-12-19 10:28:24','otto','add new part, barcode=113874668190,name=Rear Standing Board,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('100','2013-12-19 10:30:44','otto','add new part, barcode=113874669055,name=Sweater Basket - Carbon Steel,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('101','2013-12-19 10:33:15','otto','del part, barcode=113874027780,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('102','2013-12-19 10:36:42','otto','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('103','2013-12-19 10:38:03','otto','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('104','2013-12-19 10:41:04','otto','add new part, barcode=113874676203,name=Rear Bracket - Undefined,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('105','2013-12-19 10:46:30','otto','add new part, barcode=113874676661,name=Seat Back Main Bracket - 2028 Cargo Box,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('106','2013-12-19 11:02:16','otto','add new part, barcode=113874688608,name=Cargo Box Support Bracket - 2048HCX,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('107','2013-12-19 11:03:43','otto','add new part, barcode=113874689510,name=Side Armrest,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('108','2013-12-19 11:05:43','otto','add new part, barcode=113874690781,name=Seat Frame,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('109','2013-12-19 11:09:22','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('110','2013-12-19 11:10:55','otto','add new part, barcode=113874694069,name=Cargo Box Bracket Support,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('111','2013-12-19 11:13:38','otto','add new part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('112','2013-12-19 11:14:12','otto','edit part, barcode=113874689510,name=Side Armrest');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('113','2013-12-19 11:14:29','otto','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('114','2013-12-19 11:15:16','otto','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('115','2013-12-19 11:15:38','otto','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('116','2013-12-19 11:23:18','otto','add new part, barcode=113874701375,name=Searching Light Bracket 1,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('117','2013-12-19 14:08:39','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('118','2013-12-19 14:11:10','otto','add new part, barcode=113874801718,name=Searching Light,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('119','2013-12-19 14:14:21','otto','add new part, barcode=113874802719,name=Rear assembled light - LH,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('120','2013-12-19 14:15:45','otto','add new part, barcode=113874804634,name=Rear assembled light - RH,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('121','2013-12-19 14:18:08','otto','add new part, barcode=113874805471,name=Head Light - LH EG2028,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('122','2013-12-19 14:18:39','otto','add new part, barcode=113874806896,name=Head Light - RH EG2028,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('123','2013-12-19 14:19:42','otto','add new part, barcode=113874807201,name=Combination Switch,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('124','2013-12-19 14:21:13','otto','add new part, barcode=113874807834,name=Converter DC 48V-12V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('125','2013-12-19 14:21:57','otto','add new part, barcode=113874808788,name=Converter DC 36V-12V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('126','2013-12-19 14:25:17','otto','add new part, barcode=113874809185,name=Controller Curtis 1243-4320,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('127','2013-12-19 14:27:44','otto','add new part, barcode=113874811211,name=Controller Curtis 1266-5201,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('128','2013-12-19 14:28:59','otto','add new part, barcode=113874812661,name=Controller Curtis 1268-5403,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('129','2013-12-19 14:33:01','otto','add new part, barcode=113874813410,name=Tail Light LT - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('130','2013-12-19 14:33:26','otto','add new part, barcode=113874815828,name=Tail Light RT - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('131','2013-12-19 14:34:35','otto','add new part, barcode=113874816080,name=Controller Curtis 1244-5461,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('132','2013-12-19 14:48:58','otto','add new part, barcode=113874816760,name=Converter DC 72V-12V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('133','2013-12-19 14:50:17','otto','edit part, barcode=113874801718,name=Searching Light');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('134','2013-12-19 14:50:38','otto','edit part, barcode=113874802719,name=Rear assembled light - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('135','2013-12-19 14:51:05','otto','edit part, barcode=113874804634,name=Rear assembled light - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('136','2013-12-19 14:51:15','otto','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('137','2013-12-19 14:51:26','otto','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('138','2013-12-19 14:51:40','otto','edit part, barcode=113874807834,name=Converter DC 48V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('139','2013-12-19 14:52:09','otto','edit part, barcode=113874808788,name=Converter DC 36V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('140','2013-12-19 14:52:39','otto','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('141','2013-12-19 14:52:55','otto','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('142','2013-12-19 14:53:07','otto','edit part, barcode=113874811211,name=Controller Curtis 1266-5201');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('143','2013-12-19 14:53:18','otto','edit part, barcode=113874812661,name=Controller Curtis 1268-5403');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('144','2013-12-19 14:53:29','otto','edit part, barcode=113874813410,name=Tail Light LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('145','2013-12-19 15:05:31','otto','add new part, barcode=113874833776,name=Combination Switch - Non Golf Cart,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('146','2013-12-19 15:06:00','otto','edit part, barcode=113861699105,name=Front Axle Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('147','2013-12-19 15:08:29','otto','add new part, barcode=113874835726,name=Speed Meter,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('148','2013-12-19 15:11:28','otto','add new part, barcode=113874837101,name=AC Cable Extension,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('149','2013-12-19 15:12:32','otto','add new part, barcode=113874838896,name=AC Cable ,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('150','2013-12-19 15:12:51','otto','edit part, barcode=113874837101,name=AC Cable Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('151','2013-12-19 15:15:04','otto','add new part, barcode=113874840236,name=Motor 48V 5KW,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('152','2013-12-19 15:15:42','otto','add new part, barcode=113874841056,name=Motor 36V 3kw,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('153','2013-12-19 15:16:13','otto','edit part, barcode=113874841056,name=Motor 36V 3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('154','2013-12-19 15:16:47','otto','add new part, barcode=113874841768,name=Motor 48V 3.8kw,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('155','2013-12-19 15:17:24','otto','add new part, barcode=113874842091,name=Motor 48V 5.3kw,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('156','2013-12-19 15:17:36','otto','edit part, barcode=113874835726,name=Speed Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('157','2013-12-19 15:19:11','otto','add new part, barcode=113874843125,name=Charger - Smart 36V-120V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('158','2013-12-19 15:20:43','otto','add new part, barcode=113874843531,name=Windshield Wiper Motor Assembly,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('159','2013-12-19 15:22:38','otto','add new part, barcode=113874844445,name=Charger - DeltaQ 48V-110,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('160','2013-12-19 15:23:13','otto','add new part, barcode=113874845600,name=Charger - DeltaQ 36V-110,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('161','2013-12-19 15:27:00','otto','add new part, barcode=113874845946,name=Charger - DeltaQ 72V-110V,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('162','2013-12-19 15:28:08','otto','edit part, barcode=113874845600,name=Charger - DeltaQ 36V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('163','2013-12-19 15:28:20','otto','edit part, barcode=113874844445,name=Charger - DeltaQ 48V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('164','2013-12-19 15:28:38','otto','edit part, barcode=113874843125,name=Charger - Smart 36V-120V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('165','2013-12-19 15:38:50','otto','add new part, barcode=113874854618,name=Head Light - LH EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('166','2013-12-19 15:39:30','otto','add new part, barcode=113874855314,name=Head Light - RH EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('167','2013-12-19 15:40:18','otto','add new part, barcode=113874855716,name=Front Fog Light - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('168','2013-12-19 15:41:03','otto','add new part, barcode=113874856197,name=Front Turn Signal - EG6118,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('169','2013-12-19 15:42:20','otto','edit part, barcode=113874856197,name=Light - Front Turn Signal - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('170','2013-12-19 15:42:40','otto','edit part, barcode=113874855716,name= Light - Front Fog - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('171','2013-12-19 15:43:02','otto','edit part, barcode=113874855314,name=Light - Head - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('172','2013-12-19 15:43:23','otto','edit part, barcode=113874854618,name=Light - Head - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('173','2013-12-19 15:44:09','otto','edit part, barcode=113874815828,name=Light - Tail RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('174','2013-12-19 15:44:33','otto','edit part, barcode=113874815828,name=Light - Tail - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('175','2013-12-19 15:45:03','otto','edit part, barcode=113874813410,name=Light - Tail - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('176','2013-12-19 15:45:39','otto','edit part, barcode=113874806896,name=Light - Head - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('177','2013-12-19 15:45:57','otto','edit part, barcode=113874805471,name=Light - Head - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('178','2013-12-19 15:46:31','otto','edit part, barcode=113874804634,name=Light - Rear assembled - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('179','2013-12-19 15:46:51','otto','edit part, barcode=113874802719,name=Light - Rear assembled - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('180','2013-12-19 15:47:30','otto','edit part, barcode=113874801718,name=Light - Searching - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('181','2013-12-19 15:50:09','otto','add new part, barcode=113874862027,name=Light - Rear assembled - LH - Truck,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('182','2013-12-19 15:50:31','otto','add new part, barcode=113874862100,name=Light - Rear assembled - RH - Truck,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('183','2013-12-19 15:52:21','otto','add new part, barcode=113874862955,name=Light - Head - EG2020,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('184','2013-12-19 15:54:11','otto','add new part, barcode=113874863430,name=Battery Cable Jacket - Black,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('185','2013-12-19 15:55:50','otto','add new part, barcode=113874864521,name=Battery Cable Jacket - Red,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('186','2013-12-19 15:56:27','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('187','2013-12-19 16:03:01','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('188','2013-12-19 16:03:33','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('189','2013-12-19 16:04:10','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('190','2013-12-19 16:04:21','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('191','2013-12-19 16:04:24','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('192','2013-12-19 16:06:26','otto','edit part, barcode=113874864521,name=Battery Cable Jacket - Red');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('193','2013-12-19 16:06:49','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('194','2013-12-19 16:20:24','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('195','2013-12-19 16:23:14','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('196','2013-12-19 16:23:22','si','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('197','2013-12-19 16:25:02','otto','add new part, barcode=113874880273,name=Connect Wire 252Ã—130mm ,amount=40');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('198','2013-12-19 16:25:12','si','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('199','2013-12-19 16:25:16','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('200','2013-12-19 16:32:37','otto','del part, barcode=113861699105,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('201','2013-12-19 16:40:25','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('202','2013-12-19 16:40:30','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('203','2013-12-19 16:40:44','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('204','2013-12-19 16:41:00','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('205','2013-12-19 16:41:03','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('206','2013-12-19 16:41:26','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('207','2013-12-19 16:43:20','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('208','2013-12-19 16:50:08','san','edit car, barcode=013849847336,name=Garbage Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('209','2013-12-19 16:51:16','Boyao','edit part, barcode=113874863430,name=Battery Cable Jacket - Black');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('210','2013-12-19 16:52:21','Boyao','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('211','2013-12-19 16:52:27','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('212','2013-12-19 16:52:35','test','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('213','2013-12-19 16:53:05','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('214','2013-12-19 16:53:44','Boyao','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('215','2013-12-19 16:54:02','test','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('216','2013-12-19 16:54:22','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('217','2013-12-20 08:58:01','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('218','2013-12-20 09:04:02','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('219','2013-12-20 09:25:09','otto','edit part, barcode=113874880273,name=Connect Wire 25x130mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('220','2013-12-20 09:26:23','otto','add new part, barcode=113875495207,name=Connect Wire 25x200mm ,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('221','2013-12-20 09:27:34','otto','add new part, barcode=113875495845,name=Connect Wire 25Ã—300mm ,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('222','2013-12-20 09:29:03','otto','add new part, barcode=113875496561,name=Connect Wire 25Ã—440mm ,amount=30');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('223','2013-12-20 09:29:42','otto','edit part, barcode=113875495845,name=Connect Wire 25Ã—300mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('224','2013-12-20 09:33:55','otto','add new part, barcode=113875499828,name=Connect Wire 25Ã—440mm ,amount=40');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('225','2013-12-20 09:36:36','otto','edit part, barcode=113875499828,name=Battery Dead Lever');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('226','2013-12-20 09:37:47','otto','add new part, barcode=113875502090,name=Battery Impact Block,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('227','2013-12-20 09:39:01','otto','add new part, barcode=113875502687,name=Battery Dead Lever - S End,amount=16');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('228','2013-12-20 09:39:31','otto','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('229','2013-12-20 09:39:54','otto','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('230','2013-12-20 09:41:51','otto','add new part, barcode=113875504357,name=Accelerator,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('231','2013-12-20 09:43:35','otto','add new part, barcode=113875505132,name=Main Contactor - 36V 200A,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('232','2013-12-20 09:43:58','otto','edit part, barcode=113875505132,name=Main Contactor - 36V 200A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('233','2013-12-20 09:44:31','otto','add new part, barcode=113875506414,name=Main Contactor - 48V 150A,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('234','2013-12-20 09:44:58','otto','add new part, barcode=113875506733,name=Main Contactor - 48V 300A,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('235','2013-12-20 09:45:50','otto','add new part, barcode=113875506994,name=Main Contactor - 48V 100A FSIP,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('236','2013-12-20 09:47:19','otto','add new part, barcode=113875507516,name=Meter,amount=24');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('237','2013-12-20 09:47:58','otto','add new part, barcode=113875508403,name=Meter Holder,amount=22');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('238','2013-12-20 09:50:32','otto','add new part, barcode=113875508802,name=Meter Wires - Long,amount=16');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('239','2013-12-20 09:51:14','otto','add new part, barcode=113875510340,name=Meter Wires - Short,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('240','2013-12-20 09:51:49','otto','add new part, barcode=113875510757,name=Meter Wires - Extension,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('241','2013-12-20 09:53:44','otto','add new part, barcode=113875511107,name=Battery Impact Block Cap,amount=39');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('242','2013-12-20 09:59:22','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('243','2013-12-20 10:04:41','otto','add new part, barcode=113875517870,name=Side rear view mirror LH,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('244','2013-12-20 10:05:50','otto','add new part, barcode=113875518830,name=Side rear view mirror LH,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('245','2013-12-20 10:11:22','otto','add new part, barcode=113875519554,name=EG6020A4D Battery Cover on Front Body,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('246','2013-12-20 10:15:15','otto','add new part, barcode=113875523072,name=Motor Access,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('247','2013-12-20 10:18:31','otto','add new part, barcode=113875525170,name=Motor Cover - EG6040A4D,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('248','2013-12-20 10:20:42','otto','add new part, barcode=113875527221,name=Split Windshield - Slip block,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('249','2013-12-20 10:21:23','otto','add new part, barcode=113875528431,name=Split Windshield - Clipping block,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('250','2013-12-20 11:18:06','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('251','2013-12-20 11:19:52','otto','add new part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle,amount=44');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('252','2013-12-20 11:22:57','otto','add new part, barcode=113875563935,name=Sash (Clipper),amount=147');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('253','2013-12-20 11:24:26','otto','del part, barcode=113855784845,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('254','2013-12-20 11:26:17','otto','edit part, barcode=113874838896,name=AC Cable ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('255','2013-12-20 11:30:24','otto','edit part, barcode=113874837101,name=AC Cable Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('256','2013-12-20 11:31:13','otto','edit part, barcode=113875504357,name=Accelerator');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('257','2013-12-20 11:32:43','otto','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('258','2013-12-20 11:34:51','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('259','2013-12-20 11:36:35','otto','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('260','2013-12-20 11:37:36','otto','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('261','2013-12-20 11:37:40','otto','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('262','2013-12-20 11:38:04','otto','edit part, barcode=113875502090,name=Battery Impact Block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('263','2013-12-20 11:38:38','otto','edit part, barcode=113875511107,name=Battery Impact Block Cap');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('264','2013-12-20 11:39:33','otto','edit part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('265','2013-12-20 11:45:06','otto','edit part, barcode=113874845600,name=Charger - DeltaQ 36V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('266','2013-12-20 11:45:12','otto','edit part, barcode=113874844445,name=Charger - DeltaQ 48V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('267','2013-12-20 11:45:17','otto','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('268','2013-12-20 11:45:37','otto','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('269','2013-12-20 11:46:41','otto','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('270','2013-12-20 11:48:01','otto','edit part, barcode=113874833776,name=Combination Switch - Non Golf Cart');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('271','2013-12-20 11:52:23','otto','edit part, barcode=113874809185,name=Controller Curtis 1243-4320');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('272','2013-12-20 11:55:50','otto','edit part, barcode=113874816080,name=Controller Curtis 1244-5461');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('273','2013-12-20 11:57:53','otto','edit part, barcode=113874811211,name=Controller Curtis 1266-5201');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('274','2013-12-20 11:58:34','otto','edit part, barcode=113874816760,name=Converter DC 72V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('275','2013-12-20 12:00:48','otto','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('276','2013-12-20 13:06:24','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('277','2013-12-20 13:09:06','otto','add new part, barcode=113875628522,name=Sash (Clipper) - One piece,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('278','2013-12-20 13:09:33','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('279','2013-12-20 13:10:16','san','edit car, barcode=013849847336,name=Garbage Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('280','2013-12-20 13:11:32','san','edit car, barcode=013849848727,name=HOBBIT 2+2 Ambulance');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('281','2013-12-20 13:17:57','san','edit car, barcode=013849857778,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('282','2013-12-20 13:25:38','san','edit part, barcode=113874855716,name=Light - Front Fog - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('283','2013-12-20 13:29:37','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('284','2013-12-20 13:31:14','otto','edit part, barcode=113874862100,name=Light - Rear assembled - RH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('285','2013-12-20 13:31:18','otto','edit part, barcode=113874862027,name=Light - Rear assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('286','2013-12-20 13:31:28','san','edit car, barcode=013849846414,name=QUANTUM Customize');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('287','2013-12-20 13:32:07','otto','edit part, barcode=113874856197,name=Light - Front Turn Signal - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('288','2013-12-20 13:32:12','otto','edit part, barcode=113874855716,name=Light - Front Fog - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('289','2013-12-20 13:32:34','san','edit car, barcode=013849854684,name=QUANTUM Customize');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('290','2013-12-20 13:32:38','otto','edit part, barcode=113874855314,name=Light - Head - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('291','2013-12-20 13:32:43','otto','edit part, barcode=113874854618,name=Light - Head - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('292','2013-12-20 13:33:42','san','edit car, barcode=013849843167,name=KERNEL');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('293','2013-12-20 13:34:51','san','edit car, barcode=013849845400,name=Motorcycle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('294','2013-12-20 13:35:16','san','edit car, barcode=013849845400,name=Motorcycle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('295','2013-12-20 13:35:52','otto','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('296','2013-12-20 13:35:56','san','edit car, barcode=013849844238,name=HOBBIT 4+2 Customize');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('297','2013-12-20 13:36:37','san','edit car, barcode=013849848035,name=ARGO 14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('298','2013-12-20 13:37:07','san','edit car, barcode=013849848309,name=ARGO 14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('299','2013-12-20 13:37:08','otto','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('300','2013-12-20 13:38:18','san','edit car, barcode=013849850219,name=HOBBIT 6+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('301','2013-12-20 13:38:37','otto','edit part, barcode=113874801718,name=Light - Searching - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('302','2013-12-20 13:39:03','san','edit car, barcode=013849849042,name=HOBBIT 6+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('303','2013-12-20 13:39:29','otto','edit part, barcode=113874813410,name=Light - Tail - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('304','2013-12-20 13:39:35','otto','edit part, barcode=113874815828,name=Light - Tail - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('305','2013-12-20 13:40:03','san','edit car, barcode=013849859041,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('306','2013-12-20 13:40:12','otto','edit part, barcode=113875507516,name=Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('307','2013-12-20 13:40:16','otto','edit part, barcode=113875508403,name=Meter Holder');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('308','2013-12-20 13:40:48','san','edit car, barcode=013849858782,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('309','2013-12-20 13:40:51','otto','edit part, barcode=113875510757,name=Meter Wires - Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('310','2013-12-20 13:40:55','otto','edit part, barcode=113875508802,name=Meter Wires - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('311','2013-12-20 13:40:57','otto','edit part, barcode=113875510340,name=Meter Wires - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('312','2013-12-20 13:41:23','otto','edit part, barcode=113874841056,name=Motor 36V 3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('313','2013-12-20 13:41:28','otto','edit part, barcode=113874841768,name=Motor 48V 3.8kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('314','2013-12-20 13:41:32','otto','edit part, barcode=113874842091,name=Motor 48V 5.3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('315','2013-12-20 13:41:42','san','edit car, barcode=013849851341,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('316','2013-12-20 13:42:30','otto','edit part, barcode=113875523072,name=Motor Access EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('317','2013-12-20 13:42:33','san','edit car, barcode=013849851104,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('318','2013-12-20 13:43:34','san','edit car, barcode=013849854322,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('319','2013-12-20 13:44:06','otto','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('320','2013-12-20 13:44:44','san','edit car, barcode=013849853196,name=CRICKET 2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('321','2013-12-20 13:45:54','san','edit car, barcode=013849855695,name=CRICKET 2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('322','2013-12-20 13:46:46','san','edit car, barcode=013849853756,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('323','2013-12-20 13:47:09','otto','edit part, barcode=113874665250,name=Rear Bracket - 2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('324','2013-12-20 13:47:24','otto','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('325','2013-12-20 13:47:27','san','edit car, barcode=013849843596,name=HULK');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('326','2013-12-20 13:47:55','otto','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('327','2013-12-20 13:48:22','san','edit car, barcode=013849856001,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('328','2013-12-20 13:49:09','san','edit car, barcode=013849858260,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('329','2013-12-20 13:49:14','otto','edit part, barcode=113875563935,name=Sash (Clipper)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('330','2013-12-20 13:49:51','san','edit car, barcode=013849856577,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('331','2013-12-20 13:52:15','san','edit car, barcode=013849859323,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('332','2013-12-20 13:52:33','otto','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('333','2013-12-20 13:52:56','san','edit car, barcode=013849857340,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('334','2013-12-20 13:53:02','otto','edit part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('335','2013-12-20 13:53:26','san','edit car, barcode=013849857969,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('336','2013-12-20 13:53:58','san','edit car, barcode=013849858479,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('337','2013-12-20 13:54:27','san','edit car, barcode=013849857035,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('338','2013-12-20 13:54:52','otto','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('339','2013-12-20 13:55:18','san','edit car, barcode=013849852101,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('340','2013-12-20 13:56:02','san','edit car, barcode=013849856801,name=NUCLEUS');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('341','2013-12-20 13:56:30','otto','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('342','2013-12-20 13:58:07','otto','edit part, barcode=113875517870,name=Side rear view mirror LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('343','2013-12-20 13:58:12','otto','edit part, barcode=113875518830,name=Side rear view mirror LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('344','2013-12-20 13:58:50','otto','edit part, barcode=113874835726,name=Speed Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('345','2013-12-20 13:59:58','otto','edit part, barcode=113875527221,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('346','2013-12-20 14:00:21','otto','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('347','2013-12-20 14:00:57','otto','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('348','2013-12-20 14:01:23','otto','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('349','2013-12-20 14:02:01','otto','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('350','2013-12-20 14:02:11','otto','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('351','2013-12-20 14:02:51','otto','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('352','2013-12-20 14:03:14','otto','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('353','2013-12-20 14:03:19','otto','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('354','2013-12-20 14:03:25','otto','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('355','2013-12-20 14:39:20','otto','add new part, barcode=113875682157,name=Canopy Handle - 2028,amount=36');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('356','2013-12-20 14:41:38','otto','add new part, barcode=113875683616,name=Side Rear View Mirror Bass - L,amount=120');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('357','2013-12-20 14:42:01','otto','add new part, barcode=113875684999,name=Side Rear View Mirror Bass - R,amount=120');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('358','2013-12-20 14:44:39','otto','add new part, barcode=113875685230,name=Jacket For Caddie Handle,amount=150');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('359','2013-12-20 14:46:14','otto','add new part, barcode=113875686804,name=Dustproof cover,amount=58');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('360','2013-12-20 14:48:12','otto','add new part, barcode=113875687755,name=Floor Mat - Short,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('361','2013-12-20 14:48:36','otto','add new part, barcode=113875688937,name=Floor Mat - Long,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('362','2013-12-20 14:56:09','otto','add new part, barcode=113875689178,name=Enclosure for EG6118,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('363','2013-12-20 15:00:23','otto','add new part, barcode=113875693714,name=Underseat Compartment,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('364','2013-12-20 15:01:53','otto','add new part, barcode=113875696246,name=Back Rest Cover - Plastic ,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('365','2013-12-20 15:12:54','otto','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('366','2013-12-20 15:13:58','otto','add new part, barcode=113875703804,name=Canopy Handle - 2028,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('367','2013-12-20 15:14:29','otto','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('368','2013-12-20 15:17:07','otto','add new part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('369','2013-12-20 15:18:37','otto','add new part, barcode=113875706287,name=Arm Rest - Paired,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('370','2013-12-20 15:22:35','otto','add new part, barcode=113875707186,name=Sweater Basket Frame,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('371','2013-12-20 15:25:02','otto','add new part, barcode=113875709563,name=Seat Back Sub-bracket,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('372','2013-12-20 15:36:04','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('373','2013-12-20 15:38:09','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('374','2013-12-20 15:38:12','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('375','2013-12-20 15:57:29','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('376','2013-12-20 16:02:05','otto','add new part, barcode=113875732227,name=Caddie Handle (Old Model),amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('377','2013-12-20 16:03:25','otto','add new part, barcode=113875733270,name=Caddie Handle - 35\" (Old Model),amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('378','2013-12-20 16:04:38','otto','add new part, barcode=113875734063,name=Caddie Handle - 39\",amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('379','2013-12-20 16:05:27','otto','add new part, barcode=113875734794,name=Caddie Handle - 33\",amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('380','2013-12-20 16:06:21','otto','add new part, barcode=113875735287,name=Caddie Handle - 38.5\",amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('381','2013-12-20 16:06:51','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5\" (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('382','2013-12-20 16:07:05','otto','edit part, barcode=113875733270,name=Caddie Handle - 35');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('383','2013-12-20 16:07:32','otto','edit part, barcode=113875734063,name=Caddie Handle - 39');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('384','2013-12-20 16:07:59','otto','edit part, barcode=113875734794,name=Caddie Handle - 33\"');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('385','2013-12-20 16:08:43','otto','edit part, barcode=113875735287,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('386','2013-12-20 16:08:54','otto','edit part, barcode=113875734794,name=Caddie Handle - 33 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('387','2013-12-20 16:09:05','otto','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('388','2013-12-20 16:09:37','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('389','2013-12-20 16:10:12','otto','edit part, barcode=113875733270,name=Caddie Handle - 35 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('390','2013-12-20 16:10:38','otto','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('391','2013-12-20 16:11:13','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('392','2013-12-20 16:13:39','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('393','2013-12-20 16:15:17','otto','add new part, barcode=113875740798,name=Tie Rod,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('394','2013-12-20 16:16:29','otto','add new part, barcode=113875741190,name=Steering Shaft Bushing,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('395','2013-12-20 16:18:02','otto','add new part, barcode=113875741899,name=Hubcap,amount=60');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('396','2013-12-20 16:19:16','otto','add new part, barcode=113875742842,name=Hubcap - Plastic,amount=50');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('397','2013-12-20 16:19:37','otto','edit part, barcode=113875741899,name=Hubcap - Aluminum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('398','2013-12-20 16:21:22','otto','add new part, barcode=113875744437,name=Enclosure - EG2028KSZ,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('399','2013-12-20 16:22:27','otto','add new part, barcode=113875744839,name=Enclosure - EG6158,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('400','2013-12-20 16:23:52','otto','add new part, barcode=113875745490,name=Enclosure - EG2048K,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('401','2013-12-20 16:24:41','otto','add new part, barcode=113875746339,name=Enclosure - EG6043,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('402','2013-12-20 16:30:21','otto','add new part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired),amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('403','2013-12-20 16:31:06','otto','add new part, barcode=113875750225,name=Front Wheel Trim - Fender Flare (Paired),amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('404','2013-12-20 16:31:19','otto','edit part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('405','2013-12-20 16:34:06','otto','add new part, barcode=113875752178,name=Braking Cable Assembly,amount=19');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('406','2013-12-20 16:36:04','otto','add new part, barcode=113875752475,name=Windshield Wiper,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('407','2013-12-20 16:37:45','otto','add new part, barcode=113875753656,name=Windshield Wiper - EG6118 (Paired),amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('408','2013-12-20 16:38:02','otto','edit part, barcode=113875752475,name=Windshield Wiper - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('409','2013-12-20 16:40:58','otto','add new part, barcode=113875756083,name=Thin Copper Sheath - Thin,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('410','2013-12-20 16:41:42','otto','add new part, barcode=113875756594,name=Copper Sheath - Thick,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('411','2013-12-20 16:41:54','otto','edit part, barcode=113875756083,name=Copper Sheath - Thin');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('412','2013-12-20 16:43:01','otto','add new part, barcode=113875757195,name=Bearing Assembly,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('413','2013-12-20 16:44:04','otto','add new part, barcode=113875757827,name=Bearing 6206-Z,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('414','2013-12-20 16:45:21','otto','add new part, barcode=113875758458,name=Redirector Assembly,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('415','2013-12-20 16:55:36','otto','add new part, barcode=113875764620,name=Wheel Nut - Aluminum Rim,amount=500');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('416','2013-12-20 17:01:20','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('417','2013-12-20 17:04:02','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('418','2013-12-23 09:17:12','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('419','2013-12-23 09:23:59','otto','add new part, barcode=113878082911,name=Seat Belt Set - 2 point,amount=15');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('420','2013-12-23 09:24:47','otto','add new part, barcode=113878086410,name=Seat Belt Set - 3 point,amount=15');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('421','2013-12-23 09:28:18','otto','add new part, barcode=113878088327,name=Front Axle Assembly,amount=11');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('422','2013-12-23 09:30:48','otto','add new part, barcode=113878088998,name=Front Axle Assembly - Semi,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('423','2013-12-23 09:31:36','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('424','2013-12-23 09:35:51','otto','edit part, barcode=113878088327,name=Front Axle Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('425','2013-12-23 09:37:18','otto','add new part, barcode=113878093952,name=Rear Brake assembly RH,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('426','2013-12-23 09:40:48','otto','add new part, barcode=113878094409,name=Rear Brake assembly LH,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('427','2013-12-23 09:40:57','otto','edit part, barcode=113878093952,name=Rear Brake assembly RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('428','2013-12-23 09:42:16','otto','add new part, barcode=113878096654,name=Brake Shoe,amount=46');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('429','2013-12-23 09:46:36','otto','add new part, barcode=113878098067,name=Brake Shoe - Unidentified,amount=48');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('430','2013-12-23 09:48:33','otto','add new part, barcode=113878099978,name=Front Axle Assembly - EG2028,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('431','2013-12-23 09:49:02','otto','edit part, barcode=113878099978,name=Front Axle Assembly - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('432','2013-12-23 09:49:50','otto','edit part, barcode=113878088327,name=Front Axle Assembly - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('433','2013-12-23 09:52:29','otto','add new part, barcode=113878103106,name=Rear Axle Assembly ,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('434','2013-12-23 09:53:51','otto','add new part, barcode=113878103505,name=Rear Bumper - EG2020/ EG2028,amount=13');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('435','2013-12-23 09:54:51','otto','add new part, barcode=113878104320,name=Motor Access - EG2028/ EG2020,amount=48');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('436','2013-12-23 09:56:56','otto','add new part, barcode=113878104955,name=Fender scuffguard - Paired,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('437','2013-12-23 09:57:37','otto','add new part, barcode=113878106177,name=Front Bumper - EG2028,amount=9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('438','2013-12-23 09:59:31','otto','add new part, barcode=113878106590,name=Front Bumper - EG2020 - Plastic,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('439','2013-12-23 10:01:27','otto','add new part, barcode=113878107737,name=Front Shock Absorber Assembly - EG2020,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('440','2013-12-23 10:02:29','otto','add new part, barcode=113878109179,name=Front Shock Absorber Assembly - EG2028,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('441','2013-12-23 10:03:19','otto','add new part, barcode=113878109505,name=Front Shock Absorber Assembly - Unidentified,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('442','2013-12-23 10:07:30','otto','add new part, barcode=113878110008,name=Left Knuckle,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('443','2013-12-23 10:08:12','otto','add new part, barcode=113878112510,name=Right Knuckle,amount=7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('444','2013-12-23 10:08:59','otto','add new part, barcode=113878112939,name=Watering System,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('445','2013-12-23 10:10:43','otto','add new part, barcode=113878113414,name=Front Leaf Spring Assembly,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('446','2013-12-23 10:12:18','otto','add new part, barcode=113878114441,name=Rear Leaf Spring Assembly,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('447','2013-12-23 10:12:56','otto','add new part, barcode=113878115393,name=Seat Belt Set - 3 point (Large),amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('448','2013-12-23 10:13:12','otto','edit part, barcode=113878115393,name=Seat Belt Set - 3 point (Large)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('449','2013-12-23 10:18:12','otto','add new part, barcode=113878118605,name=Tie Rod Joint,amount=33');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('450','2013-12-23 10:19:06','otto','add new part, barcode=113878118930,name=Rear Brake Drum,amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('451','2013-12-23 10:19:20','otto','edit part, barcode=113878118930,name=Rear Brake Drum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('452','2013-12-23 10:21:36','otto','add new part, barcode=113878120248,name=Top Canopy Bracket - EG2028KSF/ EG2028KSZ,amount=30');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('453','2013-12-23 10:23:12','otto','add new part, barcode=113878120972,name=Front Bracket - Normal,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('454','2013-12-23 10:25:20','otto','add new part, barcode=113878122294,name=Top Canopy Bracket - EG2048KSF/ 2048KSZ,amount=13');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('455','2013-12-23 10:26:22','otto','add new part, barcode=113878123216,name=Top Canopy Bracket - EG2068KSZ,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('456','2013-12-23 10:28:22','otto','add new part, barcode=113878123902,name=Front Bracket - EG2020ASZ,amount=3');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('457','2013-12-23 10:28:42','otto','edit part, barcode=113878123216,name=Top Canopy Bracket - EG2068KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('458','2013-12-23 10:28:56','otto','edit part, barcode=113878122294,name=Top Canopy Bracket - EG2048KSF/ 2048KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('459','2013-12-23 10:29:27','otto','edit part, barcode=113878120972,name=Front Bracket - Normal');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('460','2013-12-23 10:29:33','otto','edit part, barcode=113878120248,name=Top Canopy Bracket - EG2028KSF/ EG2028KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('461','2013-12-23 10:42:10','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('462','2013-12-23 10:56:34','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('463','2013-12-23 10:58:52','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('464','2013-12-23 11:00:27','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('465','2013-12-23 11:01:07','otto','edit car, barcode=013849843596,name=HULK');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('466','2013-12-23 11:58:08','otto','add new car, barcode=013878178357,name=HOBBIT 2HCX,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('467','2013-12-23 11:58:52','otto','add new car, barcode=013878179093,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('468','2013-12-23 11:59:10','otto','edit car, barcode=013878178357,name=HOBBIT 2HCX');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('469','2013-12-23 11:59:46','otto','add new car, barcode=013878179678,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('470','2013-12-23 12:02:43','otto','add new car, barcode=013878181388,name=HOBBIT 2HCX,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('471','2013-12-23 12:05:34','otto','add new car, barcode=013878183182,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('472','2013-12-23 12:05:45','otto','edit car, barcode=013878183182,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('473','2013-12-23 13:43:18','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('474','2013-12-23 13:49:07','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('475','2013-12-23 13:55:35','otto','add new car, barcode=013878248948,name=HOBBIT 4+H,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('476','2013-12-23 13:57:13','otto','add new car, barcode=013878250105,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('477','2013-12-23 13:57:44','otto','add new car, barcode=013878250462,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('478','2013-12-23 13:57:58','otto','edit car, barcode=013878250105,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('479','2013-12-23 14:00:42','otto','add new car, barcode=013878252345,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('480','2013-12-23 14:01:09','otto','edit car, barcode=013878252345,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('481','2013-12-23 14:01:59','otto','add new car, barcode=013878252919,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('482','2013-12-23 14:03:27','otto','add new car, barcode=013878253878,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('483','2013-12-23 14:04:13','otto','add new car, barcode=013878254236,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('484','2013-12-23 14:05:35','otto','add new car, barcode=013878255184,name=NOMAD,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('485','2013-12-23 14:06:16','otto','add new car, barcode=013878255554,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('486','2013-12-23 14:11:19','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('487','2013-12-23 14:11:39','san','edit car, barcode=013878179678,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('488','2013-12-23 14:11:45','Boyao','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('489','2013-12-23 14:11:51','san','edit car, barcode=013878179093,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('490','2013-12-23 14:11:57','Boyao','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('491','2013-12-23 14:12:08','san','edit car, barcode=013849859659,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('492','2013-12-23 14:12:24','san','edit car, barcode=013849859041,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('493','2013-12-23 14:13:00','san','edit car, barcode=013849858782,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('494','2013-12-23 14:14:39','san','edit car, barcode=013849852101,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('495','2013-12-23 14:14:50','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('496','2013-12-23 14:14:59','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('497','2013-12-23 14:15:25','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('498','2013-12-23 14:16:42','otto','add new car, barcode=013878261696,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('499','2013-12-23 14:16:52','otto','edit car, barcode=013878261696,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('500','2013-12-23 14:17:36','otto','edit car, barcode=013878261696,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('501','2013-12-23 14:18:16','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('502','2013-12-23 14:18:40','otto','add new part, barcode=113878261008,name=Shunt,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('503','2013-12-23 14:20:38','otto','add new part, barcode=113878263216,name=Main Fuse - 425A,amount=29');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('504','2013-12-23 14:22:15','otto','add new part, barcode=113878264399,name=Controller Fuse,amount=88');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('505','2013-12-23 14:23:06','otto','add new part, barcode=113878265368,name=Attach Fuse socket,amount=30');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('506','2013-12-23 14:24:00','otto','add new part, barcode=113878265874,name=Battery Protector,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('507','2013-12-23 14:29:01','otto','add new car, barcode=013878269189,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('508','2013-12-23 14:29:20','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('509','2013-12-23 14:29:23','otto','add new part, barcode=113878266414,name=Reverse Buzzer,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('510','2013-12-23 14:29:37','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('511','2013-12-23 14:29:39','otto','add new car, barcode=013878269640,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('512','2013-12-23 14:30:01','otto','add new car, barcode=013878269848,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('513','2013-12-23 14:30:26','otto','add new car, barcode=013878270074,name=RAMBLER,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('514','2013-12-23 14:30:37','otto','add new part, barcode=113878269647,name=Reverse Buzzer - Golf,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('515','2013-12-23 14:30:41','otto','edit car, barcode=013878269640,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('516','2013-12-23 14:31:03','otto','edit part, barcode=113878266414,name=Reverse Buzzer - Truck/ Bus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('517','2013-12-23 14:32:07','otto','add new part, barcode=113878270780,name=Fuse Box - Golf,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('518','2013-12-23 14:32:11','otto','add new car, barcode=013878271054,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('519','2013-12-23 14:33:37','otto','add new part, barcode=113878271280,name=Electric Horn - Golf,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('520','2013-12-23 14:33:52','otto','add new car, barcode=013878272167,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('521','2013-12-23 14:34:10','otto','edit car, barcode=013878272167,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('522','2013-12-23 14:34:37','otto','add new part, barcode=113878272184,name=Time-lapse Relay - Golf,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('523','2013-12-23 14:34:49','otto','add new car, barcode=013878272679,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('524','2013-12-23 14:35:17','otto','add new car, barcode=013878273016,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('525','2013-12-23 14:36:12','otto','add new car, barcode=013878273573,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('526','2013-12-23 14:36:26','otto','add new part, barcode=113878272791,name=Electronic Flasher,amount=11');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('527','2013-12-23 14:36:38','otto','add new car, barcode=013878273839,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('528','2013-12-23 14:37:14','otto','add new car, barcode=013878274028,name=HOBBIT 2+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('529','2013-12-23 14:37:41','otto','add new part, barcode=113878273877,name=Auxiliary relay - 48V,amount=12');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('530','2013-12-23 14:37:51','otto','add new car, barcode=013878274540,name=HOBBIT 6+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('531','2013-12-23 14:38:20','otto','add new car, barcode=013878274827,name=HOBBIT 6+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('532','2013-12-23 14:38:56','otto','add new part, barcode=113878274626,name=Main Fuse - 250A,amount=25');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('533','2013-12-23 14:39:28','otto','add new car, barcode=013878275466,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('534','2013-12-23 14:39:51','otto','add new part, barcode=113878275369,name=Tow/Run Switch,amount=17');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('535','2013-12-23 14:39:53','otto','add new car, barcode=013878275778,name=HOBBIT 6+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('536','2013-12-23 14:41:33','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('537','2013-12-23 14:41:37','otto','add new part, barcode=113878275921,name=Brake Light Switch,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('538','2013-12-23 14:42:40','otto','add new part, barcode=113878276989,name=Universal Start Key,amount=25');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('539','2013-12-23 14:43:38','otto','add new part, barcode=113878277615,name=F/R Switch,amount=19');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('540','2013-12-23 14:44:30','otto','add new part, barcode=113878278199,name=Power Meter - 36V,amount=15');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('541','2013-12-23 14:45:15','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('542','2013-12-23 14:45:16','otto','add new part, barcode=113878278718,name=Power Meter - 48V,amount=12');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('543','2013-12-23 14:46:41','otto','add new part, barcode=113878279170,name=Speed Sensor,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('544','2013-12-23 14:48:05','otto','add new part, barcode=113878280024,name=Carbon Brush - Chinese Motor,amount=5');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('545','2013-12-23 14:48:36','otto','add new part, barcode=113878280863,name=Carbon brush - ADC motor,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('546','2013-12-23 14:49:31','otto','add new part, barcode=113878281176,name=Speed sensor - ADC motor,amount=6');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('547','2013-12-23 14:49:51','otto','edit part, barcode=113878281176,name=Speed sensor - ADC motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('548','2013-12-23 14:50:57','otto','add new part, barcode=113878282207,name=Head Light Bulb - EG2028,amount=21');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('549','2013-12-23 14:51:45','otto','add new part, barcode=113878282586,name=Turn Light Bulb - EG2028,amount=21');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('550','2013-12-23 14:53:10','otto','add new part, barcode=113878283060,name=LED light Wire - On board,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('551','2013-12-23 14:54:30','otto','add new part, barcode=113878283910,name=Turn light bulb - EG2020,amount=8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('552','2013-12-23 14:56:02','otto','add new part, barcode=113878284719,name=Rear Light Bulb - Golf,amount=18');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('553','2013-12-23 14:57:19','otto','add new part, barcode=113878285629,name=Reflector,amount=10');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('554','2013-12-23 14:58:34','otto','add new part, barcode=113878286445,name=Hi-Low Switch,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('555','2013-12-23 15:08:21','otto','add new car, barcode=013878292620,name=HOBBIT 4+2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('556','2013-12-23 15:12:53','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('557','2013-12-23 15:16:02','otto','edit car, barcode=013878292620,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('558','2013-12-23 15:18:10','otto','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('559','2013-12-23 15:18:11','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('560','2013-12-23 15:18:32','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('561','2013-12-23 15:21:04','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('562','2013-12-23 15:21:07','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('563','2013-12-23 15:21:09','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('564','2013-12-23 15:21:37','Boyao-Wang','edit part, barcode=113874660495,name=Inner Rearview Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('565','2013-12-23 15:25:00','Boyao-Wang','edit part, barcode=113874660495,name=Inner Rearview Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('566','2013-12-23 15:27:38','Boyao-Wang','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('567','2013-12-23 15:33:21','Boyao-Wang','edit part, barcode=113874657396,name=Front Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('568','2013-12-23 15:34:46','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('569','2013-12-23 15:36:28','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('570','2013-12-23 15:39:13','Boyao-Wang','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('571','2013-12-23 15:41:17','otto','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('572','2013-12-23 15:42:53','otto','edit part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('573','2013-12-23 15:43:31','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('574','2013-12-23 15:43:40','OTTO','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('575','2013-12-23 15:43:43','OTTO','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('576','2013-12-23 15:43:55','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('577','2013-12-23 15:43:57','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('578','2013-12-23 15:44:06','otto','edit part, barcode=113874676203,name=Rear Bracket - Undefined');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('579','2013-12-23 15:46:09','otto','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('580','2013-12-23 15:46:41','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('581','2013-12-23 15:47:31','otto','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('582','2013-12-23 15:48:29','otto','edit part, barcode=113874665250,name=Rear Bracket - 2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('583','2013-12-23 15:49:51','otto','edit part, barcode=113874667209,name=Front Basket Bracket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('584','2013-12-23 15:51:59','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('585','2013-12-23 15:53:21','otto','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('586','2013-12-23 15:54:43','otto','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('587','2013-12-23 15:55:28','otto','add new part, barcode=113878320669,name=Side Rear View Mirror - RH,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('588','2013-12-23 15:55:59','otto','add new part, barcode=113878321298,name=Side Rear View Mirror - RH,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('589','2013-12-23 15:56:07','otto','edit part, barcode=113874701375,name=Searching Light Bracket 1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('590','2013-12-23 15:57:22','otto','edit part, barcode=113874689510,name=Side Armrest');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('591','2013-12-23 15:58:36','otto','edit part, barcode=113875518830,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('592','2013-12-23 15:58:58','otto','edit part, barcode=113875517870,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('593','2013-12-23 15:59:30','otto','edit part, barcode=113874688608,name=Cargo Box Support Bracket - 2048HCX');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('594','2013-12-23 16:13:49','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('595','2013-12-23 16:14:15','otto','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('596','2013-12-23 16:14:17','otto','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('597','2013-12-23 16:15:15','otto','edit part, barcode=113875523072,name=Motor Access EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('598','2013-12-23 16:16:34','otto','edit part, barcode=113875519554,name=EG6020A4D Battery Cover on Front Body');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('599','2013-12-23 16:19:43','otto','edit part, barcode=113875517870,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('600','2013-12-23 16:20:22','otto','edit part, barcode=113875518830,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('601','2013-12-23 16:23:46','otto','edit part, barcode=113878320669,name=Side Rear View Mirror - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('602','2013-12-23 16:27:53','otto','edit part, barcode=113878321298,name=Side Rear View Mirror - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('603','2013-12-23 16:31:05','otto','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('604','2013-12-23 16:32:26','otto','edit part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('605','2013-12-23 16:34:25','otto','edit part, barcode=113875703804,name=Canopy Handle - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('606','2013-12-23 16:43:13','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('607','2013-12-23 16:58:15','otto','edit part, barcode=113875707186,name=Sweater Basket Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('608','2013-12-23 16:58:17','otto','edit part, barcode=113875707186,name=Sweater Basket Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('609','2013-12-23 16:59:20','otto','edit part, barcode=113875628522,name=Sash (Clipper) - One piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('610','2013-12-23 17:00:10','otto','edit part, barcode=113875563935,name=Sash (Clipper)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('611','2013-12-23 18:13:56','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('612','2013-12-23 18:14:53','otto','edit part, barcode=113874815828,name=Tail Light - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('613','2013-12-23 18:15:43','otto','edit part, barcode=113874813410,name=Tail Light - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('614','2013-12-23 18:16:22','otto','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('615','2013-12-23 18:17:34','otto','edit part, barcode=113874802719,name=Tail Light Assembled - LT - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('616','2013-12-23 18:18:21','otto','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('617','2013-12-23 18:19:14','otto','edit part, barcode=113874804634,name=Tail Light Assembled - RH - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('618','2013-12-23 18:20:15','otto','edit part, barcode=113874801718,name=Searching Light - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('619','2013-12-23 18:21:25','otto','edit part, barcode=113874862955,name=Head Light - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('620','2013-12-23 18:22:01','otto','edit part, barcode=113874862100,name=Tail Light Assembled - RH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('621','2013-12-23 18:22:13','otto','edit part, barcode=113874862027,name=Tail Light Assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('622','2013-12-23 18:22:34','otto','edit part, barcode=113874856197,name=Front Turn Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('623','2013-12-23 18:22:49','otto','edit part, barcode=113874855314,name=Head Light - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('624','2013-12-23 18:23:02','otto','edit part, barcode=113874855716,name=Front Fog Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('625','2013-12-23 18:23:13','otto','edit part, barcode=113874854618,name=Head Light - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('626','2013-12-23 18:33:14','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('627','2013-12-23 20:16:31','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('628','2013-12-24 09:11:33','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('629','2013-12-24 09:57:21','otto','add new part, barcode=113878969596,name=Oil Seal 32*47*8,amount=40');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('630','2013-12-24 10:00:11','otto','add new part, barcode=113878970448,name=Oil Seal 50.3/43.1/9,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('631','2013-12-24 10:01:11','otto','add new part, barcode=113878972137,name=Oil Seal 42/55/7,amount=20');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('632','2013-12-24 10:02:25','otto','edit part, barcode=113878972137,name=Oil Seal 42/55/7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('633','2013-12-24 10:02:57','otto','edit part, barcode=113878970448,name=Oil Seal 50.3/43.1/9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('634','2013-12-24 10:05:18','otto','edit part, barcode=113878969596,name=Oil Seal 32*47*8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('635','2013-12-24 10:06:03','otto','edit part, barcode=113878969596,name=Oil Seal 32/47/8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('636','2013-12-24 10:20:41','otto','add new part, barcode=113878983894,name=Wheel 21x11-10 CST/ Aluminum Rim F - Damaged,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('637','2013-12-24 10:22:15','otto','edit part, barcode=113878103106,name=Rear Axle Assembly ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('638','2013-12-24 10:31:00','otto','add new part, barcode=113878990073,name=Tyre valve,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('639','2013-12-24 10:32:09','otto','add new part, barcode=113878990619,name=Shackle plate,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('640','2013-12-24 10:33:49','otto','add new part, barcode=113878991309,name=Flip-Flop Seat Rubber Pad,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('641','2013-12-24 10:34:52','otto','add new part, barcode=113878992304,name=Holding Block - Widshield,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('642','2013-12-24 10:43:44','otto','add new part, barcode=113878997974,name=Steering Wheel Cover,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('643','2013-12-24 10:44:28','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('644','2013-12-24 10:54:21','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('645','2013-12-24 10:55:21','otto','add new part, barcode=113879004663,name=Battery - US 2200,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('646','2013-12-24 10:55:48','otto','add new part, barcode=113879005228,name=Battery - Trojan T875,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('647','2013-12-24 10:56:36','otto','add new part, barcode=113879005492,name=Battery - Trojan T105,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('648','2013-12-24 13:42:42','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('649','2013-12-30 14:59:02','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('650','2013-12-30 15:09:52','otto ','edit part, barcode=113878261008,name=Shunt');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('651','2013-12-30 15:16:03','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('652','2013-12-30 15:16:38','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('653','2013-12-30 15:17:43','otto ','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('654','2013-12-30 15:22:25','otto ','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('655','2013-12-30 15:24:42','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('656','2013-12-30 15:25:31','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('657','2013-12-30 15:26:25','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('658','2013-12-30 15:26:57','otto ','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('659','2013-12-30 15:30:12','otto ','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('660','2013-12-30 15:37:28','otto ','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('661','2013-12-30 15:38:09','otto ','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('662','2013-12-30 15:44:10','otto ','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('663','2013-12-30 15:45:52','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('664','2013-12-30 15:46:43','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('665','2013-12-30 15:48:04','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('666','2013-12-30 15:48:58','otto ','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('667','2013-12-30 15:51:16','otto ','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('668','2013-12-30 15:53:07','otto ','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('669','2013-12-30 15:55:33','otto ','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('670','2013-12-30 16:11:29','otto ','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('671','2013-12-30 16:12:02','otto ','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('672','2013-12-30 16:20:04','otto ','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('673','2013-12-30 16:29:14','otto ','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('674','2013-12-30 16:31:27','otto ','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('675','2013-12-30 16:33:37','otto ','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('676','2014-01-02 09:12:37','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('677','2014-01-02 09:42:17','otto','edit part, barcode=113878992304,name=Holding Block - Widshield');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('678','2014-01-02 09:43:10','otto','edit part, barcode=113878990073,name=Tyre valve');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('679','2014-01-02 09:43:18','otto','edit part, barcode=113878970448,name=Oil Seal 50.3/43.1/9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('680','2014-01-02 09:43:25','otto','edit part, barcode=113878280024,name=Carbon Brush - Chinese Motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('681','2014-01-02 09:43:33','otto','edit part, barcode=113878279170,name=Speed Sensor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('682','2014-01-02 09:43:43','otto','edit part, barcode=113878278199,name=Power Meter - 36V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('683','2014-01-02 09:43:50','otto','edit part, barcode=113878274626,name=Main Fuse - 250A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('684','2014-01-02 09:43:55','otto','edit part, barcode=113878272184,name=Time-lapse Relay - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('685','2014-01-02 09:44:00','otto','edit part, barcode=113878271280,name=Electric Horn - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('686','2014-01-02 09:44:24','otto','edit part, barcode=113879005228,name=Battery - Trojan T875');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('687','2014-01-02 09:44:31','otto','edit part, barcode=113879004663,name=Battery - US 2200');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('688','2014-01-02 09:44:36','otto','edit part, barcode=113879005492,name=Battery - Trojan T105');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('689','2014-01-02 09:45:26','otto','edit part, barcode=113878106590,name=Front Bumper - EG2020 - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('690','2014-01-02 09:45:34','otto','edit part, barcode=113875753656,name=Windshield Wiper - EG6118 (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('691','2014-01-02 09:45:40','otto','edit part, barcode=113875752475,name=Windshield Wiper - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('692','2014-01-02 09:45:47','otto','edit part, barcode=113875746339,name=Enclosure - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('693','2014-01-02 09:46:11','otto','edit part, barcode=113875745490,name=Enclosure - EG2048K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('694','2014-01-02 09:46:16','otto','edit part, barcode=113875740798,name=Tie Rod');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('695','2014-01-02 09:46:20','otto','edit part, barcode=113875687755,name=Floor Mat - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('696','2014-01-02 09:46:37','otto','edit part, barcode=113875527221,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('697','2014-01-02 09:46:50','otto','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('698','2014-01-02 09:47:34','otto','edit part, barcode=113874862027,name=Tail Light Assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('699','2014-01-02 09:47:45','otto','edit part, barcode=113874807834,name=Converter DC 48V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('700','2014-01-02 09:47:54','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('701','2014-01-02 09:48:00','otto','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('702','2014-01-02 09:48:14','otto','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('703','2014-01-02 09:48:21','otto','edit part, barcode=113860008361,name=Central Cover - camouflage - used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('704','2014-01-02 09:48:26','otto','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('705','2014-01-02 09:51:59','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('706','2014-01-02 10:41:43','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('707','2014-01-02 11:13:54','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('708','2014-01-02 11:15:43','otto ','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('709','2014-01-02 11:35:22','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('710','2014-01-02 11:35:56','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('711','2014-01-02 11:36:41','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('712','2014-01-02 11:38:07','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('713','2014-01-02 11:39:13','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('714','2014-01-02 11:40:04','otto ','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('715','2014-01-02 11:50:37','otto','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('716','2014-01-02 11:51:07','otto','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('717','2014-01-02 11:51:35','otto','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('718','2014-01-02 11:51:47','otto','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('719','2014-01-02 11:59:25','otto ','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('720','2014-01-02 11:59:54','otto ','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('721','2014-01-02 13:44:40','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('722','2014-01-02 14:41:33','Tracy-Liu','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('723','2014-01-02 14:59:50','otto ','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('724','2014-01-02 15:02:41','otto ','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('725','2014-01-02 15:04:42','Tracy-Liu','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('726','2014-01-02 15:05:03','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('727','2014-01-02 15:05:52','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('728','2014-01-02 15:06:29','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('729','2014-01-02 15:07:22','otto ','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('730','2014-01-02 15:10:09','otto ','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('731','2014-01-02 15:10:39','otto ','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('732','2014-01-02 15:12:27','otto ','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('733','2014-01-02 15:36:05','otto ','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('734','2014-01-02 15:37:16','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('735','2014-01-02 15:37:57','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('736','2014-01-02 15:38:41','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('737','2014-01-02 15:39:30','otto ','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('738','2014-01-02 15:59:00','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('739','2014-01-02 16:05:33','otto ','edit part, barcode=113874676203,name=Rear Bracket - Undefined');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('740','2014-01-02 16:19:57','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('741','2014-01-02 16:20:29','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('742','2014-01-02 16:20:58','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('743','2014-01-02 16:21:45','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('744','2014-01-02 16:23:05','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('745','2014-01-02 16:25:31','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('746','2014-01-02 16:26:05','otto ','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('747','2014-01-02 16:28:46','otto ','edit part, barcode=113874665250,name=Rear Bracket - 2028K - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('748','2014-01-02 16:30:29','otto ','edit part, barcode=113874665250,name=Rear Bracket - 2028K - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('749','2014-01-02 16:33:10','otto ','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('750','2014-01-02 16:33:54','otto ','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('751','2014-01-02 16:36:25','otto ','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('752','2014-01-02 16:37:32','otto ','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('753','2014-01-02 16:39:52','otto ','edit part, barcode=113874667209,name=Front Basket Bracket - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('754','2014-01-02 16:40:57','otto ','edit part, barcode=113874667209,name=Front Basket Bracket - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('755','2014-01-02 16:44:16','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('756','2014-01-02 16:45:45','otto','edit part, barcode=113874676661,name=Backrest bracket - EG2028H - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('757','2014-01-02 16:45:54','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('758','2014-01-02 16:48:52','otto ','edit part, barcode=113874676661,name=Backrest bracket - EG2028H - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('759','2014-01-03 09:35:17','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('760','2014-01-03 09:41:57','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('761','2014-01-03 09:44:00','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('762','2014-01-03 10:06:01','otto','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('763','2014-01-03 10:08:42','otto','edit part, barcode=113875684999,name=Side Rear View Mirror Bass - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('764','2014-01-03 10:09:38','otto','edit part, barcode=113875684999,name=Side Rear View Mirror Bass - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('765','2014-01-03 10:11:00','otto','edit part, barcode=113875683616,name=Side Rear View Mirror Bass - L');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('766','2014-01-03 10:11:23','otto','del part, barcode=113875683616,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('767','2014-01-03 10:50:11','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('768','2014-01-03 11:03:51','otto','edit part, barcode=113875685230,name=Jacket For Caddie Handle -  Piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('769','2014-01-03 11:05:06','otto','edit part, barcode=113875685230,name=Jacket For Caddie Handle -  Piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('770','2014-01-03 11:09:00','otto','edit part, barcode=113875686804,name=Dustproof cover');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('771','2014-01-03 11:29:47','otto','edit part, barcode=113875741190,name=Steering Shaft Bushing');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('772','2014-01-03 11:31:53','otto','edit part, barcode=113875741899,name=Hubcap - Aluminum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('773','2014-01-03 11:37:52','otto','edit part, barcode=113875742842,name=Hubcap - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('774','2014-01-03 11:50:59','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('775','2014-01-03 13:16:14','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('776','2014-01-03 14:15:36','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('777','2014-01-03 14:24:51','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('778','2014-01-03 14:26:51','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('779','2014-01-03 14:27:23','otto','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('780','2014-01-03 14:28:28','otto','edit part, barcode=113875733270,name=Caddie Handle - 35 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('781','2014-01-03 14:30:14','otto','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('782','2014-01-03 14:30:54','otto','edit part, barcode=113875734794,name=Caddie Handle - 33 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('783','2014-01-03 14:31:37','otto','edit part, barcode=113875735287,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('784','2014-01-03 14:34:04','otto','edit part, barcode=113875709563,name=Seat Back Sub-bracket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('785','2014-01-03 14:35:17','otto','edit part, barcode=113875740798,name=Tie Rod');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('786','2014-01-03 14:38:35','otto','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('787','2014-01-03 14:42:26','otto','edit part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('788','2014-01-03 14:44:42','otto','edit part, barcode=113878990619,name=Shackle plate');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('789','2014-01-03 14:46:06','otto','edit part, barcode=113878997974,name=Steering Wheel Cover');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('790','2014-01-03 14:47:28','otto','edit part, barcode=113878991309,name=Flip-Flop Seat Rubber Pad');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('791','2014-01-03 14:48:30','otto','edit part, barcode=113878990073,name=Tyre valve');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('792','2014-01-03 14:50:50','otto','edit part, barcode=113878992304,name=Holding Block - Widshield');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('793','2014-01-03 14:54:16','otto','edit part, barcode=113875696246,name=Back Rest Cover - Plastic ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('794','2014-01-03 14:55:08','otto','edit part, barcode=113875693714,name=Underseat Compartment');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('795','2014-01-03 14:58:58','otto','edit part, barcode=113875527221,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('796','2014-01-03 15:00:47','otto','edit part, barcode=113875528431,name=Split Windshield - Clipping block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('797','2014-01-03 15:09:43','otto','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('798','2014-01-03 15:10:17','otto','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('799','2014-01-03 15:10:51','otto','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('800','2014-01-03 15:36:27','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('801','2014-01-03 15:42:55','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('802','2014-01-03 15:43:30','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('803','2014-01-03 15:55:15','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('804','2014-01-03 16:22:14','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('805','2014-01-03 16:26:59','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('806','2014-01-06 10:12:01','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('807','2014-01-06 10:14:06','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('808','2014-01-06 10:16:08','otto','add new part, barcode=113890212526,name=Top Basket,amount=2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('809','2014-01-06 10:17:55','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('810','2014-01-06 10:19:52','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('811','2014-01-06 10:22:19','otto ','edit part, barcode=113878280024,name=Carbon Brush - Chinese Motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('812','2014-01-06 10:25:15','otto ','edit part, barcode=113878280863,name=Carbon brush - ADC motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('813','2014-01-06 10:28:17','otto ','edit part, barcode=113878275369,name=Tow/Run Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('814','2014-01-06 10:28:53','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('815','2014-01-06 10:29:46','otto ','edit part, barcode=113878275921,name=Brake Light Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('816','2014-01-06 10:42:55','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('817','2014-01-06 10:45:02','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('818','2014-01-06 10:47:35','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('819','2014-01-06 10:47:40','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('820','2014-01-06 10:49:13','otto','add new customer, company:Cart Guy, phone:18889052278');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('821','2014-01-06 10:56:17','otto','add new customer, company:Armada Golf Cars, phone:9057133525');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('822','2014-01-06 11:02:20','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('823','2014-01-06 11:02:57','otto','add new customer, company:Albion Golf Cars, phone: 4162361001');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('824','2014-01-06 11:03:17','otto','edit part, barcode=113878274626,name=Main Fuse - 250A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('825','2014-01-06 11:04:35','otto','edit part, barcode=113878263216,name=Main Fuse - 425A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('826','2014-01-06 11:07:52','otto','edit part, barcode=113878273877,name=Auxiliary relay - 48V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('827','2014-01-06 11:09:16','otto','edit part, barcode=113878272791,name=Electronic Flasher');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('828','2014-01-06 11:10:32','otto','edit part, barcode=113878265368,name=Attach Fuse socket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('829','2014-01-06 11:12:48','otto','edit part, barcode=113878264399,name=Controller Fuse');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('830','2014-01-06 11:13:09','otto','add new customer, company:Albion Golf Cars, phone: 4162361001');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('831','2014-01-06 11:13:41','otto','add new customer, company:Armada Golf Cars, phone:9057133525');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('832','2014-01-06 11:16:09','otto','edit part, barcode=113878277615,name=F/R Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('833','2014-01-06 11:16:46','otto','add new customer, company:Bennett Golf Carts, phone:905-640-7822');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('834','2014-01-06 11:18:49','otto','edit part, barcode=113878286445,name=Hi-Low Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('835','2014-01-06 11:19:15','otto','add new customer, company:Birdie Golf Cart, phone:9058943113');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('836','2014-01-06 11:21:21','otto','edit part, barcode=113878278718,name=Power Meter - 48V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('837','2014-01-06 11:22:12','otto','add new customer, company:Cart Guy, phone:18889052278');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('838','2014-01-06 11:22:48','otto','edit part, barcode=113878272184,name=Time-lapse Relay - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('839','2014-01-06 11:23:56','otto','edit part, barcode=113878278199,name=Power Meter - 36V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('840','2014-01-06 11:25:36','otto','edit part, barcode=113878283060,name=LED light Wire - On board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('841','2014-01-06 11:25:38','otto','edit part, barcode=113878283060,name=LED light Wire - On board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('842','2014-01-06 11:26:24','otto','add new customer, company:Classic Carts (1079245 On Ltd), phone:5197850956');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('843','2014-01-06 11:26:50','otto','edit part, barcode=113875504357,name=Accelerator');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('844','2014-01-06 11:27:54','otto','add new customer, company:Classic Carts , phone:5197850956');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('845','2014-01-06 11:29:06','otto','edit part, barcode=113875505132,name=Main Contactor - 36V 200A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('846','2014-01-06 11:30:21','otto','edit part, barcode=113875506414,name=Main Contactor - 48V 125A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('847','2014-01-06 11:30:32','otto','add new customer, company:Skyway Lawn Equipment Ltd, phone: 905-662-2663');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('848','2014-01-06 11:30:52','otto','add new customer, company:Skyway Lawn Equipment Ltd, phone:9056622663');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('849','2014-01-06 11:31:09','otto','edit part, barcode=113875506414,name=Main Contactor - 48V 125A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('850','2014-01-06 11:33:57','otto','edit part, barcode=113875506733,name=Main Contactor - 48V 300A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('851','2014-01-06 11:35:05','otto','edit part, barcode=113875506994,name=Main Contactor - 48V 100A FSIP');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('852','2014-01-06 11:36:45','otto','edit part, barcode=113875507516,name=Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('853','2014-01-06 11:37:33','otto','add new customer, company:Tilbury Auto Sales &RV, phone:5196822407');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('854','2014-01-06 11:40:06','otto','edit part, barcode=113875508403,name=Meter Holder');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('855','2014-01-06 11:41:32','otto','add new customer, company:Wayne Morrow Auto, phone:18774427162');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('856','2014-01-06 11:41:39','otto','edit part, barcode=113875510340,name=Meter Wires - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('857','2014-01-06 11:42:59','otto','edit part, barcode=113875508802,name=Meter Wires - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('858','2014-01-06 11:44:51','otto','edit part, barcode=113875510757,name=Meter Wires - Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('859','2014-01-06 11:45:02','otto','add new customer, company:Webster Beacon, phone:5196762288');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('860','2014-01-06 11:46:07','otto','add new customer, company:Webster Beacon, phone:5196762288');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('861','2014-01-06 11:46:47','otto','edit part, barcode=113874833776,name=Combination Switch - Non Golf Cart');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('862','2014-01-06 11:48:32','otto','edit part, barcode=113874835726,name=Speed Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('863','2014-01-06 11:49:16','otto','add new customer, company:Diabo Auto Wholesale, phone:4506389009');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('864','2014-01-06 11:49:53','otto','edit part, barcode=113874838896,name=AC Cable ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('865','2014-01-06 11:50:09','otto','add new customer, company:Diabo Auto Wholesale, phone:4506389009');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('866','2014-01-06 11:52:46','otto','add new customer, company:Calgary Golf Carts Centre, phone:4032795025');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('867','2014-01-06 11:56:21','otto','add new customer, company:Golf Car Quebec, phone:5146313775');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('868','2014-01-06 11:59:34','otto','add new customer, company:Real East Import, phone:902-468-8255');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('869','2014-01-06 12:02:36','otto','add new customer, company:Trailer Trash Toyz, phone:7059371411');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('870','2014-01-06 12:45:23','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('871','2014-01-06 13:27:17','Otto-Lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('872','2014-01-06 13:27:22','Otto-Lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('873','2014-01-06 13:27:38','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('874','2014-01-06 13:38:10','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('875','2014-01-06 13:38:15','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('876','2014-01-06 13:38:21','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('877','2014-01-06 13:38:24','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('878','2014-01-06 13:50:35','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('879','2014-01-06 13:50:39','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('880','2014-01-06 13:54:04','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('881','2014-01-06 13:54:06','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('882','2014-01-06 13:54:29','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('883','2014-01-06 13:54:34','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('884','2014-01-06 13:54:40','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('885','2014-01-06 13:54:43','san','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('886','2014-01-06 14:05:41','san','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('887','2014-01-06 14:05:45','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('888','2014-01-06 14:06:03','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('889','2014-01-06 14:06:11','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('890','2014-01-06 14:09:11','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('891','2014-01-06 14:10:27','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('892','2014-01-06 14:10:32','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('893','2014-01-06 14:10:52','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('894','2014-01-06 15:00:15','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('895','2014-01-06 15:01:58','otto ','edit part, barcode=113878269647,name=Reverse Buzzer - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('896','2014-01-06 15:04:34','otto ','edit part, barcode=113878266414,name=Reverse Buzzer - Truck/ Bus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('897','2014-01-06 15:07:30','otto ','edit part, barcode=113878265874,name=Battery Protector');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('898','2014-01-06 15:09:06','otto ','edit part, barcode=113878270780,name=Fuse Box - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('899','2014-01-06 15:10:26','otto ','edit part, barcode=113878276989,name=Universal Start Key');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('900','2014-01-06 15:11:49','otto ','edit part, barcode=113878282586,name=Turn Light Bulb - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('901','2014-01-06 15:12:50','otto ','edit part, barcode=113878282207,name=Head Light Bulb - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('902','2014-01-06 15:14:07','otto ','edit part, barcode=113878284719,name=Rear Light Bulb - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('903','2014-01-06 15:15:34','otto ','edit part, barcode=113878279170,name=Speed Sensor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('904','2014-01-06 15:16:26','otto ','edit part, barcode=113878281176,name=Speed sensor - ADC motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('905','2014-01-06 15:17:15','otto ','edit part, barcode=113878285629,name=Reflector');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('906','2014-01-06 15:18:06','otto ','edit part, barcode=113878283910,name=Turn light bulb - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('907','2014-01-06 15:20:48','otto ','edit part, barcode=113874807201,name=Combination Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('908','2014-01-06 15:26:05','otto ','edit part, barcode=113874816760,name=Converter DC 72V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('909','2014-01-06 15:27:30','otto ','edit part, barcode=113874816760,name=Converter DC 72V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('910','2014-01-06 15:28:28','otto ','edit part, barcode=113874807834,name=Converter DC 48V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('911','2014-01-06 15:30:28','otto ','edit part, barcode=113874808788,name=Converter DC 36V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('912','2014-01-06 15:33:26','otto ','edit part, barcode=113874809185,name=Controller Curtis 1243-4320');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('913','2014-01-06 15:33:29','otto ','edit part, barcode=113874809185,name=Controller Curtis 1243-4320');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('914','2014-01-06 15:35:34','otto ','edit part, barcode=113874816080,name=Controller Curtis 1244-5461');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('915','2014-01-06 15:37:12','otto ','edit part, barcode=113874812661,name=Controller Curtis 1268-5403');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('916','2014-01-06 15:38:38','otto ','edit part, barcode=113874801718,name=Searching Light - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('917','2014-01-06 15:40:09','otto ','edit part, barcode=113874802719,name=Tail Light Assembled - LT - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('918','2014-01-06 15:40:22','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('919','2014-01-06 15:40:52','otto ','edit part, barcode=113874804634,name=Tail Light Assembled - RH - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('920','2014-01-06 15:42:36','otto ','edit part, barcode=113874813410,name=Tail Light - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('921','2014-01-06 15:43:35','otto ','edit part, barcode=113874815828,name=Tail Light - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('922','2014-01-06 15:46:10','otto ','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('923','2014-01-06 15:48:48','otto ','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('924','2014-01-06 15:49:51','otto ','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('925','2014-01-06 15:51:07','otto ','edit part, barcode=113874863430,name=Battery Cable Jacket - Black');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('926','2014-01-06 15:51:48','otto ','edit part, barcode=113874864521,name=Battery Cable Jacket - Red');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('927','2014-01-06 15:53:16','otto-lau','edit part, barcode=113874842091,name=Motor 48V 5.3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('928','2014-01-06 15:53:16','otto ','edit part, barcode=113874880273,name=Connect Wire 25x130mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('929','2014-01-06 15:53:32','otto-lau','edit part, barcode=113874841768,name=Motor 48V 3.8kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('930','2014-01-06 15:53:47','otto-lau','edit part, barcode=113874841056,name=Motor 36V 3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('931','2014-01-06 15:54:02','otto ','edit part, barcode=113875495207,name=Connect Wire 25x200mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('932','2014-01-06 15:54:03','otto-lau','edit part, barcode=113874840236,name=Motor 48V 5KW');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('933','2014-01-06 15:55:13','otto ','edit part, barcode=113875496561,name=Connect Wire 25Ã—440mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('934','2014-01-06 15:56:07','otto ','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('935','2014-01-06 15:57:36','otto ','edit part, barcode=113875495845,name=Connect Wire 25Ã—300mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('936','2014-01-06 15:58:38','otto ','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('937','2014-01-06 15:59:34','otto ','edit part, barcode=113875502090,name=Battery Impact Block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('938','2014-01-06 16:01:23','otto ','edit part, barcode=113874854618,name=Head Light - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('939','2014-01-06 16:02:21','otto ','edit part, barcode=113874855314,name=Head Light - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('940','2014-01-06 16:05:02','otto ','edit part, barcode=113874855716,name=Front Fog Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('941','2014-01-06 16:05:56','otto ','edit part, barcode=113874856197,name=Front Turn Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('942','2014-01-06 16:05:58','otto ','edit part, barcode=113874856197,name=Front Turn Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('943','2014-01-07 09:22:38','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('944','2014-01-07 09:24:01','otto ','edit part, barcode=113874862955,name=Head Light - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('945','2014-01-07 09:28:30','otto ','edit part, barcode=113874862100,name=Tail Light Assembled - RH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('946','2014-01-07 09:29:30','otto ','edit part, barcode=113874862027,name=Tail Light Assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('947','2014-01-07 09:35:40','otto ','edit part, barcode=113875752178,name=Braking Cable Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('948','2014-01-07 09:37:41','otto ','edit part, barcode=113878104955,name=Fender scuffguard - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('949','2014-01-07 09:38:18','otto ','edit part, barcode=113878104955,name=Fender scuffguard - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('950','2014-01-07 09:51:17','otto ','edit part, barcode=113878106177,name=Front Bumper - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('951','2014-01-07 09:53:07','otto ','edit part, barcode=113878106590,name=Front Bumper - EG2020 - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('952','2014-01-07 09:56:55','otto ','edit part, barcode=113875750225,name=Front Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('953','2014-01-07 10:00:45','otto ','edit part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('954','2014-01-07 10:01:07','otto ','edit part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('955','2014-01-07 10:07:53','otto ','edit part, barcode=113878103505,name=Rear Bumper - EG2020/ EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('956','2014-01-07 10:13:08','otto ','edit part, barcode=113878104320,name=Motor Access - EG2028/ EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('957','2014-01-07 10:15:01','otto ','edit part, barcode=113875752475,name=Windshield Wiper - EG6043');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('958','2014-01-07 10:15:18','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('959','2014-01-07 10:15:38','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('960','2014-01-07 10:16:00','otto ','edit part, barcode=113875753656,name=Windshield Wiper - EG6118 (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('961','2014-01-07 10:16:05','otto ','edit part, barcode=113875753656,name=Windshield Wiper - EG6118 (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('962','2014-01-07 10:17:30','otto ','edit part, barcode=113875764620,name=Wheel Nut - Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('963','2014-01-07 10:18:20','otto ','edit part, barcode=113875758458,name=Redirector Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('964','2014-01-07 10:22:41','otto ','edit part, barcode=113875756594,name=Copper Sheath - Thick');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('965','2014-01-07 10:24:21','otto ','edit part, barcode=113875756083,name=Copper Sheath - Thin');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('966','2014-01-07 10:26:21','otto ','edit part, barcode=113875757195,name=Bearing Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('967','2014-01-07 10:29:00','otto ','edit part, barcode=113875757827,name=Bearing 6206-Z');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('968','2014-01-07 10:32:38','otto ','edit part, barcode=113878970448,name=Oil Seal 50.3/43.1/9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('969','2014-01-07 10:32:56','otto-lau','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('970','2014-01-07 10:33:11','otto-lau','edit part, barcode=113874845600,name=Charger - DeltaQ 36V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('971','2014-01-07 10:33:24','otto-lau','edit part, barcode=113874844445,name=Charger - DeltaQ 48V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('972','2014-01-07 10:34:01','otto-lau','edit part, barcode=113874843125,name=Charger - Smart 36V-120V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('973','2014-01-07 10:34:51','otto ','edit part, barcode=113878969596,name=Oil Seal 32/47/8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('974','2014-01-07 10:36:16','otto ','edit part, barcode=113878972137,name=Oil Seal 42/55/7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('975','2014-01-07 10:41:03','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('976','2014-01-07 10:56:25','otto-lau','edit part, barcode=113890212526,name=Top Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('977','2014-01-07 10:56:48','otto-lau','edit part, barcode=113890212526,name=Top Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('978','2014-01-07 10:58:10','otto-lau','edit part, barcode=113890212526,name=Top Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('979','2014-01-07 11:09:12','otto-lau','edit part, barcode=113879005492,name=Battery - Trojan T105');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('980','2014-01-07 11:11:11','otto-lau','edit part, barcode=113879005492,name=Battery - Trojan T105');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('981','2014-01-07 11:12:14','otto-lau','edit part, barcode=113879005228,name=Battery - Trojan T875');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('982','2014-01-07 11:12:49','otto-lau','edit part, barcode=113879004663,name=Battery - US 2200');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('983','2014-01-07 11:19:57','otto-lau','edit car, barcode=013878248948,name=HOBBIT 4+H');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('984','2014-01-07 11:43:54','otto-lau','edit part, barcode=113878103106,name=Rear Axle Assembly ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('985','2014-01-07 11:44:10','otto-lau','edit part, barcode=113878099978,name=Front Axle Assembly - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('986','2014-01-07 11:44:50','otto-lau','edit part, barcode=113878099978,name=Front Axle Assembly - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('987','2014-01-07 13:12:43','otto ','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('988','2014-01-07 13:13:58','otto ','edit part, barcode=113878086410,name=Seat Belt Set - 3 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('989','2014-01-07 13:18:14','otto ','edit part, barcode=113878082911,name=Seat Belt Set - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('990','2014-01-07 13:22:32','otto ','edit part, barcode=113878107737,name=Front Shock Absorber Assembly - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('991','2014-01-07 13:23:48','otto ','edit part, barcode=113878109179,name=Front Shock Absorber Assembly - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('992','2014-01-07 13:25:11','otto ','edit part, barcode=113878109505,name=Front Shock Absorber Assembly - Unidentified');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('993','2014-01-07 13:28:14','otto ','edit part, barcode=113878110008,name=Left Knuckle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('994','2014-01-07 13:29:19','otto ','edit part, barcode=113878112510,name=Right Knuckle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('995','2014-01-07 13:32:26','otto ','edit part, barcode=113878112939,name=Watering System');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('996','2014-01-07 13:34:30','otto ','edit part, barcode=113878118605,name=Tie Rod Joint');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('997','2014-01-07 13:35:16','otto ','edit part, barcode=113878118605,name=Tie Rod Joint');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('998','2014-01-07 13:36:40','otto ','edit part, barcode=113878115393,name=Seat Belt Set - 3 point (Large)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('999','2014-01-07 13:39:08','otto ','edit part, barcode=113878114441,name=Rear Leaf Spring Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1000','2014-01-07 13:42:00','otto ','edit part, barcode=113878098067,name=Brake Shoe - Unidentified');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1001','2014-01-07 13:43:31','otto ','edit part, barcode=113878096654,name=Brake Shoe');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1002','2014-01-07 13:44:32','otto ','edit part, barcode=113878094409,name=Rear Brake assembly LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1003','2014-01-07 13:46:19','otto ','edit part, barcode=113878093952,name=Rear Brake assembly RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1004','2014-01-07 13:46:26','otto ','edit part, barcode=113878093952,name=Rear Brake assembly RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1005','2014-01-07 13:47:51','otto ','edit part, barcode=113878088998,name=Front Axle Assembly - Semi');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1006','2014-01-07 13:50:40','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1007','2014-01-07 13:52:01','otto ','edit part, barcode=113878088327,name=Front Axle Assembly - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1008','2014-01-07 13:54:07','otto ','edit part, barcode=113875511107,name=Battery Impact Block Cap');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1009','2014-01-07 13:56:10','otto ','edit part, barcode=113878118930,name=Rear Brake Drum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1010','2014-01-07 13:59:26','otto ','edit part, barcode=113875687755,name=Floor Mat - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1011','2014-01-07 14:00:44','otto-lau','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1012','2014-01-07 14:04:26','otto ','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1013','2014-01-07 14:04:51','otto ','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1014','2014-01-07 14:05:24','otto ','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1015','2014-01-07 14:05:54','otto ','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1016','2014-01-07 14:06:55','otto ','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1017','2014-01-07 14:12:35','otto-lau','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1018','2014-01-07 14:17:39','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1019','2014-01-07 14:27:52','otto ','edit part, barcode=113855780864,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1020','2014-01-07 14:51:43','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1021','2014-01-08 09:03:42','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1022','2014-01-08 09:09:30','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1023','2014-01-08 09:23:49','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1024','2014-01-08 11:04:16','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1025','2014-01-08 11:08:17','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1026','2014-01-08 11:08:30','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1027','2014-01-08 11:08:42','Otto-Lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1028','2014-01-08 11:10:26','Otto-Lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1029','2014-01-08 11:10:34','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1030','2014-01-08 11:11:36','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1031','2014-01-08 11:11:41','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1032','2014-01-08 11:26:45','otto-lau','edit part, barcode=113890212526,name=Top Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1033','2014-01-08 11:27:10','otto-lau','edit part, barcode=113890212526,name=Top Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1034','2014-01-08 11:39:55','otto-lau','edit part, barcode=113874838896,name=AC Cable ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1035','2014-01-08 13:14:19','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1036','2014-01-08 13:14:42','otto-lau','edit part, barcode=113874837101,name=AC Cable Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1037','2014-01-08 13:54:52','otto-lau','edit part, barcode=113878275921,name=Brake Light Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1038','2014-01-09 09:15:30','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1039','2014-01-09 09:19:24','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1040','2014-01-09 11:20:52','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1041','2014-01-09 11:25:35','otto-lau','edit part, barcode=113874811211,name=Controller Curtis 1266-5201');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1042','2014-01-09 11:59:47','boyao-wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1043','2014-01-09 14:42:32','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1044','2014-01-09 15:04:32','otto-lau','edit part, barcode=113878271280,name=Electric Horn - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1045','2014-01-09 15:14:34','otto-lau','del part, barcode=113855780864,name=');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1046','2014-01-09 16:55:05','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1047','2014-01-10 09:34:12','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1048','2014-01-10 10:56:11','otto-lau','edit part, barcode=113875527221,name=Split Windshield - Clipping block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1049','2014-01-10 10:56:47','otto-lau','edit part, barcode=113875528431,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1050','2014-01-10 11:46:25','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1051','2014-01-10 14:21:13','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1052','2014-01-13 09:07:48','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1053','2014-01-13 11:11:08','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1054','2014-01-13 13:00:15','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1055','2014-01-13 13:11:33','Boyao-Wang','add new customer, company:Abibaba Wholesale Inc., phone:19056690305');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1056','2014-01-13 13:22:08','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1057','2014-01-14 09:25:07','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1058','2014-01-14 13:09:45','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1059','2014-01-14 13:20:52','boyao-wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1060','2014-01-14 13:37:28','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1061','2014-01-14 15:15:39','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1062','2014-01-14 15:18:32','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1063','2014-01-14 15:22:43','otto-lau','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1064','2014-01-14 15:24:47','otto-lau','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1065','2014-01-14 15:32:05','otto-lau','add new part, barcode=113897315200,name=Wheel 24x8-12 WAN DA with Aluminum Rim,amount=4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1066','2014-01-15 09:46:19','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1067','2014-01-15 09:47:38','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1068','2014-01-15 09:47:41','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1069','2014-01-15 09:50:35','Boyao-Wang','edit car, barcode=013849843596,name=HULK');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1070','2014-01-15 09:51:40','Tracy-Liu','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1071','2014-01-15 09:51:47','Tracy-Liu','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1072','2014-01-15 09:51:56','Tracy-Liu','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1073','2014-01-15 15:53:55','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1074','2014-01-15 16:54:25','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1075','2014-01-15 16:58:02','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1076','2014-01-15 17:08:10','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1077','2014-01-16 09:03:02','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1078','2014-01-16 09:03:11','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1079','2014-01-16 09:24:17','luke-li','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1080','2014-01-16 09:27:11','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1081','2014-01-17 09:39:31','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1082','2014-01-17 09:45:16','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1083','2014-01-17 10:36:44','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1084','2014-01-17 13:27:07','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1085','2014-01-17 14:31:52','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1086','2014-01-20 09:57:25','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1087','2014-01-20 10:12:33','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1088','2014-01-20 10:27:54','otto-lau','edit part, barcode=113874838896,name=AC Cable ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1089','2014-01-20 10:33:20','otto-lau','edit part, barcode=113875504357,name=Accelerator');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1090','2014-01-20 10:33:42','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1091','2014-01-20 10:34:36','otto-lau','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1092','2014-01-20 11:02:31','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1093','2014-01-20 12:10:23','otto-lau','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1094','2014-01-20 12:11:27','otto-lau','edit part, barcode=113878265368,name=Attach Fuse socket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1095','2014-01-20 12:12:25','otto-lau','edit part, barcode=113878273877,name=Auxiliary relay - 48V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1096','2014-01-20 12:12:41','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1097','2014-01-20 12:12:54','otto-lau','edit part, barcode=113878273877,name=Auxiliary relay - 48V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1098','2014-01-20 12:14:45','otto-lau','edit part, barcode=113875696246,name=Back Rest Cover - Plastic ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1099','2014-01-20 12:15:36','otto-lau','edit part, barcode=113874676661,name=Backrest bracket - EG2028H - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1100','2014-01-20 12:18:34','otto-lau','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1101','2014-01-20 12:29:39','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1102','2014-01-20 14:53:04','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1103','2014-01-22 09:21:56','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1104','2014-01-22 09:22:00','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1105','2014-01-22 11:31:56','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1106','2014-01-22 13:14:07','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1107','2014-01-22 13:18:55','otto-lau','add new car, barcode=013904144693,name=Cricket 2,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1108','2014-01-22 13:26:55','otto-lau','edit car, barcode=013904144693,name=Cricket 2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1109','2014-01-22 13:44:46','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1110','2014-01-22 14:16:10','otto-lau','edit car, barcode=013904144693,name=CRICKET');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1111','2014-01-22 14:16:24','otto-lau','edit car, barcode=013904144693,name=CRICKET 2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1112','2014-01-22 14:28:05','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1113','2014-01-22 14:59:18','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1114','2014-01-22 15:03:14','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1115','2014-01-22 15:03:30','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1116','2014-01-22 15:03:33','Tracy-Liu','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1117','2014-01-22 15:03:52','Allen-Cai','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1118','2014-01-22 15:31:19','otto-lau','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1119','2014-01-22 15:33:12','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1120','2014-01-22 15:40:22','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1121','2014-01-22 15:40:54','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1122','2014-01-22 15:45:40','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1123','2014-01-23 09:17:03','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1124','2014-01-23 10:00:28','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1125','2014-01-23 11:28:13','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1126','2014-01-23 16:34:53','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1127','2014-01-23 16:37:48','Boyao-Wang','add new customer, company:Seaspan Ferries, phone:604 940 7239');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1128','2014-01-24 09:23:44','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1129','2014-01-24 09:30:00','otto-lau','edit part, barcode=113897315200,name=Wheel 24x8-12 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1130','2014-01-24 09:31:09','otto-lau','edit part, barcode=113875504357,name=Accelerator');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1131','2014-01-24 09:31:48','otto-lau','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1132','2014-01-24 09:32:10','otto-lau','edit part, barcode=113861036513,name=Assembly of Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1133','2014-01-24 09:32:40','otto-lau','edit part, barcode=113878265368,name=Attach Fuse socket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1134','2014-01-24 09:32:52','otto-lau','edit part, barcode=113878273877,name=Auxiliary relay - 48V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1135','2014-01-24 09:44:40','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1136','2014-01-24 13:10:47','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1137','2014-01-24 13:11:26','otto-lau','edit part, barcode=113875696246,name=Back Rest Cover - Plastic ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1138','2014-01-24 13:11:48','otto-lau','edit part, barcode=113874676661,name=Backrest bracket - EG2028H - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1139','2014-01-24 13:13:07','otto-lau','edit part, barcode=113874020209,name=Backrest Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1140','2014-01-24 13:13:55','otto-lau','edit part, barcode=113874863430,name=Battery Cable Jacket - Black');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1141','2014-01-24 13:14:08','otto-lau','edit part, barcode=113874864521,name=Battery Cable Jacket - Red');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1142','2014-01-24 13:14:29','otto-lau','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1143','2014-01-24 13:14:40','otto-lau','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1144','2014-01-24 13:15:04','otto-lau','edit part, barcode=113875502090,name=Battery Impact Block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1145','2014-01-24 13:16:31','otto-lau','edit part, barcode=113875511107,name=Battery Impact Block Cap');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1146','2014-01-24 13:17:15','otto-lau','edit part, barcode=113878265874,name=Battery Protector');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1147','2014-01-24 13:20:05','otto-lau','edit part, barcode=113875757827,name=Bearing 6206-Z');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1148','2014-01-24 13:20:35','otto-lau','edit part, barcode=113875757195,name=Bearing Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1149','2014-01-24 13:20:52','otto-lau','edit part, barcode=113878275921,name=Brake Light Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1150','2014-01-24 13:21:22','otto-lau','edit part, barcode=113878096654,name=Brake Shoe');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1151','2014-01-24 13:23:09','otto-lau','edit part, barcode=113875734794,name=Caddie Handle - 33 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1152','2014-01-24 13:23:22','otto-lau','edit part, barcode=113875733270,name=Caddie Handle - 35 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1153','2014-01-24 13:24:03','otto-lau','edit part, barcode=113875735287,name=Caddie Handle - 38.5 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1154','2014-01-24 13:24:36','otto-lau','edit part, barcode=113875732227,name=Caddie Handle - 38.5 inches (Old Model)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1155','2014-01-24 13:24:47','otto-lau','edit part, barcode=113875734063,name=Caddie Handle - 39 inches');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1156','2014-01-24 13:26:25','otto-lau','edit part, barcode=113875703804,name=Canopy Handle - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1157','2014-01-24 13:26:58','otto-lau','edit part, barcode=113875682157,name=Canopy Handle - 2028 - 4 Passenger Plus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1158','2014-01-24 13:28:20','otto-lau','edit part, barcode=113878280863,name=Carbon brush - ADC motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1159','2014-01-24 13:29:09','otto-lau','edit part, barcode=113878280024,name=Carbon Brush - Chinese Motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1160','2014-01-24 13:31:19','otto-lau','edit part, barcode=113875562993,name=Cargo Box - Manual Dump - Handle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1161','2014-01-24 13:32:22','otto-lau','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1162','2014-01-24 13:32:32','otto-lau','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1163','2014-01-24 13:32:45','otto-lau','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1164','2014-01-24 13:33:05','otto-lau','edit part, barcode=113874694069,name=Cargo Box Bracket Support');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1165','2014-01-24 13:38:44','otto-lau','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1166','2014-01-24 13:42:45','otto-lau','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1167','2014-01-24 13:43:50','otto-lau','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1168','2014-01-24 13:44:06','otto-lau','edit part, barcode=113874688608,name=Cargo Box Support Bracket - 2048HCX');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1169','2014-01-24 14:29:47','otto-lau','edit part, barcode=113874845600,name=Charger - DeltaQ 36V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1170','2014-01-24 14:30:07','otto-lau','edit part, barcode=113874844445,name=Charger - DeltaQ 48V-110');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1171','2014-01-24 14:30:28','otto-lau','edit part, barcode=113874845946,name=Charger - DeltaQ 72V-110V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1172','2014-01-24 14:31:17','otto-lau','edit part, barcode=113874843125,name=Charger - Smart 36V-120V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1173','2014-01-24 14:31:37','otto-lau','edit part, barcode=113874807201,name=Combination Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1174','2014-01-24 14:31:53','otto-lau','edit part, barcode=113874833776,name=Combination Switch - Non Golf Cart');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1175','2014-01-24 14:32:52','otto-lau','edit part, barcode=113875495845,name=Connect Wire 25Ã—300mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1176','2014-01-24 14:33:05','otto-lau','edit part, barcode=113875496561,name=Connect Wire 25Ã—440mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1177','2014-01-24 14:33:12','otto-lau','edit part, barcode=113874880273,name=Connect Wire 25x130mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1178','2014-01-24 14:33:19','otto-lau','edit part, barcode=113875495207,name=Connect Wire 25x200mm ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1179','2014-01-24 14:33:56','otto-lau','edit part, barcode=113874809185,name=Controller Curtis 1243-4320');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1180','2014-01-24 14:34:12','otto-lau','edit part, barcode=113874816080,name=Controller Curtis 1244-5461');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1181','2014-01-24 14:34:36','otto-lau','edit part, barcode=113874811211,name=Controller Curtis 1266-5201');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1182','2014-01-24 14:34:52','otto-lau','edit part, barcode=113874812661,name=Controller Curtis 1268-5403');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1183','2014-01-24 14:35:02','otto-lau','edit part, barcode=113878264399,name=Controller Fuse');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1184','2014-01-24 14:38:39','otto-lau','edit part, barcode=113874808788,name=Converter DC 36V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1185','2014-01-24 14:38:48','otto-lau','edit part, barcode=113874807834,name=Converter DC 48V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1186','2014-01-24 14:39:04','otto-lau','edit part, barcode=113874816760,name=Converter DC 72V-12V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1187','2014-01-24 14:39:19','otto-lau','edit part, barcode=113875756594,name=Copper Sheath - Thick');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1188','2014-01-24 14:39:26','otto-lau','edit part, barcode=113875756083,name=Copper Sheath - Thin');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1189','2014-01-24 14:59:34','otto-lau','edit part, barcode=113861020767,name=Drivers Seat');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1190','2014-01-24 14:59:52','otto-lau','edit part, barcode=113875686804,name=Dustproof cover');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1191','2014-01-24 15:49:02','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1192','2014-01-24 15:49:21','otto-lau','edit part, barcode=113875519554,name=EG6020A4D Battery Cover on Front Body');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1193','2014-01-24 15:49:41','otto-lau','edit part, barcode=113878271280,name=Electric Horn - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1194','2014-01-24 15:49:59','otto-lau','edit part, barcode=113878272791,name=Electronic Flasher');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1195','2014-01-24 15:50:28','otto-lau','edit part, barcode=113878277615,name=F/R Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1196','2014-01-24 15:50:40','otto-lau','edit part, barcode=113878104955,name=Fender scuffguard - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1197','2014-01-24 15:50:49','otto-lau','edit part, barcode=113878104955,name=Fender scuffguard - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1198','2014-01-24 15:50:56','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1199','2014-01-28 09:07:54','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1200','2014-01-28 10:17:01','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1201','2014-01-28 13:04:55','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1202','2014-01-28 13:08:19','otto-lau','edit part, barcode=113855787534,name=Flip-Flop Seat Kit');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1203','2014-01-28 13:08:48','otto-lau','edit part, barcode=113878991309,name=Flip-Flop Seat Rubber Pad');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1204','2014-01-28 13:09:07','otto-lau','edit part, barcode=113875688937,name=Floor Mat - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1205','2014-01-28 14:02:19','otto-lau','edit part, barcode=113875687755,name=Floor Mat - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1206','2014-01-28 14:02:45','otto-lau','edit part, barcode=113878088998,name=Front Axle Assembly - Semi');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1207','2014-01-28 14:02:58','otto-lau','edit part, barcode=113874657396,name=Front Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1208','2014-01-28 14:03:24','otto-lau','edit part, barcode=113874667209,name=Front Basket Bracket - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1209','2014-01-28 15:07:42','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1210','2014-01-28 15:08:20','otto-lau','edit part, barcode=113878123902,name=Front Bracket - EG2020ASZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1211','2014-01-28 15:08:34','otto-lau','edit part, barcode=113878120972,name=Front Bracket - Normal');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1212','2014-01-28 15:08:48','otto-lau','edit part, barcode=113878106590,name=Front Bumper - EG2020 - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1213','2014-01-28 15:09:02','otto-lau','edit part, barcode=113878106177,name=Front Bumper - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1214','2014-01-28 15:09:16','otto-lau','edit part, barcode=113874008674,name=Front Bumper - Metallic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1215','2014-01-28 15:13:11','otto-lau','edit part, barcode=113860007132,name=Front Cover - Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1216','2014-01-28 15:13:27','otto-lau','edit part, barcode=113860007207,name=Front Cover - Camouflage - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1217','2014-01-28 15:13:37','otto-lau','edit part, barcode=113860002295,name=Front Cover - Metallic Green - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1218','2014-01-28 15:13:46','otto-lau','edit part, barcode=113860005355,name=Front Cover - Pure Black - Used');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1219','2014-01-28 15:14:28','otto-lau','edit part, barcode=113874855716,name=Front Fog Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1220','2014-01-28 15:14:57','otto-lau','edit part, barcode=113878107737,name=Front Shock Absorber Assembly - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1221','2014-01-28 15:15:12','otto-lau','edit part, barcode=113878109179,name=Front Shock Absorber Assembly - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1222','2014-01-28 15:15:32','otto-lau','edit part, barcode=113878109505,name=Front Shock Absorber Assembly - Unidentified');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1223','2014-01-28 15:15:44','otto-lau','edit part, barcode=113874856197,name=Front Turn Light - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1224','2014-01-28 15:16:09','otto-lau','edit part, barcode=113875750225,name=Front Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1225','2014-01-28 15:16:22','otto-lau','edit part, barcode=113878270780,name=Fuse Box - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1226','2014-01-28 15:49:55','otto-lau','edit part, barcode=113874862955,name=Head Light - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1227','2014-01-28 15:50:09','otto-lau','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1228','2014-01-28 15:50:33','otto-lau','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1229','2014-01-28 15:50:49','otto-lau','edit part, barcode=113874854618,name=Head Light - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1230','2014-01-28 15:50:55','otto-lau','edit part, barcode=113874855314,name=Head Light - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1231','2014-01-28 15:51:15','otto-lau','edit part, barcode=113878282207,name=Head Light Bulb - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1232','2014-01-28 15:55:22','otto-lau','edit part, barcode=113878286445,name=Hi-Low Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1233','2014-01-28 15:55:32','otto-lau','edit part, barcode=113878992304,name=Holding Block - Widshield');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1234','2014-01-28 15:55:42','otto-lau','edit part, barcode=113875741899,name=Hubcap - Aluminum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1235','2014-01-28 15:55:55','otto-lau','edit part, barcode=113875742842,name=Hubcap - Plastic');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1236','2014-01-28 15:56:15','otto-lau','edit part, barcode=113874660495,name=Inner Rearview Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1237','2014-01-28 15:56:25','otto-lau','edit part, barcode=113875685230,name=Jacket For Caddie Handle -  Piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1238','2014-01-28 15:56:54','otto-lau','edit part, barcode=113878283060,name=LED light Wire - On board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1239','2014-01-28 15:57:30','otto-lau','edit part, barcode=113856688278,name=Left Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1240','2014-01-28 15:57:46','otto-lau','edit part, barcode=113878110008,name=Left Knuckle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1241','2014-01-28 15:57:58','otto-lau','edit part, barcode=113875505132,name=Main Contactor - 36V 200A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1242','2014-01-28 15:59:21','otto-lau','edit part, barcode=113875506994,name=Main Contactor - 48V 100A FSIP');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1243','2014-01-28 15:59:58','otto-lau','edit part, barcode=113875506414,name=Main Contactor - 48V 125A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1244','2014-01-28 16:00:12','otto-lau','edit part, barcode=113875506733,name=Main Contactor - 48V 300A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1245','2014-01-28 16:00:33','otto-lau','edit part, barcode=113875506994,name=Main Contactor - 48V 100A FSIP');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1246','2014-01-28 16:00:54','otto-lau','edit part, barcode=113875506414,name=Main Contactor - 48V 125A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1247','2014-01-28 16:14:03','otto-lau','edit part, barcode=113878274626,name=Main Fuse - 250A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1248','2014-01-28 16:14:14','otto-lau','edit part, barcode=113878263216,name=Main Fuse - 425A');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1249','2014-01-28 16:14:26','otto-lau','edit part, barcode=113875507516,name=Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1250','2014-01-28 16:14:36','otto-lau','edit part, barcode=113875508403,name=Meter Holder');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1251','2014-01-28 16:14:48','otto-lau','edit part, barcode=113875510757,name=Meter Wires - Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1252','2014-01-28 16:15:01','otto-lau','edit part, barcode=113875508802,name=Meter Wires - Long');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1253','2014-01-28 16:15:08','otto-lau','edit part, barcode=113875510340,name=Meter Wires - Short');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1254','2014-01-29 09:55:13','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1255','2014-01-29 09:55:59','otto-lau','edit part, barcode=113874841056,name=Motor 36V 3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1256','2014-01-29 09:56:10','otto-lau','edit part, barcode=113874841768,name=Motor 48V 3.8kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1257','2014-01-29 09:56:23','otto-lau','edit part, barcode=113874842091,name=Motor 48V 5.3kw');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1258','2014-01-29 09:56:38','otto-lau','edit part, barcode=113874840236,name=Motor 48V 5KW');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1259','2014-01-29 09:57:14','otto-lau','edit part, barcode=113878104320,name=Motor Access - EG2028/ EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1260','2014-01-29 09:57:25','otto-lau','edit part, barcode=113875523072,name=Motor Access EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1261','2014-01-29 09:57:35','otto-lau','edit part, barcode=113875525170,name=Motor Cover - EG6040A4D');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1262','2014-01-29 09:57:55','otto-lau','edit part, barcode=113878969596,name=Oil Seal 32/47/8');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1263','2014-01-29 09:58:01','otto-lau','edit part, barcode=113878972137,name=Oil Seal 42/55/7');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1264','2014-01-29 09:58:09','otto-lau','edit part, barcode=113878970448,name=Oil Seal 50.3/43.1/9');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1265','2014-01-29 09:58:21','otto-lau','edit part, barcode=113861020003,name=Passenger Seat EG6158');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1266','2014-01-29 09:59:22','otto-lau','edit part, barcode=113878278199,name=Power Meter - 36V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1267','2014-01-29 09:59:33','otto-lau','edit part, barcode=113878278718,name=Power Meter - 48V');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1268','2014-01-29 10:00:32','otto-lau','edit part, barcode=113874661256,name=Rear Bracket - 2020ASZ - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1269','2014-01-29 10:00:45','otto-lau','edit part, barcode=113874665250,name=Rear Bracket - 2028K - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1270','2014-01-29 10:00:58','otto-lau','edit part, barcode=113874666349,name=Rear Bracket - 2028KSF - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1271','2014-01-29 10:01:13','otto-lau','edit part, barcode=113874676203,name=Rear Bracket - Undefined');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1272','2014-01-29 10:01:33','otto-lau','edit part, barcode=113878094409,name=Rear Brake assembly LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1273','2014-01-29 10:01:44','otto-lau','edit part, barcode=113878093952,name=Rear Brake assembly RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1274','2014-01-29 10:01:54','otto-lau','edit part, barcode=113878118930,name=Rear Brake Drum');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1275','2014-01-29 10:02:10','otto-lau','edit part, barcode=113878103505,name=Rear Bumper - EG2020/ EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1276','2014-01-29 10:02:51','otto-lau','edit part, barcode=113878114441,name=Rear Leaf Spring Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1277','2014-01-29 10:03:08','otto-lau','edit part, barcode=113874668190,name=Rear Standing Board');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1278','2014-01-29 10:03:28','otto-lau','edit part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1279','2014-01-29 10:03:52','otto-lau','edit part, barcode=113875758458,name=Redirector Assembly');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1280','2014-01-29 10:04:00','otto-lau','edit part, barcode=113878285629,name=Reflector');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1281','2014-01-29 10:04:13','otto-lau','edit part, barcode=113878269647,name=Reverse Buzzer - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1282','2014-01-29 10:04:25','otto-lau','edit part, barcode=113878266414,name=Reverse Buzzer - Truck/ Bus');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1283','2014-01-29 10:12:26','otto-lau','edit part, barcode=113856688951,name=Right Half Axle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1284','2014-01-29 10:12:51','otto-lau','edit part, barcode=113878112510,name=Right Knuckle');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1285','2014-01-29 10:13:08','otto-lau','edit part, barcode=113875563935,name=Sash (Clipper)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1286','2014-01-29 10:13:19','otto-lau','edit part, barcode=113875628522,name=Sash (Clipper) - One piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1287','2014-01-29 10:13:36','otto-lau','edit part, barcode=113874801718,name=Searching Light - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1288','2014-01-29 10:13:47','otto-lau','edit part, barcode=113874701375,name=Searching Light Bracket 1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1289','2014-01-29 10:14:13','otto-lau','edit part, barcode=113875709563,name=Seat Back Sub-bracket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1290','2014-01-29 10:14:51','otto-lau','edit part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1291','2014-01-29 10:15:48','otto-lau','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1292','2014-01-29 10:16:26','otto-lau','edit part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1293','2014-01-29 10:16:40','otto-lau','edit part, barcode=113878082911,name=Seat Belt Set - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1294','2014-01-29 10:16:50','otto-lau','edit part, barcode=113878086410,name=Seat Belt Set - 3 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1295','2014-01-29 10:17:30','otto-lau','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1296','2014-01-29 10:17:49','otto-lau','edit part, barcode=113874690781,name=Seat Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1297','2014-01-29 10:18:00','otto-lau','edit part, barcode=113878990619,name=Shackle plate');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1298','2014-01-29 10:18:09','otto-lau','edit part, barcode=113878261008,name=Shunt');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1299','2014-01-29 10:18:46','otto-lau','edit part, barcode=113874689510,name=Side Armrest');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1300','2014-01-29 10:19:05','otto-lau','edit part, barcode=113874033533,name=Side Rear View Mirror');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1301','2014-01-29 10:19:17','otto-lau','edit part, barcode=113875517870,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1302','2014-01-29 10:19:26','otto-lau','edit part, barcode=113875518830,name=Side rear view mirror - LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1303','2014-01-29 10:19:38','otto-lau','edit part, barcode=113878320669,name=Side Rear View Mirror - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1304','2014-01-29 10:19:45','otto-lau','edit part, barcode=113878321298,name=Side Rear View Mirror - RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1305','2014-01-29 10:20:34','otto-lau','edit part, barcode=113875684999,name=Side Rear View Mirror Bass - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1306','2014-01-29 10:21:15','otto-lau','edit part, barcode=113878279170,name=Speed Sensor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1307','2014-01-29 10:21:25','otto-lau','edit part, barcode=113878281176,name=Speed sensor - ADC motor');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1308','2014-01-29 10:21:36','otto-lau','edit part, barcode=113875528431,name=Split Windshield - Slip block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1309','2014-01-29 10:21:46','otto-lau','edit part, barcode=113875741190,name=Steering Shaft Bushing');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1310','2014-01-29 10:21:56','otto-lau','edit part, barcode=113878997974,name=Steering Wheel Cover');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1311','2014-01-29 10:22:05','otto-lau','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1312','2014-01-29 10:22:15','otto-lau','edit part, barcode=113875707186,name=Sweater Basket Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1313','2014-01-29 10:22:40','otto-lau','edit part, barcode=113874813410,name=Tail Light - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1314','2014-01-29 10:22:47','otto-lau','edit part, barcode=113874815828,name=Tail Light - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1315','2014-01-29 10:23:01','otto-lau','edit part, barcode=113874802719,name=Tail Light Assembled - LT - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1316','2014-01-29 10:23:07','otto-lau','edit part, barcode=113874804634,name=Tail Light Assembled - RH - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1317','2014-01-29 10:23:20','otto-lau','edit part, barcode=113875740798,name=Tie Rod');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1318','2014-01-29 10:23:50','otto-lau','edit part, barcode=113878118605,name=Tie Rod Joint');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1319','2014-01-29 10:24:00','otto-lau','edit part, barcode=113878272184,name=Time-lapse Relay - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1320','2014-01-29 10:24:11','otto-lau','edit part, barcode=113890212526,name=Top Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1321','2014-01-29 10:24:27','otto-lau','edit part, barcode=113878120248,name=Top Canopy Bracket - EG2028KSF/ EG2028KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1322','2014-01-29 10:24:36','otto-lau','edit part, barcode=113878122294,name=Top Canopy Bracket - EG2048KSF/ 2048KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1323','2014-01-29 10:24:47','otto-lau','edit part, barcode=113878123216,name=Top Canopy Bracket - EG2068KSZ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1324','2014-01-29 10:25:08','otto-lau','edit part, barcode=113878275369,name=Tow/Run Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1325','2014-01-29 10:25:15','otto-lau','edit part, barcode=113878275369,name=Tow/Run Switch');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1326','2014-01-29 10:25:28','otto-lau','edit part, barcode=113878283910,name=Turn light bulb - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1327','2014-01-29 10:25:34','otto-lau','edit part, barcode=113878283910,name=Turn light bulb - EG2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1328','2014-01-29 10:25:46','otto-lau','edit part, barcode=113878282586,name=Turn Light Bulb - EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1329','2014-01-29 10:25:54','otto-lau','edit part, barcode=113878990073,name=Tyre valve');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1330','2014-01-29 10:26:04','otto-lau','edit part, barcode=113875693714,name=Underseat Compartment');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1331','2014-01-29 10:26:13','otto-lau','edit part, barcode=113878276989,name=Universal Start Key');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1332','2014-01-29 10:27:17','otto-lau','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1333','2014-01-29 10:27:29','otto-lau','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1334','2014-01-29 10:27:44','otto-lau','edit part, barcode=113878983894,name=Wheel 21x11-10 CST/ Aluminum Rim F - Damaged');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1335','2014-01-29 10:27:52','otto-lau','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1336','2014-01-29 10:28:04','otto-lau','edit part, barcode=113897315200,name=Wheel 24x8-12 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1337','2014-01-29 10:28:11','otto-lau','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1338','2014-01-29 10:28:19','otto-lau','edit part, barcode=113875764620,name=Wheel Nut - Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1339','2014-01-29 10:53:17','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1340','2014-01-29 13:47:21','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1341','2014-01-29 13:49:33','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1342','2014-01-30 09:37:45','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1343','2014-01-30 10:21:05','otto-lau','add new customer, company:Otterville Custom Golf Carts, phone:519-468-3617');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1344','2014-01-30 13:42:21','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1345','2014-01-30 13:43:19','otto-lau','edit part, barcode=113874033533,name=Side Rear View Mirror (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1346','2014-01-30 13:53:32','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1347','2014-01-30 14:58:50','otto-lau','edit part, barcode=113874838896,name=AC Cable ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1348','2014-01-30 14:59:26','otto-lau','edit part, barcode=113874837101,name=AC Cable Extension');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1349','2014-01-30 15:02:33','otto-lau','edit part, barcode=113875706287,name=Arm Rest - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1350','2014-01-30 15:03:18','otto-lau','edit part, barcode=113878265368,name=Attach Fuse socket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1351','2014-01-30 15:03:27','otto-lau','edit part, barcode=113878264399,name=Controller Fuse');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1352','2014-01-30 15:04:11','otto-lau','edit part, barcode=113875696246,name=Back Rest Cover - Plastic ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1353','2014-01-30 15:04:22','otto-lau','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1354','2014-01-31 10:10:29','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1355','2014-01-31 10:20:51','otto-lau','edit part, barcode=113875511107,name=Battery Impact Block Cap');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1356','2014-01-31 10:20:58','otto-lau','edit part, barcode=113875499828,name=Battery Dead Lever - L End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1357','2014-01-31 10:21:27','otto-lau','edit part, barcode=113875502687,name=Battery Dead Lever - S End');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1358','2014-01-31 10:21:33','otto-lau','edit part, barcode=113875502090,name=Battery Impact Block');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1359','2014-01-31 10:32:52','otto-lau','edit part, barcode=113856726477,name=Cargo Box Aluminium - Non Standard - 1000x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1360','2014-01-31 10:33:00','otto-lau','edit part, barcode=113856730198,name=Cargo Box Aluminum - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1361','2014-01-31 10:33:06','otto-lau','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1362','2014-01-31 10:33:12','otto-lau','edit part, barcode=113856726379,name=Cargo Box Carbon Steel - Non Standard - 1000x1100x250');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1363','2014-01-31 10:37:27','otto-lau','edit part, barcode=113856732204,name=Cargo Box Carbon Steel - Standard - 770x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1364','2014-01-31 10:37:34','otto-lau','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1365','2014-01-31 10:38:20','otto-lau','edit part, barcode=113856717210,name=Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1366','2014-01-31 10:38:27','otto-lau','edit part, barcode=113856724550,name=Cargo Box Aluminum- Manual Dump - 1400x1100x250 ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1367','2014-01-31 14:56:58','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1368','2014-01-31 14:57:44','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1369','2014-02-03 13:45:34','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1370','2014-02-03 13:50:35','otto-lau','edit part, barcode=113874657396,name=Front Basket');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1371','2014-02-03 13:50:45','otto-lau','edit part, barcode=113874667209,name=Front Basket Bracket - paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1372','2014-02-03 14:26:38','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1373','2014-02-03 14:33:46','otto-lau','edit part, barcode=113875749549,name=Rear Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1374','2014-02-03 14:33:55','otto-lau','edit part, barcode=113875750225,name=Front Wheel Trim - Fender Flare (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1375','2014-02-03 14:34:56','otto-lau','edit part, barcode=113874806896,name=Head Light - RH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1376','2014-02-03 14:35:06','otto-lau','edit part, barcode=113874805471,name=Head Light - LH EG2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1377','2014-02-03 14:35:29','otto-lau','edit part, barcode=113874854618,name=Head Light - LH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1378','2014-02-03 14:35:36','otto-lau','edit part, barcode=113874855314,name=Head Light - RH EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1379','2014-02-03 14:38:08','otto-lau','edit part, barcode=113875507516,name=Meter');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1380','2014-02-03 14:38:11','otto-lau','edit part, barcode=113875508403,name=Meter Holder');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1381','2014-02-03 14:39:51','otto-lau','edit part, barcode=113878094409,name=Rear Brake assembly LH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1382','2014-02-03 14:39:54','otto-lau','edit part, barcode=113878093952,name=Rear Brake assembly RH');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1383','2014-02-03 14:42:09','otto-lau','edit part, barcode=113875563935,name=Sash (Clipper)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1384','2014-02-03 14:42:21','otto-lau','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1385','2014-02-03 14:42:26','otto-lau','edit part, barcode=113855789397,name=Windshield - Foldable - 2028');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1386','2014-02-03 14:42:52','otto-lau','edit part, barcode=113874010003,name=Windshield - Non Foldable - 6040');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1387','2014-02-03 14:42:59','otto-lau','edit part, barcode=113875628522,name=Sash (Clipper) - One piece');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1388','2014-02-03 14:44:01','otto-lau','edit part, barcode=113874701375,name=Searching Light Bracket 1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1389','2014-02-03 14:44:05','otto-lau','edit part, barcode=113874801718,name=Searching Light - 4X4');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1390','2014-02-03 14:44:39','otto-lau','edit part, barcode=113860136683,name=Seat Back Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1391','2014-02-03 14:45:29','otto-lau','edit part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1392','2014-02-03 14:46:41','otto-lau','edit part, barcode=113875705210,name=Seat back support - carbon steel - EG2028K (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1393','2014-02-03 14:46:56','otto-lau','edit part, barcode=113874669055,name=Sweater Basket - Carbon Steel');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1394','2014-02-03 14:47:02','otto-lau','edit part, barcode=113875707186,name=Sweater Basket Frame');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1395','2014-02-03 14:47:26','otto-lau','edit part, barcode=113878082911,name=Seat Belt Set - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1396','2014-02-03 14:47:37','otto-lau','edit part, barcode=113874694562,name=Seat Belt Mounting Bar - 2 point');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1397','2014-02-03 14:48:35','otto-lau','edit part, barcode=113860146106,name=Seat Cushion');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1398','2014-02-03 14:49:23','otto-lau','edit part, barcode=113874033533,name=Side Rear View Mirror (Paired)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1399','2014-02-03 14:49:34','otto-lau','edit part, barcode=113875684999,name=Side Rear View Mirror Bass - Paired');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1400','2014-02-03 14:51:29','otto-lau','edit part, barcode=113874804634,name=Tail Light Assembled - RH - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1401','2014-02-03 14:51:37','otto-lau','edit part, barcode=113874802719,name=Tail Light Assembled - LT - Golf');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1402','2014-02-03 14:52:00','otto-lau','edit part, barcode=113874862100,name=Tail Light Assembled - RH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1403','2014-02-03 14:52:09','otto-lau','edit part, barcode=113874862027,name=Tail Light Assembled - LH - Truck');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1404','2014-02-03 14:52:19','otto-lau','edit part, barcode=113874815828,name=Tail Light - RT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1405','2014-02-03 14:52:27','otto-lau','edit part, barcode=113874813410,name=Tail Light - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1406','2014-02-03 14:52:34','otto-lau','edit part, barcode=113874813410,name=Tail Light - LT - EG6118');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1407','2014-02-03 15:01:41','otto-lau','edit part, barcode=113855780864,name=Wheel 155R12C KENDA with Steel Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1408','2014-02-03 15:02:15','otto-lau','edit part, barcode=113855786227,name=Wheel 205150-10 KENDA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1409','2014-02-03 15:02:32','otto-lau','edit part, barcode=113855768358,name=Wheel 21x11-10 CST/ Aluminum Rim F');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1410','2014-02-03 15:02:59','otto-lau','edit part, barcode=113855773834,name=Wheel 21x11-10 CST/ Aluminum Rim R');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1411','2014-02-03 15:03:33','otto-lau','edit part, barcode=113897315200,name=Wheel 24x8-12 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1412','2014-02-03 15:04:00','otto-lau','edit part, barcode=113855777806,name=Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1413','2014-02-03 15:04:38','otto-lau','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1414','2014-02-04 10:09:42','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1415','2014-02-04 13:59:49','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1416','2014-02-04 14:29:32','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1417','2014-02-04 16:07:50','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1418','2014-02-04 16:34:23','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1419','2014-02-04 16:58:04','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1420','2014-02-05 09:49:03','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1421','2014-02-05 10:52:53','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1422','2014-02-05 13:32:43','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1423','2014-02-05 13:42:53','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1424','2014-02-05 13:45:16','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1425','2014-02-05 13:47:50','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1426','2014-02-05 13:52:17','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1427','2014-02-05 13:54:29','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1428','2014-02-05 13:55:47','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1429','2014-02-06 14:23:04','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1430','2014-02-07 13:38:42','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1431','2014-02-07 13:46:10','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1432','2014-02-07 15:26:08','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1433','2014-02-10 13:03:40','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1434','2014-02-10 13:51:15','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1435','2014-02-10 14:01:51','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1436','2014-02-10 14:02:54','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1437','2014-02-10 14:04:21','otto-lau','add new customer, company:Abibaba Wholesale Inc., phone:19056690305');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1438','2014-02-10 14:04:46','otto-lau','add new customer, company:Otterville Custom Golf Carts, phone:519-468-3617');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1439','2014-02-10 14:05:41','otto-lau','add new customer, company:Seaspan Ferries, phone:604 940 7239');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1440','2014-02-10 15:02:18','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1441','2014-02-10 15:14:20','otto','edit car, barcode=013849859999,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1442','2014-02-10 15:49:44','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1443','2014-02-10 15:50:47','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1444','2014-02-10 15:50:55','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1445','2014-02-10 15:53:31','Boyao-Wang','add new customer, company:Seaspan Ferries, phone:6049407239');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1446','2014-02-10 15:57:19','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1447','2014-02-10 15:57:29','Otto-Lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1448','2014-02-11 09:56:46','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1449','2014-02-11 10:27:01','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1450','2014-02-11 10:30:22','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1451','2014-02-11 15:34:51','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1452','2014-02-11 16:06:29','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1453','2014-02-11 16:23:48','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1454','2014-02-12 10:14:17','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1455','2014-02-12 10:15:30','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1456','2014-02-12 10:18:54','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1457','2014-02-12 10:28:23','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1458','2014-02-12 11:29:27','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1459','2014-02-12 11:33:11','Christal-Usiosefe','edit car, barcode=013849848309,name=ARGO 14');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1460','2014-02-12 11:37:37','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1461','2014-02-13 11:25:25','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1462','2014-02-14 09:03:43','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1463','2014-02-14 11:12:07','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1464','2014-02-14 13:52:41','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1465','2014-02-14 14:09:03','otto','add new car, barcode=013924049396,name=Kernel (Hard Door),amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1466','2014-02-14 14:24:02','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1467','2014-02-14 14:32:03','otto','edit car, barcode=013924049396,name=Kernel (Hard Door)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1468','2014-02-14 14:32:29','otto','edit car, barcode=013924049396,name=Kernel (Hard Door)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1469','2014-02-14 16:35:56','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1470','2014-02-14 16:36:34','otto','edit car, barcode=013924049396,name=Kernel (Hard Door)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1471','2014-02-18 14:39:08','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1472','2014-02-18 14:40:01','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1473','2014-02-18 16:48:04','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1474','2014-02-19 09:41:20','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1475','2014-02-19 11:11:03','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1476','2014-02-19 11:55:07','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1477','2014-02-19 14:03:30','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1478','2014-02-19 14:09:01','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1479','2014-02-19 14:10:27','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1480','2014-02-19 16:44:44','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1481','2014-02-19 16:47:03','otto','add new customer, company:Albion Golf Cars, phone: 4162361001');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1482','2014-02-19 16:48:14','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1483','2014-02-19 16:56:51','otto','add new customer, company:Otterville Custom Golf Carts, phone:519-468-3617');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1484','2014-02-20 09:56:00','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1485','2014-02-20 10:06:02','otto','edit part, barcode=113855795797,name=Windshield - Foldable - 2020');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1486','2014-02-20 10:23:19','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1487','2014-02-20 10:29:29','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1488','2014-02-20 13:06:40','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1489','2014-02-20 14:05:16','otto','edit part, barcode=113878103106,name=Rear Axle Assembly ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1490','2014-02-20 14:06:05','otto','edit part, barcode=113878103106,name=Rear Axle Assembly ');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1491','2014-02-20 14:28:09','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1492','2014-02-21 09:34:39','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1493','2014-02-21 09:40:22','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1494','2014-02-21 09:47:28','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1495','2014-02-21 09:57:56','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1496','2014-02-21 09:59:18','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1497','2014-02-21 09:59:40','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1498','2014-02-21 11:20:48','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1499','2014-02-24 09:29:50','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1500','2014-02-24 09:41:01','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1501','2014-02-24 09:49:17','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1502','2014-02-24 11:45:17','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1503','2014-02-24 11:59:47','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1504','2014-02-24 15:12:09','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1505','2014-02-25 13:18:54','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1506','2014-02-25 16:19:30','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1507','2014-02-27 10:15:29','otto-lau','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1508','2014-02-28 09:39:52','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1509','2014-02-28 14:07:35','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1510','2014-03-03 11:54:53','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1511','2014-03-03 14:32:10','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1512','2014-03-04 09:36:08','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1513','2014-03-06 15:48:33','Allen-Cai','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1514','2014-03-10 13:48:49','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1515','2014-03-10 14:45:40','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1516','2014-03-10 15:18:43','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1517','2014-03-10 15:25:47','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1518','2014-03-11 09:01:44','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1519','2014-03-11 13:10:11','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1520','2014-03-11 14:49:55','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1521','2014-03-11 14:59:50','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1522','2014-03-12 09:10:58','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1523','2014-03-12 09:17:39','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1524','2014-03-12 09:17:47','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1525','2014-03-12 09:18:01','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1526','2014-03-12 09:35:53','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1527','2014-03-12 10:12:17','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1528','2014-03-12 10:13:06','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1529','2014-03-12 13:47:51','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1530','2014-03-12 13:53:25','Boyao-Wang','add new customer, company:Scottcitywheels, phone:5193511870');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1531','2014-03-13 11:48:56','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1532','2014-03-13 11:53:24','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1533','2014-03-13 11:59:22','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1534','2014-03-14 09:46:18','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1535','2014-03-14 09:48:43','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1536','2014-03-14 10:46:36','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1537','2014-03-17 15:34:20','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1538','2014-03-17 15:41:52','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1539','2014-03-18 10:08:53','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1540','2014-03-18 10:20:41','allen-cai','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1541','2014-03-18 10:21:26','Boyao-Wang','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1542','2014-03-19 13:07:05','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1543','2014-03-19 14:42:20','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1544','2014-03-19 14:43:52','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1545','2014-03-19 14:44:01','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1546','2014-03-19 16:27:39','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1547','2014-03-20 09:35:17','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1548','2014-03-20 13:12:04','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1549','2014-03-20 13:12:40','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1550','2014-03-20 13:15:51','Allen-Cai','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1551','2014-03-20 14:21:41','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1552','2014-03-20 16:08:42','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1553','2014-03-20 16:40:10','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1554','2014-03-20 17:47:13','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1555','2014-03-21 09:39:05','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1556','2014-03-21 09:39:42','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1557','2014-03-21 10:43:15','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1558','2014-03-21 10:44:04','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1559','2014-03-21 14:46:49','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1560','2014-03-21 15:11:18','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1561','2014-03-21 15:18:04','Christal-Usiosefe','edit car, barcode=013849858782,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1562','2014-03-21 15:18:45','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1563','2014-03-21 16:03:39','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1564','2014-03-21 16:10:20','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1565','2014-03-22 15:46:17','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1566','2014-03-24 11:30:24','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1567','2014-03-24 11:30:30','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1568','2014-03-24 11:33:35','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1569','2014-03-24 11:53:46','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1570','2014-03-24 14:03:35','','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1571','2014-03-25 09:30:04','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1572','2014-03-25 13:58:25','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1573','2014-03-26 09:10:50','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1574','2014-03-26 09:13:51','otto','add new part, barcode=113958394533,name=Strobe Light - Blue and Red,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1575','2014-03-26 09:15:04','otto','add new part, barcode=113958396331,name=Strobe Light - Yellow and Orange,amount=0');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1576','2014-03-26 09:15:41','otto','edit part, barcode=113958394533,name=Strobe Light - Blue and Red');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1577','2014-03-26 09:17:27','otto','edit part, barcode=113958394533,name=Strobe Light - Blue and Red');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1578','2014-03-26 09:17:41','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1579','2014-03-26 09:18:51','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1580','2014-03-26 09:21:11','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1581','2014-03-26 09:42:59','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1582','2014-03-26 09:47:16','otto','edit car, barcode=013849859041,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1583','2014-03-26 09:47:36','otto','edit car, barcode=013849859323,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1584','2014-03-26 10:42:49','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1585','2014-03-26 11:31:06','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1586','2014-03-26 11:39:11','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1587','2014-03-26 11:46:09','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1588','2014-03-26 14:57:52','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1589','2014-03-27 09:08:39','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1590','2014-03-27 09:13:32','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1591','2014-03-27 09:38:15','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1592','2014-03-27 09:38:15','otto','edit car, barcode=013849857340,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1593','2014-03-27 09:41:06','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1594','2014-03-27 10:09:00','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1595','2014-03-27 10:44:30','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1596','2014-03-27 11:18:05','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1597','2014-03-27 13:37:48','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1598','2014-03-27 13:49:46','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1599','2014-03-28 13:22:52','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1600','2014-03-31 09:51:59','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1601','2014-03-31 15:51:38','Allen-Cai','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1602','2014-04-01 16:15:43','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1603','2014-04-01 16:25:14','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1604','2014-04-01 16:28:38','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1605','2014-04-01 16:33:12','otto','edit car, barcode=013849857340,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1606','2014-04-01 16:36:00','otto','add new car, barcode=013963845512,name=Hulk,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1607','2014-04-01 16:38:23','otto','add new car, barcode=013963845620,name=Hulk,amount=1');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1608','2014-04-01 16:38:56','otto','edit car, barcode=013963845620,name=Hulk (W/Cargo Box)');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1609','2014-04-02 09:27:45','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1610','2014-04-02 12:07:44','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1611','2014-04-02 13:55:39','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1612','2014-04-02 14:30:29','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1613','2014-04-03 09:44:03','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1614','2014-04-03 11:29:24','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1615','2014-04-03 15:13:06','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1616','2014-04-04 10:38:27','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1617','2014-04-04 10:39:54','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1618','2014-04-04 10:42:02','otto','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1619','2014-04-04 10:46:09','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1620','2014-04-04 10:48:37','otto','edit car, barcode=013849857035,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1621','2014-04-04 10:50:46','otto','edit car, barcode=013878275778,name=HOBBIT 6+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1622','2014-04-04 10:51:01','otto','edit car, barcode=013849857035,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1623','2014-04-04 10:52:23','otto','edit car, barcode=013878273839,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1624','2014-04-04 10:56:43','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1625','2014-04-07 09:31:52','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1626','2014-04-09 09:14:06','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1627','2014-04-09 10:29:25','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1628','2014-04-09 10:52:42','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1629','2014-04-09 11:39:44','otto','edit car, barcode=013849858260,name=NOMAD');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1630','2014-04-09 14:09:37','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1631','2014-04-09 14:17:28','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1632','2014-04-09 15:21:41','otto','edit car, barcode=013878179093,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1633','2014-04-09 15:36:34','otto','edit car, barcode=013878269848,name=RAMBLER');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1634','2014-04-09 15:37:24','otto','edit car, barcode=013878255554,name=HOBBIT 4+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1635','2014-04-09 15:40:41','otto','edit car, barcode=013849853756,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1636','2014-04-09 16:25:28','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1637','2014-04-09 16:38:34','Boyao-Wang','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1638','2014-04-09 16:40:25','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1639','2014-04-10 13:57:42','otto','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1640','2014-04-10 13:59:20','otto','edit car, barcode=013878273573,name=HOBBIT 2+2');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1641','2014-04-10 16:18:15','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1642','2014-04-11 09:57:28','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1643','2014-04-11 10:34:30','Christal-Usiosefe','logout system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1644','2014-04-11 11:42:59','Christal-Usiosefe','login to the system.');
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1645','2014-04-11 13:06:29','otto','login to the system.');
/*!40000 ALTER TABLE `ew_log` ENABLE KEYS */;


--
-- Create Table `ew_message`
--

DROP TABLE IF EXISTS `ew_message`;
CREATE TABLE `ew_message` (
  `mid` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `path` varchar(40) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=234 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_message`
--

/*!40000 ALTER TABLE `ew_message` DISABLE KEYS */;
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('165','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878280024,Carbon Brush - Chinese Motor,1,0.00,0.00<br>','2014-01-06 10:22:40','upload/1389021760932.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('166','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878280863,Carbon brush - ADC motor,15,0.00,0.00<br>','2014-01-06 10:25:37','upload/1389021937744.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('114','san','Original Viso File for Warehouse Map~~~~~','2013-12-20 17:04:41','upload/1387577081332.vsd');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('164','otto','<a href=\"http://192.168.1.175/www/upload/usermanual.pdf\">http://192.168.1.175/www/upload/usermanual.pdf</a>','2014-01-03 15:51:18','upload/usermanual.pdf');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('167','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878261008,Shunt,1,0.00,0.00<br>','2014-01-06 10:26:47','upload/1389022007182.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('168','Boyao-Wang','contact list','2014-01-06 10:46:43','upload/1389023203166.xlsx');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('169','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878274626,Main Fuse - 250A,-2,0.00,0.00<br>','2014-01-06 11:02:46','upload/1389024166541.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('170','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878277615,F/R Switch,-1,0.00,0.00<br>','2014-01-06 11:17:04','upload/1389025024838.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('171','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878278718,Power Meter - 48V,1,0.00,0.00<br>','2014-01-06 11:20:26','upload/1389025226228.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('172','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878283060,LED light Wire - On board,1,0.00,0.00<br>','2014-01-06 11:25:12','upload/1389025512525.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('173','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874807201,Combination Switch,9,0.00,0.00<br>','2014-01-06 15:22:57','upload/1389039777635.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('174','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874808788,Converter DC 36V-12V,3,0.00,0.00<br>','2014-01-06 15:31:25','upload/1389040285291.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('175','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855795797,Windshield - Foldable - 2020,-1,0.00,0.00<br>','2014-01-06 15:41:11','upload/1389040871150.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('176','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855789397,Windshield - Foldable - 2028,1,0.00,0.00<br>','2014-01-06 15:41:20','upload/1389040880963.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('177','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878104320,Motor Access - EG2028/ EG2020,-2,0.00,0.00<br>','2014-01-07 10:09:59','upload/1389107399228.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('178','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878086410,Seat Belt Set - 3 point,-1,0.00,0.00<br>','2014-01-07 13:16:14','upload/1389118574994.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('179','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878114441,Rear Leaf Spring Assembly,3,0.00,0.00<br>','2014-01-07 13:39:54','upload/1389119994728.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('180','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878113414,Front Leaf Spring Assembly,-3,0.00,0.00<br>','2014-01-07 13:40:28','upload/1389120028119.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('181','otto ','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874838896,AC Cable ,13,0.00,0.00<br>','2014-01-07 13:49:04','upload/1389120544494.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('182','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874008674,Front Bumper - Metallic,1,0.00,0.00<br>','2014-01-07 14:14:56','upload/1389122096072.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('183','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874033533,Side Rear View Mirror,-1,0.00,0.00<br>','2014-01-07 15:35:58','upload/1389126958031.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('184','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855780864,Front Bumper - Metallic,-8,0.00,0.00<br>','2014-01-09 15:14:26','upload/1389298466155.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('185','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113875519554,EG6020A4D Battery Cover on Front Body,-1,0.00,0.00<br>','2014-01-13 14:04:22','upload/1389639862592.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('186','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855780864,Wheel 155R12C KENDA with Steel Rim,4,0.00,0.00<br>','2014-01-14 15:25:01','upload/1389731101798.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('187','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855777806,Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim,-4,0.00,0.00<br>','2014-01-14 15:25:49','upload/1389731149817.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('188','Boyao-Wang','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849843596,HULK,-1,9850.00,12999.00<br>','2014-01-15 09:50:45','upload/1389797445318.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('189','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855773834,Wheel 21x11-10 CST/ Aluminum Rim R,-1,0.00,0.00<br>','2014-01-17 09:42:15','upload/1389969735490.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('190','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874844445,Charger - DeltaQ 48V-110,1,0.00,0.00<br>','2014-01-17 14:32:18','upload/1389987138834.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('191','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878276989,Universal Start Key,-1,0.00,0.00<br>','2014-01-22 09:28:18','upload/1390400898432.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('192','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>013904144693,Cricket 2,-1,4299.00,5799.00<br>','2014-01-22 14:03:40','upload/1390417420729.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('193','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849856394,CRICKET 2,-1,4299.00,5799.00<br>','2014-01-22 14:14:53','upload/1390418093479.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('198','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855787534,Flip-Flop Seat Kit,-1,440.00,660.00<br>113874666349,Rear Bracket - 2028KSF - paired,-1,20.00,40.00<br>113875735287,Caddie Handle - 38.5 inches,-1,6.50,13.00<br>','2014-01-29 14:47:08','upload/1391024828948.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('200','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878103505,Rear Bumper - EG2020/ EG2028,-1,21.50,43.00<br>113874033533,Side Rear View Mirror (Paired),-1,10.00,20.00<br>113878104320,Motor Access - EG2028/ EG2020,-1,9.50,19.00<br>113878120248,Top Canopy Bracket - EG2028KSF/ EG2028KSZ,-1,30.00,60.00<br>','2014-01-30 14:01:32','upload/1391108492432.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('199','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113875685230,Jacket For Caddie Handle -  Piece,-4,4.00,8.00<br>','2014-01-29 14:47:37','upload/1391024857010.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('201','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113875705210,Seat back support - carbon steel - EG2028K (Paired),-2,17.00,34.00<br>','2014-02-03 14:45:42','upload/1391456742917.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('202','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855789397,Windshield - Foldable - 2028,-1,0.00,0.00<br>','2014-02-04 10:10:39','upload/1391526639385.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('203','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>013904144693,CRICKET 2,-1,4299.00,5799.00<br>','2014-02-04 14:22:29','upload/1391541749167.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('204','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>013904144693,CRICKET 2,1,4299.00,5799.00<br>','2014-02-04 14:26:41','upload/1391542001745.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('205','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849856394,CRICKET 2,-1,4299.00,5799.00<br>','2014-02-04 14:27:28','upload/1391542048948.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('206','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855780864,Wheel 155R12C KENDA with Steel Rim,-1,0.00,0.00<br>','2014-02-04 14:37:05','upload/1391542625792.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('207','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113875563935,Sash (Clipper),-2,10.00,20.00<br>113878991309,Flip-Flop Seat Rubber Pad,-1,1.00,2.00<br>','2014-02-04 14:38:02','upload/1391542682401.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('208','otto-lau','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874863430,Battery Cable Jacket - Black,2,1.50,3.00<br>113874864521,Battery Cable Jacket - Red,1,1.50,3.00<br>','2014-02-06 14:24:02','upload/1391714642922.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('209','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849848309,ARGO 14,-1,13599.00,17999.00<br>','2014-02-12 11:33:40','upload/1392222820428.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('210','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874844445,Charger - DeltaQ 48V-110,1,380.00,760.00<br>','2014-02-18 16:48:26','upload/1392760106203.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('211','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855773834,Wheel 21x11-10 CST/ Aluminum Rim R,-2,140.00,210.00<br>113875764620,Wheel Nut - Aluminum Rim,-16,2.00,4.00<br>113875741899,Hubcap - Aluminum,-4,4.00,8.00<br>113855768358,Wheel 21x11-10 CST/ Aluminum Rim F,-2,140.00,210.00<br>113860146106,Seat Cushion,-1,113.00,170.00<br>113855795797,Windshield - Foldable - 2020,-1,100.00,150.00<br>','2014-02-20 10:15:16','upload/1392909316240.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('212','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113875563935,Sash (Clipper),-2,10.00,20.00<br>','2014-02-20 14:00:29','upload/1392922829756.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('213','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>013924049396,Kernel (Hard Door),-1,13389.00,0.00<br>','2014-02-24 09:46:59','upload/1393253219178.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('214','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874837101,AC Cable Extension,-1,0.00,0.00<br>','2014-03-11 14:55:41','upload/1394564141130.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('215','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>013878178357,HOBBIT 2HCX,-1,5850.00,7899.00<br>','2014-03-12 09:17:17','upload/1394630237166.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('216','Christal-Usiosefe','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855789397,Windshield - Foldable - 2028,-1,0.00,0.00<br>','2014-03-13 11:49:57','upload/1394725797026.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('217','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113874808788,Converter DC 36V-12V,-1,50.00,100.00<br>113878275921,Brake Light Switch,-1,4.00,8.00<br>113878282586,Turn Light Bulb - EG2028,-2,2.50,5.00<br>113856717210,Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ,-1,0.00,0.00<br>113874838896,AC Cable ,-1,0.00,0.00<br>113879005492,Battery - Trojan T105,-8,0.00,0.00<br>','2014-03-20 10:48:18','upload/1395326898510.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('218','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849858782,RAMBLER,-1,6199.00,8299.00<br>113878094409,Rear Brake assembly LH,-1,35.00,70.00<br>113874838896,AC Cable ,-1,0.00,0.00<br>113855795797,Windshield - Foldable - 2020,-1,100.00,150.00<br>113874033533,Side Rear View Mirror (Paired),-1,10.00,20.00<br>113878106590,Front Bumper - EG2020 - Plastic,-1,12.00,24.00<br>','2014-03-21 15:22:53','upload/1395429773323.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('219','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849852101,RAMBLER,-1,6199.00,8299.00<br>','2014-03-21 15:23:44','upload/1395429824166.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('220','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849859041,RAMBLER,-1,6199.00,8299.00<br>013849859323,HOBBIT 2+2,-1,4599.00,6199.00<br>','2014-03-26 09:48:38','upload/1395841718291.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('221','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849857340,HOBBIT 2+2,-1,4599.00,6199.00<br>','2014-03-27 09:42:46','upload/1395927766682.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('222','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849857340,HOBBIT 2+2,1,4599.00,6199.00<br>','2014-04-01 16:32:50','upload/1396384370013.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('223','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849857035,HOBBIT 2+2,-1,4599.00,6199.00<br>013878275778,HOBBIT 6+2,-1,6999.00,9150.00<br>','2014-04-04 10:51:34','upload/1396623094322.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('224','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855795797,Windshield - Foldable - 2020,-1,100.00,150.00<br>113855789397,Windshield - Foldable - 2028,-4,0.00,0.00<br>113874008674,Front Bumper - Metallic,-2,70.00,140.00<br>113878104320,Motor Access - EG2028/ EG2020,-7,9.50,19.00<br>113855787534,Flip-Flop Seat Kit,-5,440.00,660.00<br>','2014-04-09 10:47:26','upload/1397054846742.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('225','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013849858260,NOMAD,-1,5950.00,7499.00<br>','2014-04-09 11:39:54','upload/1397057994101.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('226','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013878269848,RAMBLER,-1,6199.00,8299.00<br>013849853756,HOBBIT 2+2,-1,4599.00,6199.00<br>','2014-04-09 15:42:42','upload/1397072562414.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('227','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013878273839,HOBBIT 2+2,-1,4599.00,6199.00<br>','2014-04-09 15:46:14','upload/1397072774742.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('228','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878282586,Turn Light Bulb - EG2028,-4,2.50,5.00<br>113878283910,Turn light bulb - EG2020,-4,6.00,12.00<br>113874862955,Head Light - EG2020,-1,43.00,86.00<br>','2014-04-09 16:46:14','upload/1397076374101.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('229','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013878273573,HOBBIT 2+2,-1,4599.00,6199.00<br>','2014-04-10 14:00:13','upload/1397152813023.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('230','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113879004663,Battery - US 2200,-26,0.00,0.00<br>','2014-04-10 14:02:53','upload/1397152973820.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('231','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855773834,Wheel 21x11-10 CST/ Aluminum Rim R,-5,140.00,210.00<br>113855768358,Wheel 21x11-10 CST/ Aluminum Rim F,-6,140.00,210.00<br>','2014-04-10 14:04:33','upload/1397153073180.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('232','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113878104320,Motor Access - EG2028/ EG2020,-1,9.50,19.00<br>113855787534,Flip-Flop Seat Kit,-2,440.00,660.00<br>','2014-04-10 14:06:08','upload/1397153168601.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('233','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013878255554,HOBBIT 4+2,-1,5750.00,7699.00<br>','2014-04-11 13:09:20','upload/1397236160195.csv');
/*!40000 ALTER TABLE `ew_message` ENABLE KEYS */;


--
-- Create Table `ew_part`
--

DROP TABLE IF EXISTS `ew_part`;
CREATE TABLE `ew_part` (
  `barcode` varchar(20) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT 'Name of the part',
  `photo_url` tinytext COMMENT 'Photo URL',
  `part_num` varchar(20) NOT NULL COMMENT 'Part number of the part',
  `category` varchar(20) NOT NULL COMMENT 'Body, Accessory, Tire and Rim, Mechanical, Electrical',
  `sub_category` varchar(20) NOT NULL COMMENT 'Universal, Club car, EZGO, AGT, Yamaha',
  `color` varchar(20) DEFAULT NULL COMMENT 'The color of product',
  `p_price` decimal(10,2) NOT NULL COMMENT 'Purchase price',
  `w_price` decimal(10,2) NOT NULL COMMENT 'Wholesale price',
  `r_price` decimal(10,2) NOT NULL COMMENT 'Retail price',
  `quantity` int(10) NOT NULL COMMENT 'Amount in stock',
  `w_quantity` int(10) NOT NULL COMMENT 'Warning if in stock less than this amount',
  `l_zone` varchar(20) DEFAULT NULL COMMENT 'Location zone',
  `l_column` varchar(20) DEFAULT NULL COMMENT 'Location column',
  `l_level` varchar(20) DEFAULT NULL COMMENT 'Location level',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Latest update date',
  `des` text NOT NULL COMMENT 'Description of item',
  `xsearch` text NOT NULL COMMENT 'Name,part_num,category,sub_category,color,location',
  PRIMARY KEY (`barcode`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_part`
--

/*!40000 ALTER TABLE `ew_part` DISABLE KEYS */;
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855780864','Wheel 155R12C KENDA with Steel Rim','upload/1389731087792.jpg','3040-5207010','tire_and_rim','AGT','default','0.00','0.00','0.00','3','2','L','1','3_I SKID','2014-02-04 14:37:05','','barcode:113855780864, name:wheel 155r12c kenda with steel rim, model:3040-5207010, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855777806','Wheel 25x8-12 ATX78 WAN DA with Aluminum Rim','upload/1388692789385.jpg','PKG','tire_and_rim','AGT','default','85.00','120.00','180.00','4','1','L','1','3_I SKID','2014-01-29 10:28:11','EG6040 Series','barcode:113855777806, name:wheel 25x8-12 atx78 wan da with aluminum rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855773834','Wheel 21x11-10 CST/ Aluminum Rim R','upload/1388693545682.jpg','PKG','tire_and_rim','AGT','default','100.00','140.00','210.00','20','2','L','1','3_II-III SKID','2014-04-10 14:04:33','','barcode:113855773834, name:wheel 21x11-10 cst/ aluminum rim r, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_ii-iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855768358','Wheel 21x11-10 CST/ Aluminum Rim F','upload/1388693438478.jpg','PKG','tire_and_rim','AGT','default','100.00','140.00','210.00','20','2','L','1','3_II-III SKID','2014-04-10 14:04:33','','barcode:113855768358, name:wheel 21x11-10 cst/ aluminum rim f, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_ii-iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855784845','225115B12 Journey with Aluminum Rim','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','75.00','0.00','0','-1','w','1','1','2013-12-20 13:08:40','','barcode:113855784845, name:225115b12 journey with aluminum rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855786227','Wheel 205150-10 KENDA with Aluminum Rim','upload/1388692959978.jpg','PKG','tire_and_rim','AGT','default','70.00','120.00','180.00','12','12','L','1','3_I SKID','2014-01-29 10:27:17','EG2028 Series','barcode:113855786227, name:wheel 205150-10 kenda with aluminum rim, model:pkg, category:tire_and_rim, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855787534','Flip-Flop Seat Kit','upload/1388437920928.jpg','PKG','body','AGT','default','206.00','440.00','660.00','32','2','L','1 and 2','2_I-II SKID','2014-04-10 14:06:08','','barcode:113855787534, name:flip-flop seat kit, model:pkg, category:body, sub category:agt, color:default, location:l_1 and 2_2_i-ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855789397','Windshield - Foldable - 2028','upload/1388436249022.jpg','PKG','body','AGT','Tint','0.00','0.00','0.00','64','2','L','3','2_I-II SKID','2014-04-09 10:47:26','','barcode:113855789397, name:windshield - foldable - 2028, model:pkg, category:body, sub category:agt, color:tint, location:l_3_2_i-ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855795797','Windshield - Foldable - 2020','upload/1388436931991.jpg','PKG','body','AGT','Tint','55.00','100.00','150.00','16','2','L','2','2_III SKID','2014-04-09 10:47:26','','barcode:113855795797, name:windshield - foldable - 2020, model:pkg, category:body, sub category:agt, color:tint, location:l_2_2_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856688278','Left Half Axle','upload/1388439086460.jpg','2402100-008','mechanical','AGT','default','26.80','57.00','114.00','49','5','L','2','3_III SKID','2014-01-28 15:57:30','','barcode:113856688278, name:left half axle, model:2402100-008, category:mechanical, sub category:agt, color:default, location:l_2_3_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856688951','Right Half Axle','upload/1388439216069.jpg','2402200-008','mechanical','AGT','default','26.80','57.00','114.00','49','5','L','2','3_III SKID','2014-01-29 10:12:26','','barcode:113856688951, name:right half axle, model:2402200-008, category:mechanical, sub category:agt, color:default, location:l_2_3_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856717210','Cargo Box Carbon Steel- Manual Dump - 1400x1100x250 ','upload/1388694963557.jpg','PKG','accessory','AGT','default','242.00','0.00','0.00','4','2','L','1','1_I-II SKID','2014-03-20 10:48:18','','barcode:113856717210, name:cargo box carbon steel- manual dump - 1400x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_1_1_i-ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856724550','Cargo Box Aluminum- Manual Dump - 1400x1100x250 ','upload/1388695168775.jpg','PKG','accessory','AGT','default','305.00','0.00','0.00','2','2','L','1','1_II SKID','2014-01-24 13:32:45','','barcode:113856724550, name:cargo box aluminum- manual dump - 1400x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_1_1_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856726379','Cargo Box Carbon Steel - Non Standard - 1000x1100x250','upload/1388436675428.jpg','PKG','accessory','AGT','default','192.00','0.00','0.00','2','2','L','2','1_I SKID','2014-01-24 13:38:44','','barcode:113856726379, name:cargo box carbon steel - non standard - 1000x1100x250, model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856726477','Cargo Box Aluminium - Non Standard - 1000x1100x250 ','upload/1388436785694.jpg','PKG','accessory','AGT','default','310.00','0.00','0.00','2','2','L','2','1_I SKID','2014-01-24 13:32:22','','barcode:113856726477, name:cargo box aluminium - non standard - 1000x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856730198','Cargo Box Aluminum - Standard - 770x1100x250 ','upload/1388435216069.jpg','PKG','accessory','AGT','default','235.00','0.00','0.00','2','2','L','2','1_III SKID','2014-01-24 13:32:32','','barcode:113856730198, name:cargo box aluminum - standard - 770x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856732204','Cargo Box Carbon Steel - Standard - 770x1100x250 ','upload/1388436536616.jpg','PKG','accessory','AGT','default','175.00','0.00','0.00','3','2','L','2','1_II SKID','2014-01-24 13:42:45','','barcode:113856732204, name:cargo box carbon steel - standard - 770x1100x250 , model:pkg, category:accessory, sub category:agt, color:default, location:l_2_1_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856750152','Rear Cover - Metallic Green - Used','upload/default.jpg','5402010-036-A1','body','EZGO,AGT','default','0.00','0.00','0.00','2','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2028 Series','barcode:113856750152, name:rear cover - metallic green - used, model:5402010-036-a1, category:body, sub category:ezgo,agt, color:default, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856751451','Rear Cover - Pure Black - Used','upload/default.jpg','5402010-036-A4','body','EZGO,AGT','default','0.00','0.00','0.00','3','0','L','2','3_I SKID','2013-12-20 13:08:40','EG2020 and EG2028 Series','barcode:113856751451, name:rear cover - pure black - used, model:5402010-036-a4, category:body, sub category:ezgo,agt, color:default, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856751895','Rear Cover - Camouflage - Used','upload/default.jpg','23456543','body','EZGO,AGT','default','0.00','0.00','0.00','1','0','L','2','3_I SKID','2013-12-20 13:08:40','EG6040 Series','barcode:113856751895, name:rear cover - camouflage - used, model:23456543, category:body, sub category:ezgo,agt, color:default, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860002295','Front Cover - Metallic Green - Used','upload/default.jpg','5302010-036-A1','body','AGT','Metallic Green','110.00','120.00','240.00','2','0','L','2','3_I SKID','2014-01-28 15:13:37','EG2028 Series','barcode:113860002295, name:front cover - metallic green - used, model:5302010-036-a1, category:body, sub category:agt, color:metallic green, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860005355','Front Cover - Pure Black - Used','upload/default.jpg','5302010-036-A4','body','AGT','Pure Black','110.00','120.00','240.00','1','0','L','2','3_I SKID','2014-01-28 15:13:46','EG2028 Series','barcode:113860005355, name:front cover - pure black - used, model:5302010-036-a4, category:body, sub category:agt, color:pure black, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860007132','Front Cover - Black - Used','upload/default.jpg','5302010-048','body','AGT','Black','110.00','120.00','240.00','2','0','L','2','3_I SKID','2014-01-28 15:13:11','EG2020 Series','barcode:113860007132, name:front cover - black - used, model:5302010-048, category:body, sub category:agt, color:black, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860007207','Front Cover - Camouflage - Used','upload/default.jpg','3040-5202001-114','body','AGT','camouflage','110.00','120.00','240.00','1','0','L','2','3_I SKID','2014-01-28 15:13:27','EG6040','barcode:113860007207, name:front cover - camouflage - used, model:3040-5202001-114, category:body, sub category:agt, color:camouflage, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860008361','Central Cover - camouflage - used','upload/default.jpg','undefined','body','AGT','camouflage','0.00','0.00','0.00','1','0','L','2','3_I SKID','2014-01-02 09:48:21','EG6040','barcode:113860008361, name:central cover - camouflage - used, model:undefined, category:body, sub category:agt, color:camouflage, location:l_2_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860136683','Seat Back Cushion','upload/1388435411382.jpg','7106100-036','body','AGT','Tan','25.50','56.50','113.00','22','5','L','3','3_I SKID','2014-01-29 10:15:48','Without back plastic cover','barcode:113860136683, name:seat back cushion, model:7106100-036, category:body, sub category:agt, color:tan, location:l_3_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860146106','Seat Cushion','upload/1388434944225.jpg','7101100-036','body','AGT','Tan','51.20','113.00','170.00','23','4','L','3','3_II SKID','2014-02-20 10:15:16','EG2028 Seat Cushion (Battery Seat Cover)\r\nWithout Arm rest and Hinges','barcode:113860146106, name:seat cushion, model:7101100-036, category:body, sub category:agt, color:tan, location:l_3_3_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861020003','Passenger Seat EG6158','upload/1388680803072.jpg','7149000-014','body','AGT','Grey','60.00','125.00','250.00','4','2','L','2','3_II SKID','2014-01-29 09:58:21','PKG included 1 seat and a back rest cushion','barcode:113861020003, name:passenger seat eg6158, model:7149000-014, category:body, sub category:agt, color:grey, location:l_2_3_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861020767','Drivers Seat','upload/1388679341963.jpg','7101000-014','body','AGT','Grey','59.80','125.00','250.00','4','1','L','2','3_II SKID','2014-01-24 14:59:34','PKG included 2 seats (Driver & Passenger) EG6158 and a Back Rest Cushion','barcode:113861020767, name:drivers seat, model:7101000-014, category:body, sub category:agt, color:grey, location:l_2_3_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861036513','Assembly of Cushion','upload/1388434661975.jpg','7101100-040','body','AGT','Tan','21.60','63.00','126.00','10','5','L','3','3_III SKID','2014-01-24 09:32:10','First Row Seat\r\n(Without Plug in holes)\r\n\r\nCompetitor Pricing\r\n[Nivel] - 125.00\r\n[Madjax] - 40.00','barcode:113861036513, name:assembly of cushion, model:7101100-040, category:body, sub category:agt, color:tan, location:l_3_3_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861699105','Front Axle Assembly','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','0','-1','w','1','1','2013-12-20 13:08:40','Completed front axle assembly','barcode:113861699105, name:front axle assembly, model:pkg, category:mechanical, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874020209','Backrest Cushion','upload/default.jpg','7106100-036 (PKG)','body','AGT','default','52.20','104.00','155.00','10','5','M','1','3_I SKID','2014-01-24 13:13:07','Included Parts:\r\nEG2028K Backrest cover - 7106111-036 - (1)\r\nSeat back sub-bracket - 7127011-037 - (2)\r\n\r\nCompetitor Pricing\r\n[Nivel] - 82.50\r\n[Madjax] - 40.00','barcode:113874020209, name:backrest cushion, model:7106100-036 (pkg), category:body, sub category:agt, color:default, location:m_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874008674','Front Bumper - Metallic','upload/1389121955197.jpg','3040-5207010','body','AGT','default','31.10','70.00','140.00','7','4','M','1','2_II SKID','2014-04-09 10:47:26','','barcode:113874008674, name:front bumper - metallic, model:3040-5207010, category:body, sub category:agt, color:default, location:m_1_2_ii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874010003','Windshield - Non Foldable - 6040','upload/1388435887538.jpg','2020A-5203001','body','AGT','Clear','0.00','0.00','0.00','11','1','L','3','2_III SKID','2013-12-30 15:38:27','','barcode:113874010003, name:windshield - non foldable - 6040, model:2020a-5203001, category:body, sub category:agt, color:clear, location:l_3_2_iii skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878320669','Side Rear View Mirror - RH','upload/1387833825207.jpg','9002200-005','body','AGT','Black','54.00','107.00','160.00','2','2','S2','1','5_I shelf','2014-01-29 10:19:38','','barcode:113878320669, name:side rear view mirror - rh, model:9002200-005, category:body, sub category:agt, color:black, location:s2_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874033533','Side Rear View Mirror (Paired)','upload/1387830456785.jpg','9002100-009 (PKG)','body','EZGO,AGT','black','3.80','10.00','20.00','141','25','S1','1','5_I shelf','2014-03-21 15:22:53','','barcode:113874033533, name:side rear view mirror (paired), model:9002100-009 (pkg), category:body, sub category:ezgo,agt, color:black, location:s1_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874657396','Front Basket','upload/1387830800223.jpg','5302100-048','accessory','AGT','black','26.40','50.00','100.00','18','4','S1','2','5_I shelf','2014-01-28 14:02:58','','barcode:113874657396, name:front basket, model:5302100-048, category:accessory, sub category:agt, color:black, location:s1_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874660495','Inner Rearview Mirror','upload/1387830299582.jpg','9001100-001','accessory','AGT','Black','4.70','10.00','20.00','9','2','S1','1','5_II shelf','2014-01-28 15:56:15','Included 9001100-001, 9001010-001','barcode:113874660495, name:inner rearview mirror, model:9001100-001, category:accessory, sub category:agt, color:black, location:s1_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874661256','Rear Bracket - 2020ASZ - paired','upload/1388698651103.jpg','5701021-063','body','AGT','default','8.00','20.00','40.00','2','4','S1','1','3_II shelf','2014-01-29 10:00:32','','barcode:113874661256, name:rear bracket - 2020asz - paired, model:5701021-063, category:body, sub category:agt, color:default, location:s1_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874665250','Rear Bracket - 2028K - paired','upload/1388698228322.jpg','2028-5601011','body','AGT','default','8.00','20.00','40.00','2','2','S1','1','2_I shelf','2014-01-29 10:00:45','','barcode:113874665250, name:rear bracket - 2028k - paired, model:2028-5601011, category:body, sub category:agt, color:default, location:s1_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874666349','Rear Bracket - 2028KSF - paired','upload/1388697963666.jpg','5701021-043','body','AGT','default','8.40','20.00','40.00','6','4','S1','1','3_I shelf','2014-01-29 14:47:08','','barcode:113874666349, name:rear bracket - 2028ksf - paired, model:5701021-043, category:body, sub category:agt, color:default, location:s1_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874667209','Front Basket Bracket - paired','upload/1388698856353.jpg','5302030-048','accessory','AGT','default','2.30','16.00','32.00','3','8','S1','1','2_II shelf','2014-01-28 14:03:24','','barcode:113874667209, name:front basket bracket - paired, model:5302030-048, category:accessory, sub category:agt, color:default, location:s1_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874668190','Rear Standing Board','upload/1388698433213.jpg','5402110-037','accessory','AGT','default','26.10','55.00','110.00','2','2','S1','1','1_I floor','2014-01-29 10:03:08','','barcode:113874668190, name:rear standing board, model:5402110-037, category:accessory, sub category:agt, color:default, location:s1_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874669055','Sweater Basket - Carbon Steel','upload/1387832082754.jpg','5405200-036','body','AGT','default','8.70','24.00','48.00','2','1','S1','1','1_II Floor','2014-01-29 10:22:05','','barcode:113874669055, name:sweater basket - carbon steel, model:5405200-036, category:body, sub category:agt, color:default, location:s1_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874676203','Rear Bracket - Undefined','upload/1388696732135.jpg','undefined','body','AGT','default','4.00','10.00','20.00','4','0','S1','1','4_I shelf','2014-01-29 10:01:13','','barcode:113874676203, name:rear bracket - undefined, model:undefined, category:body, sub category:agt, color:default, location:s1_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874676661','Backrest bracket - EG2028H - Paired','upload/1388699331010.jpg','7107011-039','body','AGT','default','12.60','54.00','108.00','3','2','S1','1','2_III shelf','2014-01-24 13:11:48','','barcode:113874676661, name:backrest bracket - eg2028h - paired, model:7107011-039, category:body, sub category:agt, color:default, location:s1_1_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874694069','Cargo Box Bracket Support','upload/1387831151645.jpg','8115010-039','accessory','AGT','default','8.70','19.00','38.00','12','4','S1','2','4_II shelf','2014-01-24 13:33:05','','barcode:113874694069, name:cargo box bracket support, model:8115010-039, category:accessory, sub category:agt, color:default, location:s1_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874688608','Cargo Box Support Bracket - 2048HCX','upload/1387832369457.jpg','8115210-044','accessory','AGT','default','12.00','25.00','50.00','5','4','S1','2','2_II shelf','2014-01-24 13:44:06','','barcode:113874688608, name:cargo box support bracket - 2048hcx, model:8115210-044, category:accessory, sub category:agt, color:default, location:s1_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874689510','Side Armrest','upload/1387832241926.jpg','5401141-037','accessory','AGT','default','4.40','12.00','24.00','2','4','S1','2','2_III shelf','2014-01-29 10:18:46','','barcode:113874689510, name:side armrest, model:5401141-037, category:accessory, sub category:agt, color:default, location:s1_2_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874690781','Seat Frame','upload/1387831276254.jpg','5401130-037','accessory','AGT','default','6.50','16.00','32.00','6','2','S1','2','3_II shelf','2014-01-29 10:17:49','','barcode:113874690781, name:seat frame, model:5401130-037, category:accessory, sub category:agt, color:default, location:s1_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874694562','Seat Belt Mounting Bar - 2 point','upload/1387831372785.jpg','7001210-048','accessory','AGT','default','2.90','7.50','15.00','105','5','S1','2','3_I shelf','2014-01-29 10:16:26','','barcode:113874694562, name:seat belt mounting bar - 2 point, model:7001210-048, category:accessory, sub category:agt, color:default, location:s1_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874701375','Searching Light Bracket 1','upload/1387832166785.jpg','5111032-033','body','AGT','default','3.30','7.50','15.00','3','2','S1','2','2_I shelf','2014-01-29 10:13:47','','barcode:113874701375, name:searching light bracket 1, model:5111032-033, category:body, sub category:agt, color:default, location:s1_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874801718','Searching Light - 4X4','upload/1389040717150.jpg','3107200-001','electrical','AGT','default','6.20','13.50','27.00','20','4','S3','1','5_I shelf','2014-01-29 10:13:36','','barcode:113874801718, name:searching light - 4x4, model:3107200-001, category:electrical, sub category:agt, color:default, location:s3_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874802719','Tail Light Assembled - LT - Golf','upload/1389040808166.jpg','3126100-003','electrical','AGT','default','5.10','13.00','26.00','9','5','S3','1','5_II shelf','2014-01-29 10:23:01','','barcode:113874802719, name:tail light assembled - lt - golf, model:3126100-003, category:electrical, sub category:agt, color:default, location:s3_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874804634','Tail Light Assembled - RH - Golf','upload/1389040850603.jpg','3126200-003','electrical','AGT','default','5.10','13.00','26.00','9','5','S3','1','5_III shelf','2014-01-29 10:23:07','','barcode:113874804634, name:tail light assembled - rh - golf, model:3126200-003, category:electrical, sub category:agt, color:default, location:s3_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874805471','Head Light - LH EG2028','upload/1389041169244.jpg','3117100-002','electrical','AGT','default','10.10','21.50','43.00','8','5','S3','1','5_IV shelf','2014-01-28 15:50:09','','barcode:113874805471, name:head light - lh eg2028, model:3117100-002, category:electrical, sub category:agt, color:default, location:s3_1_5_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874806896','Head Light - RH EG2028','upload/1389041390103.jpg','3117200-002','electrical','AGT','default','10.10','21.50','43.00','8','5','S3','1','5_IV shelf','2014-01-28 15:50:33','','barcode:113874806896, name:head light - rh eg2028, model:3117200-002, category:electrical, sub category:agt, color:default, location:s3_1_5_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874807201','Combination Switch','upload/1389039647494.jpg','3024100-005','electrical','AGT','default','5.50','12.00','24.00','39','10','S3','1','4_I shelf','2014-01-24 14:31:37','','barcode:113874807201, name:combination switch, model:3024100-005, category:electrical, sub category:agt, color:default, location:s3_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874807834','Converter DC 48V-12V','upload/1389040107103.jpg','3048100-001','electrical','CLUB,EZGO,AGT,YAMAHA','default','25.80','50.00','100.00','11','5','S3','1','4_II shelf','2014-01-24 14:38:48','','barcode:113874807834, name:converter dc 48v-12v, model:3048100-001, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_1_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874808788','Converter DC 36V-12V','upload/1389040227260.jpg','3048100-002','electrical','AGT','default','25.80','50.00','100.00','16','5','S3','1','4_III shelf','2014-03-20 10:48:18','','barcode:113874808788, name:converter dc 36v-12v, model:3048100-002, category:electrical, sub category:agt, color:default, location:s3_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874809185','Controller Curtis 1243-4320','upload/1389040407869.jpg','1005100-012','electrical','CLUB,EZGO,AGT','default','125.00','230.00','345.00','3','3','S3','1','4_IV shelf','2014-01-24 14:33:56','','barcode:113874809185, name:controller curtis 1243-4320, model:1005100-012, category:electrical, sub category:club,ezgo,agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874811211','Controller Curtis 1266-5201','upload/1389284735170.jpg','1005100-013','electrical','CLUB,EZGO,AGT','default','165.00','305.00','458.00','5','2','S3','1','4_IV shelf','2014-01-24 14:34:36','','barcode:113874811211, name:controller curtis 1266-5201, model:1005100-013, category:electrical, sub category:club,ezgo,agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874812661','Controller Curtis 1268-5403','upload/1389040631244.jpg','1005100-007','electrical','CLUB,EZGO,AGT','default','270.00','498.00','748.00','3','4','S3','1','4_IV shelf','2014-01-24 14:34:52','','barcode:113874812661, name:controller curtis 1268-5403, model:1005100-007, category:electrical, sub category:club,ezgo,agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874813410','Tail Light - LT - EG6118','upload/1389040955432.jpg','PKG','electrical','AGT','default','13.20','28.00','56.00','2','2','S3','1','5_III shelf','2014-01-29 10:22:40','','barcode:113874813410, name:tail light - lt - eg6118, model:pkg, category:electrical, sub category:agt, color:default, location:s3_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874815828','Tail Light - RT - EG6118','upload/1389041013697.jpg','PKG','electrical','AGT','default','13.20','28.00','56.00','2','2','S3','1','5_III shelf','2014-01-29 10:22:47','','barcode:113874815828, name:tail light - rt - eg6118, model:pkg, category:electrical, sub category:agt, color:default, location:s3_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874816080','Controller Curtis 1244-5461','upload/1389040532619.jpg','1005100-006','electrical','AGT','default','380.00','700.00','1050.00','5','2','S3','1','4_IV shelf','2014-01-24 14:34:12','','barcode:113874816080, name:controller curtis 1244-5461, model:1005100-006, category:electrical, sub category:agt, color:default, location:s3_1_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874816760','Converter DC 72V-12V','upload/1389040049432.jpg','3048100-006','electrical','AGT','default','43.50','83.00','166.00','2','2','S3','1','4_II shelf','2014-01-24 14:39:04','','barcode:113874816760, name:converter dc 72v-12v, model:3048100-006, category:electrical, sub category:agt, color:default, location:s3_1_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874833776','Combination Switch - Non Golf Cart','upload/1389026806447.jpg','3024100-004','electrical','AGT','default','11.60','24.00','48.00','3','2','S3','1','2_I shelf','2014-01-24 14:31:53','','barcode:113874833776, name:combination switch - non golf cart, model:3024100-004, category:electrical, sub category:agt, color:default, location:s3_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874835726','Speed Meter','upload/1389026911525.jpg','PKG','electrical','AGT','default','0.00','0.00','0.00','4','3','S3','1','2_I shelf','2014-01-06 11:48:32','','barcode:113874835726, name:speed meter, model:pkg, category:electrical, sub category:agt, color:default, location:s3_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874837101','AC Cable Extension','upload/1389204882717.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','1','25','S3','1','2_II shelf','2014-03-11 14:55:41','','barcode:113874837101, name:ac cable extension, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874838896','AC Cable ','upload/1389026992807.jpg','2024-3022104','electrical','AGT','default','5.60','0.00','0.00','92','25','S3','1','2_III-IV shelf','2014-03-21 15:22:53','Competitor Pricing\r\n[Nivel] - 16.00\r\n[Madjax] - N/A','barcode:113874838896, name:ac cable , model:2024-3022104, category:electrical, sub category:agt, color:default, location:s3_1_2_iii-iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874840236','Motor 48V 5KW','upload/1389041642932.jpg','undefined','electrical','AGT','default','575.00','1135.00','1700.00','1','1','S3','1','1_I floor','2014-01-29 09:56:38','','barcode:113874840236, name:motor 48v 5kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874841056','Motor 36V 3kw','upload/1389041627228.jpg','undefined','electrical','AGT','default','295.00','550.00','825.00','1','1','S3','1','1_II Floor','2014-01-29 09:55:59','','barcode:113874841056, name:motor 36v 3kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874841768','Motor 48V 3.8kw','upload/1389041611947.jpg','undefined','electrical','AGT','default','300.00','560.00','840.00','1','1','S3','1','1_II Floor','2014-01-29 09:56:10','','barcode:113874841768, name:motor 48v 3.8kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874842091','Motor 48V 5.3kw','upload/1389041596182.jpg','undefined','electrical','AGT','default','366.00','690.00','1035.00','1','1','S3','1','1_II Floor','2014-01-29 09:56:23','','barcode:113874842091, name:motor 48v 5.3kw, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874843125','Charger - Smart 36V-120V','upload/1389108839588.jpg','1103100-002','electrical','CLUB,EZGO,AGT,YAMAHA','default','399.00','783.00','1174.00','2','1','S3','1','1_III floor','2014-01-24 14:31:17','','barcode:113874843125, name:charger - smart 36v-120v, model:1103100-002, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_1_1_iii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874843531','Windshield Wiper Motor Assembly','upload/default.jpg','3006110-010','electrical','AGT','default','0.00','0.00','0.00','2','2','S3','1','1_III floor','2013-12-20 13:08:40','','barcode:113874843531, name:windshield wiper motor assembly, model:3006110-010, category:electrical, sub category:agt, color:default, location:s3_1_1_iii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874844445','Charger - DeltaQ 48V-110','upload/1389108803885.jpg','undefined','electrical','AGT','default','163.00','380.00','760.00','4','3','S3','1','1_IV floor','2014-02-18 16:48:26','','barcode:113874844445, name:charger - deltaq 48v-110, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_iv floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874845600','Charger - DeltaQ 36V-110','upload/1389108791385.jpg','undefined','electrical','AGT','default','160.00','370.00','740.00','3','2','S3','1','1_IV floor','2014-01-24 14:29:47','','barcode:113874845600, name:charger - deltaq 36v-110, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_iv floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874845946','Charger - DeltaQ 72V-110V','upload/1389108775947.jpg','undefined','electrical','AGT','default','190.00','390.00','780.00','4','2','S3','1','1_IV floor','2014-01-24 14:30:28','Expect Stock : 2','barcode:113874845946, name:charger - deltaq 72v-110v, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_1_iv floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874854618','Head Light - LH EG6118','upload/1389042082369.jpg','3101100-002','electrical','AGT','default','12.10','25.00','50.00','2','2','S3','2','5_I shelf','2014-01-28 15:50:49','','barcode:113874854618, name:head light - lh eg6118, model:3101100-002, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874855314','Head Light - RH EG6118','upload/1389042140135.jpg','3101200-002','electrical','AGT','default','12.10','25.00','50.00','2','2','S3','2','5_I shelf','2014-01-28 15:50:55','','barcode:113874855314, name:head light - rh eg6118, model:3101200-002, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874855716','Front Fog Light - EG6118','upload/1389042301369.jpg','3113100-001','electrical','AGT','default','4.40','9.60','19.20','2','3','S3','2','5_I shelf','2014-01-28 15:14:28','','barcode:113874855716, name:front fog light - eg6118, model:3113100-001, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874856197','Front Turn Light - EG6118','upload/1389042356978.jpg','3109100-002','electrical','AGT','default','2.30','6.50','13.00','4','3','S3','2','5_I shelf','2014-01-28 15:15:44','','barcode:113874856197, name:front turn light - eg6118, model:3109100-002, category:electrical, sub category:agt, color:default, location:s3_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874862027','Tail Light Assembled - LH - Truck','upload/1389104969494.jpg','PKG','body','EZGO,AGT','default','0.00','0.00','0.00','5','2','S3','2','5_II shelf','2014-01-07 09:29:30','','barcode:113874862027, name:tail light assembled - lh - truck, model:pkg, category:body, sub category:ezgo,agt, color:default, location:s3_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874862100','Tail Light Assembled - RH - Truck','upload/1389104909525.jpg','PKG','electrical','AGT','default','0.00','0.00','0.00','5','2','S3','2','5_II shelf','2014-01-07 09:28:30','','barcode:113874862100, name:tail light assembled - rh - truck, model:pkg, category:electrical, sub category:agt, color:default, location:s3_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874862955','Head Light - EG2020','upload/1389104639744.jpg','3101100-008','electrical','AGT','default','20.00','43.00','86.00','17','5','S3','2','5_III shelf','2014-04-09 16:46:14','','barcode:113874862955, name:head light - eg2020, model:3101100-008, category:electrical, sub category:agt, color:default, location:s3_2_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874863430','Battery Cable Jacket - Black','upload/1389041466275.jpg','1101014-002','electrical','CLUB,EZGO,AGT,YAMAHA','Black','0.40','1.50','3.00','122','30','S3','2','4_I shelf','2014-02-06 14:24:02','','barcode:113874863430, name:battery cable jacket - black, model:1101014-002, category:electrical, sub category:club,ezgo,agt,yamaha, color:black, location:s3_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874864521','Battery Cable Jacket - Red','upload/1389041507010.jpg','1101014-002','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.40','1.50','3.00','121','30','S3','2','4_I shelf','2014-02-06 14:24:02','','barcode:113874864521, name:battery cable jacket - red, model:1101014-002, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113874880273','Connect Wire 25x130mm ','upload/1389041594822.jpg','3313010-001','electrical','AGT','default','2.00','6.00','12.00','111','20','S3','2','4_II shelf','2014-01-24 14:33:12','','barcode:113874880273, name:connect wire 25x130mm , model:3313010-001, category:electrical, sub category:agt, color:default, location:s3_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875495207','Connect Wire 25x200mm ','upload/1389041641166.jpg','3313010-003','electrical','CLUB,EZGO,AGT,YAMAHA','default','2.00','6.00','12.00','132','30','S3','2','4_II shelf','2014-01-24 14:33:19','','barcode:113875495207, name:connect wire 25x200mm , model:3313010-003, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875495845','Connect Wire 25Ã—300mm ','upload/1389041854557.jpg','3313010-005 ','electrical','CLUB,EZGO,AGT,YAMAHA','default','2.00','6.00','12.00','42','20','S3','2','4_IV shelf','2014-01-24 14:32:52','','barcode:113875495845, name:connect wire 25Ã—300mm , model:3313010-005 , category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875496561','Connect Wire 25Ã—440mm ','upload/1389041712010.jpg','3313010-006 ','electrical','CLUB,EZGO,AGT,YAMAHA','default','2.00','6.00','12.00','49','20','S3','2','4_III shelf','2014-01-24 14:33:05','','barcode:113875496561, name:connect wire 25Ã—440mm , model:3313010-006 , category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875499828','Battery Dead Lever - L End','upload/1389041766228.jpg','1101011-004','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.70','2.00','4.00','42','10','S3','2','4_IV shelf','2014-01-24 13:14:29','','barcode:113875499828, name:battery dead lever - l end, model:1101011-004, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875502090','Battery Impact Block','upload/1389041972900.jpg','1101012-003','electrical','CLUB,EZGO,AGT,YAMAHA','default','3.70','7.50','15.00','28','10','S3','2','4_IV shelf','2014-01-24 13:15:04','','barcode:113875502090, name:battery impact block, model:1101012-003, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875502687','Battery Dead Lever - S End','upload/1389041916603.jpg','1101011-005','electrical','CLUB,EZGO,AGT,YAMAHA','default','0.60','2.00','4.00','21','10','S3','2','4_IV shelf','2014-01-24 13:14:40','','barcode:113875502687, name:battery dead lever - s end, model:1101011-005, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_4_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875504357','Accelerator','upload/1389025609853.jpg','1007100-004','electrical','AGT','default','63.80','130.00','195.00','7','3','S3','2','3_I shelf','2014-01-24 09:31:09','Competitor Pricing\r\n[Nivel] - 150.00\r\n[Madjax] - N/A','barcode:113875504357, name:accelerator, model:1007100-004, category:electrical, sub category:agt, color:default, location:s3_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875505132','Main Contactor - 36V 200A','upload/1389025745728.jpg','1005200','electrical','AGT','default','23.60','47.00','94.00','5','2','S3','2','3_II shelf','2014-01-28 15:57:58','','barcode:113875505132, name:main contactor - 36v 200a, model:1005200, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875506414','Main Contactor - 48V 125A','upload/1389025868010.jpg','1005200','electrical','AGT','default','20.00','40.00','80.00','4','2','S3','2','3_II shelf','2014-01-28 16:00:54','OLD PARTS. Discontinued Already','barcode:113875506414, name:main contactor - 48v 125a, model:1005200, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875506733','Main Contactor - 48V 300A','upload/1389026036213.jpg','1005200','electrical','AGT','default','49.00','94.00','188.00','1','2','S3','2','3_II shelf','2014-01-28 16:00:12','','barcode:113875506733, name:main contactor - 48v 300a, model:1005200, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875506994','Main Contactor - 48V 100A FSIP','upload/1389026104557.jpg','FSIP','electrical','AGT','default','50.00','75.00','100.00','4','0','S3','2','3_II shelf','2014-01-28 16:00:33','OLD Parts. Discontinued Already.','barcode:113875506994, name:main contactor - 48v 100a fsip, model:fsip, category:electrical, sub category:agt, color:default, location:s3_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875507516','Meter','upload/1389026204166.jpg','3212100-033','electrical','AGT','default','26.40','50.00','100.00','22','5','S3','2','3_III shelf','2014-01-28 16:14:26','','barcode:113875507516, name:meter, model:3212100-033, category:electrical, sub category:agt, color:default, location:s3_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875508403','Meter Holder','upload/1389026405807.jpg','5305180-036','electrical','AGT','Black','4.40','10.00','20.00','22','5','S3','2','3_III shelf','2014-01-28 16:14:36','','barcode:113875508403, name:meter holder, model:5305180-036, category:electrical, sub category:agt, color:black, location:s3_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875508802','Meter Wires - Long','upload/1389026578088.jpg','SE-91','electrical','AGT','default','12.10','25.00','50.00','16','5','S3','2','2_III shelf','2014-01-28 16:15:01','','barcode:113875508802, name:meter wires - long, model:se-91, category:electrical, sub category:agt, color:default, location:s3_2_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875510340','Meter Wires - Short','upload/1389026498478.jpg','SE-91','electrical','AGT','default','12.10','25.00','50.00','18','5','S3','2','2_IV shelf','2014-01-28 16:15:08','','barcode:113875510340, name:meter wires - short, model:se-91, category:electrical, sub category:agt, color:default, location:s3_2_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875510757','Meter Wires - Extension','upload/1389026690744.jpg','SE-91','electrical','AGT','default','12.10','25.00','50.00','4','5','S3','2','2_II shelf','2014-01-28 16:14:48','','barcode:113875510757, name:meter wires - extension, model:se-91, category:electrical, sub category:agt, color:default, location:s3_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875511107','Battery Impact Block Cap','upload/1389120846322.jpg','1101012-003','electrical','CLUB,EZGO,AGT,YAMAHA','default','3.70','7.00','15.00','39','10','S3','2','1_II Floor','2014-01-24 13:16:31','','barcode:113875511107, name:battery impact block cap, model:1101012-003, category:electrical, sub category:club,ezgo,agt,yamaha, color:default, location:s3_2_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875517870','Side rear view mirror - LH','upload/1387833581988.jpg','9002100-005','body','AGT','Black','30.00','63.00','126.00','4','2','S2','1','5_II shelf','2014-01-29 10:19:17','','barcode:113875517870, name:side rear view mirror - lh, model:9002100-005, category:body, sub category:agt, color:black, location:s2_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875518830','Side rear view mirror - LH','upload/1387833621067.jpg','9002100-005','body','AGT','silver','30.00','63.00','126.00','4','2','S2','1','5_II shelf','2014-01-29 10:19:26','','barcode:113875518830, name:side rear view mirror - lh, model:9002100-005, category:body, sub category:agt, color:silver, location:s2_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875519554','EG6020A4D Battery Cover on Front Body','upload/1387833393520.jpg','SE-199','electrical','AGT','default','56.00','100.00','200.00','1','1','S2','1','5_III shelf','2014-01-24 15:49:21','','barcode:113875519554, name:eg6020a4d battery cover on front body, model:se-199, category:electrical, sub category:agt, color:default, location:s2_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875523072','Motor Access EG6158','upload/1387833314645.jpg','5103051-014','mechanical','AGT','default','9.60','19.00','38.00','2','1','S2','1','5_III shelf','2014-01-29 09:57:25','','barcode:113875523072, name:motor access eg6158, model:5103051-014, category:mechanical, sub category:agt, color:default, location:s2_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875525170','Motor Cover - EG6040A4D','upload/1387833256613.jpg','PKG','body','AGT','default','4.00','9.00','18.00','2','1','S2','1','5_III shelf','2014-01-29 09:57:35','','barcode:113875525170, name:motor cover - eg6040a4d, model:pkg, category:body, sub category:agt, color:default, location:s2_1_5_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875527221','Split Windshield - Clipping block','upload/1388779137213.jpg','PKG','body','AGT','default','0.00','0.00','0.00','100','4','S2','1','4_I shelf','2014-01-10 10:56:11','','barcode:113875527221, name:split windshield - clipping block, model:pkg, category:body, sub category:agt, color:default, location:s2_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875528431','Split Windshield - Slip block','upload/1388779246088.jpg','PKG','body','AGT','default','1.20','4.00','8.00','100','10','S2','1','4_I shelf','2014-01-29 10:21:36','','barcode:113875528431, name:split windshield - slip block, model:pkg, category:body, sub category:agt, color:default, location:s2_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875562993','Cargo Box - Manual Dump - Handle','upload/1388778145963.jpg','undefined','body','AGT','default','2.10','4.60','9.20','44','5','S2','1','4_II shelf','2014-01-24 13:31:19','','barcode:113875562993, name:cargo box - manual dump - handle, model:undefined, category:body, sub category:agt, color:default, location:s2_1_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875563935','Sash (Clipper)','upload/1387836009629.jpg','5303021-012','body','EZGO,AGT','default','2.40','10.00','20.00','146','4','S2','1','3_I-III shelf','2014-02-20 14:00:29','','barcode:113875563935, name:sash (clipper), model:5303021-012, category:body, sub category:ezgo,agt, color:default, location:s2_1_3_i-iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875628522','Sash (Clipper) - One piece','upload/1387835959223.jpg','5303021-011','body','AGT','default','4.60','15.00','30.00','16','2','S2','1','3_III shelf','2014-01-29 10:13:19','','barcode:113875628522, name:sash (clipper) - one piece, model:5303021-011, category:body, sub category:agt, color:default, location:s2_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875682157','Canopy Handle - 2028 - 4 Passenger Plus','upload/1388761560447.jpg','5708010-014','body','AGT','default','2.10','4.60','9.20','36','5','S2','1','2_I shelf','2014-01-24 13:26:58','','barcode:113875682157, name:canopy handle - 2028 - 4 passenger plus, model:5708010-014, category:body, sub category:agt, color:default, location:s2_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875683616','Side Rear View Mirror Bass - L','upload/default.jpg','undefined','body','AGT','default','0.00','0.00','0.00','0','-1','S2','1','2_II shelf','2014-01-03 10:11:23','','barcode:113875683616, name:side rear view mirror bass - l, model:undefined, category:body, sub category:agt, color:default, location:s2_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875684999','Side Rear View Mirror Bass - Paired','upload/1388761777869.jpg','undefined','body','AGT','default','3.30','7.50','15.00','148','25','S2','1','2_II shelf','2014-01-29 10:20:34','','barcode:113875684999, name:side rear view mirror bass - paired, model:undefined, category:body, sub category:agt, color:default, location:s2_1_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875685230','Jacket For Caddie Handle -  Piece','upload/1388765105260.jpg','570104','body','AGT','default','1.20','4.00','8.00','656','20','S2','1','2_III shelf','2014-01-29 14:47:37','Included:\r\n5701041-036 #1 jacket for caddie handle (2)\r\n5701042-036 #2 jacket for caddie handle (2)','barcode:113875685230, name:jacket for caddie handle -  piece, model:570104, category:body, sub category:agt, color:default, location:s2_1_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875686804','Dustproof cover','upload/1388765339463.jpg','2701112-008','body','AGT','default','0.60','2.00','4.00','58','5','S2','1','2_IV shelf','2014-01-24 14:59:52','','barcode:113875686804, name:dustproof cover, model:2701112-008, category:body, sub category:agt, color:default, location:s2_1_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875687755','Floor Mat - Short','upload/1389121165025.jpg','2028-5106006','body','AGT','default','17.10','35.00','70.00','5','2','S2','1','1_I floor','2014-01-28 14:02:19','','barcode:113875687755, name:floor mat - short, model:2028-5106006, category:body, sub category:agt, color:default, location:s2_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875688937','Floor Mat - Long','upload/1389121244150.jpg','5107010-040','body','AGT','default','23.80','43.00','86.00','5','2','S2','1','1_I floor','2014-01-28 13:09:07','','barcode:113875688937, name:floor mat - long, model:5107010-040, category:body, sub category:agt, color:default, location:s2_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875689178','Enclosure for EG6118','upload/default.jpg','9015110-004','accessory','AGT','default','0.00','0.00','0.00','1','1','S2','1','1_II Floor','2013-12-20 14:56:09','','barcode:113875689178, name:enclosure for eg6118, model:9015110-004, category:accessory, sub category:agt, color:default, location:s2_1_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875693714','Underseat Compartment','upload/1388778907103.jpg','2028-9015022','body','AGT','default','13.82','44.00','0.00','7','2','S2','2','5_I shelf','2014-01-29 10:26:04','','barcode:113875693714, name:underseat compartment, model:2028-9015022, category:body, sub category:agt, color:default, location:s2_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875696246','Back Rest Cover - Plastic ','upload/1388778855385.jpg','7106111-036','body','AGT','default','8.00','23.00','46.00','20','2','S2','2','5_II shelf','2014-01-24 13:11:26','Competitor Pricing\r\n[Nivel] - 26.00\r\n[Madjax] - N/A','barcode:113875696246, name:back rest cover - plastic , model:7106111-036, category:body, sub category:agt, color:default, location:s2_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875703804','Canopy Handle - 2028','upload/1387834464238.jpg','5702021-036','body','AGT','default','1.60','3.70','7.40','10','0','S2','2','4_III shelf','2014-01-24 13:26:25','','barcode:113875703804, name:canopy handle - 2028, model:5702021-036, category:body, sub category:agt, color:default, location:s2_2_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875705210','Seat back support - carbon steel - EG2028K (Paired)','upload/1387834345801.jpg','7107011-036','body','AGT','default','7.40','17.00','34.00','0','0','S2','2','4_II shelf','2014-02-03 14:45:42','','barcode:113875705210, name:seat back support - carbon steel - eg2028k (paired), model:7107011-036, category:body, sub category:agt, color:default, location:s2_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875706287','Arm Rest - Paired','upload/1388777914932.jpg','7109100-036','body','AGT','default','16.40','45.00','90.00','2','2','S2','2','4_I shelf','2014-01-24 09:31:48','Competitor Pricing\r\n[Nivel] - 20.00\r\n[Madjax] - N/A','barcode:113875706287, name:arm rest - paired, model:7109100-036, category:body, sub category:agt, color:default, location:s2_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875707186','Sweater Basket Frame','upload/1387835896832.jpg','5405110-036 (PKG)','body','AGT','default','6.60','20.00','40.00','2','1','S2','2','3_I shelf','2014-01-29 10:22:15','Included\r\n405130-036 Bag Strap Clip (2)\r\n5405110-036 Sweater Basket frame (1)\r\n5405121-036 Basket frame rubber strip (1)\r\n5405122-036 Bag strap (1)\r\n5405123-036 Bag strap plate (1)\r\nQ2140655-304H\r\nBlack nickel cross slot pan head bolt M6Ã—55 (2)\r\nQ40206-304H \r\nBlack nickel big washer M6 (10)','barcode:113875707186, name:sweater basket frame, model:5405110-036 (pkg), category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875709563','Seat Back Sub-bracket','upload/1388777643041.jpg','7127011-037','body','AGT','default','3.60','7.50','15.00','10','10','S2','2','3_II shelf','2014-01-29 10:14:13','','barcode:113875709563, name:seat back sub-bracket, model:7127011-037, category:body, sub category:agt, color:default, location:s2_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875732227','Caddie Handle - 38.5 inches (Old Model)','upload/1388777242260.jpg','5701031-039','body','AGT','default','2.70','6.50','13.00','4','0','S2','2','3_I shelf','2014-01-24 13:24:36','2028KSZ','barcode:113875732227, name:caddie handle - 38.5 inches (old model), model:5701031-039, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875733270','Caddie Handle - 35 inches (Old Model)','upload/1388777307478.jpg','5701031-036','body','AGT','default','2.70','6.50','13.00','1','0','S2','2','3_I shelf','2014-01-24 13:23:22','2028K','barcode:113875733270, name:caddie handle - 35 inches (old model), model:5701031-036, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875734063','Caddie Handle - 39 inches','upload/1388777413369.jpg','5701031-047','body','AGT','default','2.70','6.50','13.00','2','2','S2','2','3_I shelf','2014-01-24 13:24:47','2040KSZ, 2048KSZ','barcode:113875734063, name:caddie handle - 39 inches, model:5701031-047, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875734794','Caddie Handle - 33 inches','upload/1388777453697.jpg','5701031-055','body','AGT','default','2.70','6.50','13.00','3','2','S2','2','3_I shelf','2014-01-24 13:23:09','2020ASZ','barcode:113875734794, name:caddie handle - 33 inches, model:5701031-055, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875735287','Caddie Handle - 38.5 inches','upload/1388777496510.jpg','5701031-039','body','AGT','default','2.70','6.50','13.00','0','2','S2','2','3_I shelf','2014-01-29 14:47:08','2028KSZ','barcode:113875735287, name:caddie handle - 38.5 inches, model:5701031-039, category:body, sub category:agt, color:default, location:s2_2_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875740798','Tie Rod','upload/1388777716932.jpg','2706100-036','body','AGT','default','2.30','7.50','15.00','18','0','S2','2','3_III shelf','2014-01-29 10:23:20','','barcode:113875740798, name:tie rod, model:2706100-036, category:body, sub category:agt, color:default, location:s2_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875741190','Steering Shaft Bushing','upload/1388766586025.jpg','2712011-036','body','AGT','default','0.80','2.00','4.00','50','5','S2','2','2_I shelf','2014-01-29 10:21:46','','barcode:113875741190, name:steering shaft bushing, model:2712011-036, category:body, sub category:agt, color:default, location:s2_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875741899','Hubcap - Aluminum','upload/1388766712432.jpg','2024-2301002A','body','AGT','default','1.20','4.00','8.00','196','20','S2','2','2_II shelf','2014-02-20 10:15:16','','barcode:113875741899, name:hubcap - aluminum, model:2024-2301002a, category:body, sub category:agt, color:default, location:s2_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875742842','Hubcap - Plastic','upload/1388767071728.jpg','2600114-048','body','AGT','default','0.60','2.00','4.00','118','2','S2','2','2_IV shelf','2014-01-28 15:55:55','','barcode:113875742842, name:hubcap - plastic, model:2600114-048, category:body, sub category:agt, color:default, location:s2_2_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875744437','Enclosure - EG2028KSZ','upload/default.jpg','9015110-037','body','AGT','default','0.00','0.00','0.00','10','3','S2','2','1_I floor','2013-12-20 16:21:22','','barcode:113875744437, name:enclosure - eg2028ksz, model:9015110-037, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875744839','Enclosure - EG6158','upload/default.jpg','9015110-002','body','AGT','default','0.00','0.00','0.00','1','1','S2','2','1_I floor','2013-12-20 16:22:27','','barcode:113875744839, name:enclosure - eg6158, model:9015110-002, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875745490','Enclosure - EG2048K','upload/default.jpg','9015110-040','body','AGT','default','0.00','0.00','0.00','2','3','S2','2','1_I floor','2014-01-02 09:46:11','','barcode:113875745490, name:enclosure - eg2048k, model:9015110-040, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875746339','Enclosure - EG6043','upload/default.jpg','9021100-006','body','AGT','default','0.00','0.00','0.00','2','1','S2','2','1_I floor','2014-01-02 09:45:47','','barcode:113875746339, name:enclosure - eg6043, model:9021100-006, category:body, sub category:agt, color:default, location:s2_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875749549','Rear Wheel Trim - Fender Flare (Paired)','upload/1389106866369.jpg','2020A-5502001','accessory','AGT','default','30.20','60.00','120.00','6','3','S4','1','5_II shelf','2014-01-29 10:03:28','','barcode:113875749549, name:rear wheel trim - fender flare (paired), model:2020a-5502001, category:accessory, sub category:agt, color:default, location:s4_1_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875750225','Front Wheel Trim - Fender Flare (Paired)','upload/1389106613697.jpg','2020A-5402001','accessory','AGT','default','13.50','57.00','114.00','7','3','S4','1','5_I shelf','2014-01-28 15:16:09','','barcode:113875750225, name:front wheel trim - fender flare (paired), model:2020a-5402001, category:accessory, sub category:agt, color:default, location:s4_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875752178','Braking Cable Assembly','upload/1389105338932.jpg','undefined','body','AGT','default','0.00','0.00','0.00','19','3','S4','1','4_I shelf','2014-01-07 09:35:40','','barcode:113875752178, name:braking cable assembly, model:undefined, category:body, sub category:agt, color:default, location:s4_1_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875752475','Windshield Wiper - EG6043','upload/1389107700510.jpg','6042-30160','body','AGT','default','0.00','0.00','0.00','1','1','S4','1','3_I shelf','2014-01-07 10:15:01','Included:\r\n6042-3016020 Windshield wiper arm (1)\r\n6042-3016030 Wiper brush (1)','barcode:113875752475, name:windshield wiper - eg6043, model:6042-30160, category:body, sub category:agt, color:default, location:s4_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875753656','Windshield Wiper - EG6118 (Paired)','upload/1389107763807.jpg','38340','body','AGT','default','0.00','0.00','0.00','2','2','S4','1','3_I shelf','2014-01-07 10:16:05','','barcode:113875753656, name:windshield wiper - eg6118 (paired), model:38340, category:body, sub category:agt, color:default, location:s4_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875756083','Copper Sheath - Thin','upload/1389108259822.jpg','2302112-008','body','AGT','default','1.10','3.00','6.00','10','0','S4','1','3_II shelf','2014-01-24 14:39:26','','barcode:113875756083, name:copper sheath - thin, model:2302112-008, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875756594','Copper Sheath - Thick','upload/1389108160463.jpg','2302113-008','body','AGT','default','1.10','3.00','6.00','10','0','S4','1','3_II shelf','2014-01-24 14:39:19','','barcode:113875756594, name:copper sheath - thick, model:2302113-008, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875757195','Bearing Assembly','upload/1389108380353.jpg','L44643','mechanical','AGT','default','1.70','3.80','7.60','1','0','S4','1','3_III shelf','2014-01-24 13:20:35','','barcode:113875757195, name:bearing assembly, model:l44643, category:mechanical, sub category:agt, color:default, location:s4_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875757827','Bearing 6206-Z','upload/1389108538635.jpg','6206','mechanical','AGT','default','4.30','9.50','19.00','20','0','S4','1','3_III shelf','2014-01-24 13:20:05','','barcode:113875757827, name:bearing 6206-z, model:6206, category:mechanical, sub category:agt, color:default, location:s4_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875758458','Redirector Assembly','upload/1389107899369.jpg','2701100-008','mechanical','AGT','default','25.80','52.00','104.00','2','0','S4','1','3_III shelf','2014-01-29 10:03:52','','barcode:113875758458, name:redirector assembly, model:2701100-008, category:mechanical, sub category:agt, color:default, location:s4_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113875764620','Wheel Nut - Aluminum Rim','upload/1389107848744.jpg','2600012-012','body','AGT','default','0.50','2.00','4.00','484','100','S4','1','3_II shelf','2014-02-20 10:15:16','','barcode:113875764620, name:wheel nut - aluminum rim, model:2600012-012, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878082911','Seat Belt Set - 2 point','upload/1389118692807.jpg','PKG','accessory','EZGO,AGT','default','8.10','20.00','40.00','41','3','S4','1','3_IV shelf','2014-01-29 10:16:40','','barcode:113878082911, name:seat belt set - 2 point, model:pkg, category:accessory, sub category:ezgo,agt, color:default, location:s4_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878086410','Seat Belt Set - 3 point','upload/1389118437228.jpg','PKG','accessory','EZGO,AGT','default','13.60','29.00','58.00','14','3','S4','1','3_IV shelf','2014-01-29 10:16:50','','barcode:113878086410, name:seat belt set - 3 point, model:pkg, category:accessory, sub category:ezgo,agt, color:default, location:s4_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878088327','Front Axle Assembly - EG2020','upload/1389120720385.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','11','2','S4','2','1_I floor','2014-01-07 13:52:01','Included:\r\n2300000-008 Front axle assembly (1)\r\nQ52110130 King pinÐ¤12Ã—130 (2)\r\nQ40212 Big gasket M12 (4)\r\n2302114-008 King pin pipe (2)\r\nQ40112 Gasket M12 (2)\r\nQ32612 Nut M12 (2)\r\nOiliness copper bush (4)\r\n2302100-015 Left knuckle (include item 2-7) (1)\r\n2302200-015 Right knuckle (include item 2-7) (1)\r\n\r\nFront Hub\r\n2600111-036 Front hub (2)\r\n44643/10 Bearing assembly (4)\r\nQ38324 Slotted nut M24 (2)\r\n2600114-048 Spindle cap (for steel wheel) (2)\r\n2024-2301002A Spindle cap (for aluminum\r\nwheel) (2)\r\nChromeplate 2600113-036 Oil seal (2)\r\n2302100-008 Spindle assembly LH (1)\r\n2600011-012 Tyre bolt M12Ã—45 (8)\r\n2302200-008 Spindle assembly RH (1)','barcode:113878088327, name:front axle assembly - eg2020, model:pkg, category:mechanical, sub category:agt, color:default, location:s4_2_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878088998','Front Axle Assembly - Semi','upload/1389120470103.jpg','2300000-008','mechanical','AGT','default','19.80','51.00','102.00','2','0','S4','1','2_I shelf','2014-01-28 14:02:45','Included:\r\n2300000-008 solely','barcode:113878088998, name:front axle assembly - semi, model:2300000-008, category:mechanical, sub category:agt, color:default, location:s4_1_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878093952','Rear Brake assembly RH','upload/1389120384744.jpg','2802200-007','mechanical','AGT','default','17.20','35.00','70.00','20','5','S4','2','2_II shelf','2014-01-29 10:01:44','Included:\r\n2802110-007 Brake shoe (2) \r\nMotherboard assembly (2)\r\nAdjusting screw LH (1)\r\nAdjusting screw RH (1)\r\nRatchet wheel LH (1)\r\nRatchet wheel RH (1)\r\nMandril head (2)\r\nQ150B0825 Bolt M8Ã—25 (8)\r\nQ32608 Self-lock nut M8 (8)\r\nBearing peg (4)\r\nSpring and cuppy restrainer (4)\r\nUpside return spring (2)\r\nUnderside return spring (2)\r\nAdjusting spring (2)\r\nDialing clip LH (1)\r\nDialing clip RH (1)','barcode:113878093952, name:rear brake assembly rh, model:2802200-007, category:mechanical, sub category:agt, color:default, location:s4_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878094409','Rear Brake assembly LH','upload/1389120271353.jpg','2802100-007','mechanical','AGT','default','17.20','35.00','70.00','19','5','S4','1','2_III shelf','2014-03-21 15:22:53','Included:\r\n2802110-007 Brake shoe (2) \r\nMotherboard assembly (2)\r\nAdjusting screw LH (1)\r\nAdjusting screw RH (1)\r\nRatchet wheel LH (1)\r\nRatchet wheel RH (1)\r\nMandril head (2)\r\nQ150B0825 Bolt M8Ã—25 (8)\r\nQ32608 Self-lock nut M8 (8)\r\nBearing peg (4)\r\nSpring and cuppy restrainer (4)\r\nUpside return spring (2)\r\nUnderside return spring (2)\r\nAdjusting spring (2)\r\nDialing clip LH (1)\r\nDialing clip RH (1)','barcode:113878094409, name:rear brake assembly lh, model:2802100-007, category:mechanical, sub category:agt, color:default, location:s4_1_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878096654','Brake Shoe','upload/1389120209744.jpg','2802110-007','mechanical','AGT','default','1.60','5.00','10.00','46','0','S4','1','2_IV shelf','2014-01-24 13:21:22','','barcode:113878096654, name:brake shoe, model:2802110-007, category:mechanical, sub category:agt, color:default, location:s4_1_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878098067','Brake Shoe - Unidentified','upload/1389120119150.jpg','6082-2801080/ 280111','mechanical','AGT','default','0.00','0.00','0.00','48','0','S4','1','2_IV shelf','2014-01-07 13:42:00','','barcode:113878098067, name:brake shoe - unidentified, model:6082-2801080/ 280111, category:mechanical, sub category:agt, color:default, location:s4_1_2_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878099978','Front Axle Assembly - EG2028','','PKG','mechanical','AGT','default','0.00','0.00','0.00','0','2','S4','1','1_I floor','2014-01-07 11:44:10','Included:\r\n2300000-008 Front axle assembly (1)\r\nQ52110130 King pinÐ¤12Ã—130 (2)\r\nQ40212 Big gasket M12 (4)\r\n2302114-008 King pin pipe (2)\r\nQ40112 Gasket M12 (2)\r\nQ32612 Nut M12 (2)\r\nOiliness copper bush (4)\r\n2302100-015 Left knuckle (include item 2-7) (1)\r\n2302200-015 Right knuckle (include item 2-7) (1)\r\n\r\nFront Hub\r\n2600111-036 Front hub (2)\r\n44643/10 Bearing assembly (4)\r\nQ38324 Slotted nut M24 (2)\r\n2600114-048 Spindle cap (for steel wheel) (2)\r\n2024-2301002A Spindle cap (for aluminum\r\nwheel) (2)\r\nChromeplate 2600113-036 Oil seal (2)\r\n2302100-008 Spindle assembly LH (1)\r\n2600011-012 Tyre bolt M12Ã—45 (8)\r\n2302200-008 Spindle assembly RH (1)','barcode:113878099978, name:front axle assembly - eg2028, model:pkg, category:mechanical, sub category:agt, color:default, location:s4_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878103106','Rear Axle Assembly ','upload/1389113034150.jpg','PKG','mechanical','AGT','default','281.50','520.00','780.00','1','1','h','1','0','2014-02-20 14:06:05','','barcode:113878103106, name:rear axle assembly , model:pkg, category:mechanical, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878103505','Rear Bumper - EG2020/ EG2028','upload/1389107271510.jpg','5406110-010','body','AGT','default','10.00','21.50','43.00','11','3','S4','2','5_I shelf','2014-01-30 14:01:32','','barcode:113878103505, name:rear bumper - eg2020/ eg2028, model:5406110-010, category:body, sub category:agt, color:default, location:s4_2_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878104320','Motor Access - EG2028/ EG2020','upload/1389107587353.jpg','5402041-036','body','AGT','default','4.40','9.50','19.00','37','4','S4','2','5_II shelf','2014-04-10 14:06:08','','barcode:113878104320, name:motor access - eg2028/ eg2020, model:5402041-036, category:body, sub category:agt, color:default, location:s4_2_5_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878104955','Fender scuffguard - Paired','upload/1389105496557.jpg','5402021-036','body','AGT','default','3.20','7.50','15.00','7','1','S4','2','4_I shelf','2014-01-24 15:50:49','','barcode:113878104955, name:fender scuffguard - paired, model:5402021-036, category:body, sub category:agt, color:default, location:s4_2_4_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878106177','Front Bumper - EG2028','upload/1389106276182.jpg','5307110-007','body','AGT','default','11.80','26.00','52.00','9','2','S4','2','4_II shelf','2014-01-28 15:09:02','','barcode:113878106177, name:front bumper - eg2028, model:5307110-007, category:body, sub category:agt, color:default, location:s4_2_4_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878106590','Front Bumper - EG2020 - Plastic','upload/1389106385900.jpg','5307110-008','body','AGT','default','4.40','12.00','24.00','2','2','S4','2','4_III shelf','2014-03-21 15:22:53','','barcode:113878106590, name:front bumper - eg2020 - plastic, model:5307110-008, category:body, sub category:agt, color:default, location:s4_2_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878107737','Front Shock Absorber Assembly - EG2020','upload/1389118951353.jpg','2504100-005','mechanical','AGT','default','8.50','18.50','37.00','8','2','S4','2','3_II shelf','2014-01-28 15:14:57','','barcode:113878107737, name:front shock absorber assembly - eg2020, model:2504100-005, category:mechanical, sub category:agt, color:default, location:s4_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878109179','Front Shock Absorber Assembly - EG2028','upload/1389119027010.jpg','2504100-003','mechanical','AGT','default','7.20','16.00','32.00','2','2','S4','2','3_III shelf','2014-01-28 15:15:12','','barcode:113878109179, name:front shock absorber assembly - eg2028, model:2504100-003, category:mechanical, sub category:agt, color:default, location:s4_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878109505','Front Shock Absorber Assembly - Unidentified','upload/1389119110010.jpg','PKG','mechanical','AGT','default','8.00','18.00','36.00','2','2','S4','2','3_II shelf','2014-01-28 15:15:32','','barcode:113878109505, name:front shock absorber assembly - unidentified, model:pkg, category:mechanical, sub category:agt, color:default, location:s4_2_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878110008','Left Knuckle','upload/1389119292900.jpg','2302100-008','mechanical','AGT','default','16.00','37.00','74.00','8','0','S4','2','3_III shelf','2014-01-28 15:57:46','Included:\r\n2302112-008 Oiliness copper bushï¼ˆthickï¼‰(1)\r\n2302113-008 Oiliness copper bush (thin) (1)','barcode:113878110008, name:left knuckle, model:2302100-008, category:mechanical, sub category:agt, color:default, location:s4_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878112510','Right Knuckle','upload/1389119358447.jpg','2302200-008','mechanical','AGT','default','18.20','40.00','80.00','7','0','S4','2','3_III shelf','2014-01-29 10:12:51','Included:\r\n2302112-008 Oiliness copper bushï¼ˆthickï¼‰(1)\r\n2302113-008 Oiliness copper bush (thin) (1)','barcode:113878112510, name:right knuckle, model:2302200-008, category:mechanical, sub category:agt, color:default, location:s4_2_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878112939','Watering System','upload/1389119544557.jpg','PKG','accessory','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','2','2','S4','2','3_IV shelf','2014-01-07 13:32:26','','barcode:113878112939, name:watering system, model:pkg, category:accessory, sub category:club,ezgo,agt,yamaha, color:default, location:s4_2_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878113414','Front Leaf Spring Assembly','upload/default.jpg','2501100-008','mechanical','AGT','default','0.00','0.00','0.00','0','2','S4','2','2_I shelf','2014-01-07 13:40:28','','barcode:113878113414, name:front leaf spring assembly, model:2501100-008, category:mechanical, sub category:agt, color:default, location:s4_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878114441','Rear Leaf Spring Assembly','upload/1389119947385.jpg','2508100-013','mechanical','AGT','default','10.80','22.00','44.00','6','2','S4','2','2_I shelf','2014-01-29 10:02:51','','barcode:113878114441, name:rear leaf spring assembly, model:2508100-013, category:mechanical, sub category:agt, color:default, location:s4_2_2_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878115393','Seat Belt Set - 3 point (Large)','upload/1389119799244.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','10','2','S4','2','2_II shelf','2014-01-07 13:36:40','','barcode:113878115393, name:seat belt set - 3 point (large), model:pkg, category:accessory, sub category:agt, color:default, location:s4_2_2_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878118605','Tie Rod Joint','upload/1389119714666.jpg','2706120-036','mechanical','AGT','default','4.80','15.00','30.00','33','0','S4','2','2_III shelf','2014-01-29 10:23:50','','barcode:113878118605, name:tie rod joint, model:2706120-036, category:mechanical, sub category:agt, color:default, location:s4_2_2_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878118930','Rear Brake Drum','upload/1389120969260.jpg','2802210-007','mechanical','AGT','default','6.50','14.00','28.00','6','0','S4','2','1_II Floor','2014-01-29 10:01:54','','barcode:113878118930, name:rear brake drum, model:2802210-007, category:mechanical, sub category:agt, color:default, location:s4_2_1_ii floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878120248','Top Canopy Bracket - EG2028KSF/ EG2028KSZ','upload/default.jpg','5701061-037','body','AGT','default','12.00','30.00','60.00','29','0','H','4','0','2014-01-30 14:01:32','','barcode:113878120248, name:top canopy bracket - eg2028ksf/ eg2028ksz, model:5701061-037, category:body, sub category:agt, color:default, location:h_4_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878120972','Front Bracket - Normal','upload/default.jpg','5701011-039','body','AGT','default','10.10','26.00','52.00','10','0','H','2','0','2014-01-28 15:08:34','','barcode:113878120972, name:front bracket - normal, model:5701011-039, category:body, sub category:agt, color:default, location:h_2_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878122294','Top Canopy Bracket - EG2048KSF/ 2048KSZ','upload/default.jpg','5701061-040','body','AGT','default','16.00','35.00','70.00','13','0','H','1','0','2014-01-29 10:24:36','','barcode:113878122294, name:top canopy bracket - eg2048ksf/ 2048ksz, model:5701061-040, category:body, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878123216','Top Canopy Bracket - EG2068KSZ','upload/default.jpg','PKG','body','AGT','default','24.20','55.00','110.00','3','0','H','1','0','2014-01-29 10:24:47','','barcode:113878123216, name:top canopy bracket - eg2068ksz, model:pkg, category:body, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878123902','Front Bracket - EG2020ASZ','upload/default.jpg','3041-5601001','body','AGT','default','10.00','26.00','52.00','3','0','H','3','0','2014-01-28 15:08:20','','barcode:113878123902, name:front bracket - eg2020asz, model:3041-5601001, category:body, sub category:agt, color:default, location:h_3_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878261008','Shunt','upload/1388434190647.jpg','1005310-002','electrical','AGT','default','5.80','12.00','24.00','2','5','S3','1','3_I shelf','2014-01-29 10:18:09','','barcode:113878261008, name:shunt, model:1005310-002, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878263216','Main Fuse - 425A','upload/1389024274041.jpg','F26-ANL-425A','electrical','AGT','default','6.10','12.00','24.00','30','10','S3','1','3_II shelf','2014-01-28 16:14:14','','barcode:113878263216, name:main fuse - 425a, model:f26-anl-425a, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878264399','Controller Fuse','upload/1389024767260.jpg','1005410-001','electrical','AGT','default','0.40','2.00','4.00','88','20','S3','1','3_IV shelf','2014-01-24 14:35:02','','barcode:113878264399, name:controller fuse, model:1005410-001, category:electrical, sub category:agt, color:default, location:s3_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878265368','Attach Fuse socket','upload/1389024631916.jpg','1005420-001','electrical','AGT','default','0.90','3.50','7.00','30','5','S3','1','3_IV shelf','2014-01-24 09:32:40','Competitor Pricing\r\n[Nivel] - 5.00\r\n[Madjax] - N/A','barcode:113878265368, name:attach fuse socket, model:1005420-001, category:electrical, sub category:agt, color:default, location:s3_1_3_iv shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878265874','Battery Protector','upload/1389038849416.jpg','1102100-003','electrical','AGT','default','14.90','32.00','64.00','2','2','S3','1','3_II shelf','2014-01-24 13:17:15','','barcode:113878265874, name:battery protector, model:1102100-003, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878266414','Reverse Buzzer - Truck/ Bus','upload/1389038672682.jpg','3211010-001','electrical','AGT','default','3.30','8.50','17.00','1','2','S3','1','3_I shelf','2014-01-29 10:04:25','','barcode:113878266414, name:reverse buzzer - truck/ bus, model:3211010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878269647','Reverse Buzzer - Golf','upload/1389038517369.jpg','3211010-003','electrical','AGT','default','2.10','4.50','9.00','18','5','S3','1','3_I shelf','2014-01-29 10:04:13','','barcode:113878269647, name:reverse buzzer - golf, model:3211010-003, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878270780','Fuse Box - Golf','upload/1389038945213.jpg','3308100-002','body','AGT','default','3.10','7.20','14.40','10','5','S3','1','3_II shelf','2014-01-28 15:16:22','','barcode:113878270780, name:fuse box - golf, model:3308100-002, category:body, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878271280','Electric Horn - Golf','upload/1389297872326.jpg','3004010-001','electrical','AGT','default','1.20','3.00','6.00','10','10','S3','1','3_I shelf','2014-01-24 15:49:41','','barcode:113878271280, name:electric horn - golf, model:3004010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878272184','Time-lapse Relay - Golf','upload/1389025367416.jpg','3040010-003','electrical','AGT','default','2.50','7.50','15.00','1','5','S3','1','3_V shelf','2014-01-29 10:24:00','','barcode:113878272184, name:time-lapse relay - golf, model:3040010-003, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878272791','Electronic Flasher','upload/1389024555166.jpg','3129010-002','electrical','AGT','default','1.90','4.20','8.40','11','10','S3','1','3_III shelf','2014-01-24 15:49:59','','barcode:113878272791, name:electronic flasher, model:3129010-002, category:electrical, sub category:agt, color:default, location:s3_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878273877','Auxiliary relay - 48V','upload/1389024471713.jpg','3040010-002','electrical','AGT','default','1.60','4.50','9.00','12','10','S3','1','3_III shelf','2014-01-24 09:32:52','Competitor Pricing\r\n[Nivel] - N/A\r\n[Madjax] - N/A','barcode:113878273877, name:auxiliary relay - 48v, model:3040010-002, category:electrical, sub category:agt, color:default, location:s3_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878274626','Main Fuse - 250A','upload/1389024196728.jpg','F26-ANL-250A','body','AGT','default','6.10','12.00','24.00','23','5','S3','1','3_II shelf','2014-01-28 16:14:03','','barcode:113878274626, name:main fuse - 250a, model:f26-anl-250a, category:body, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878275369','Tow/Run Switch','upload/1389022095713.jpg','3032020-001','electrical','AGT','default','1.00','4.00','8.00','17','5','S3','1','3_II shelf','2014-01-29 10:25:15','','barcode:113878275369, name:tow/run switch, model:3032020-001, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878275921','Brake Light Switch','upload/1389022184697.jpg','3127010-001','electrical','AGT','default','1.40','4.00','8.00','17','10','S3','1','3_II shelf','2014-03-20 10:48:18','','barcode:113878275921, name:brake light switch, model:3127010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878276989','Universal Start Key','upload/1389039024838.jpg','3001010-003','electrical','AGT','default','2.90','7.00','14.00','24','10','S3','1','3_III shelf','2014-01-29 10:26:13','','barcode:113878276989, name:universal start key, model:3001010-003, category:electrical, sub category:agt, color:default, location:s3_1_3_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878277615','F/R Switch','upload/1389024968807.jpg','3032010-001','electrical','AGT','default','1.70','4.00','8.00','18','10','S3','1','3_V shelf','2014-01-24 15:50:28','','barcode:113878277615, name:f/r switch, model:3032010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878278199','Power Meter - 36V','upload/1389025435557.jpg','3217010-001','electrical','AGT','default','25.10','50.00','75.00','15','10','S3','1','3_VI shelf','2014-01-29 09:59:22','','barcode:113878278199, name:power meter - 36v, model:3217010-001, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878278718','Power Meter - 48V','upload/1389025280853.jpg','3217010-002','electrical','AGT','default','25.20','50.00','75.00','13','10','S3','1','3_VI shelf','2014-01-29 09:59:33','','barcode:113878278718, name:power meter - 48v, model:3217010-002, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878279170','Speed Sensor','upload/1389039333150.jpg','3202020-005','electrical','AGT','default','10.80','23.00','46.00','8','5','S3','1','3_V shelf','2014-01-29 10:21:15','','barcode:113878279170, name:speed sensor, model:3202020-005, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878280024','Carbon Brush - Chinese Motor','upload/1389021738119.jpg','XQ-3-4/020','electrical','AGT','default','6.10','14.00','28.00','6','2','S3','1','3_I shelf','2014-01-24 13:29:09','','barcode:113878280024, name:carbon brush - chinese motor, model:xq-3-4/020, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878280863','Carbon brush - ADC motor','upload/1389021914088.jpg','ZQS48-3.8-T/020','electrical','AGT','default','11.20','24.00','48.00','25','2','S3','1','3_I shelf','2014-01-24 13:28:20','','barcode:113878280863, name:carbon brush - adc motor, model:zqs48-3.8-t/020, category:electrical, sub category:agt, color:default, location:s3_1_3_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878281176','Speed sensor - ADC motor','upload/1389039385150.jpg','3202020-004','electrical','AGT','default','8.10','18.00','36.00','6','5','S3','1','3_V shelf','2014-01-29 10:21:25','','barcode:113878281176, name:speed sensor - adc motor, model:3202020-004, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878282207','Head Light Bulb - EG2028','upload/1389039169150.jpg','3117130-002','electrical','AGT','default','3.80','7.50','15.00','21','10','S3','1','3_V shelf','2014-01-28 15:51:15','','barcode:113878282207, name:head light bulb - eg2028, model:3117130-002, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878282586','Turn Light Bulb - EG2028','upload/1389039108025.jpg','3126140-003','electrical','AGT','default','0.80','2.50','5.00','15','10','S3','1','3_V shelf','2014-04-09 16:46:14','','barcode:113878282586, name:turn light bulb - eg2028, model:3126140-003, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878283060','LED light Wire - On board','upload/1389025537135.jpg','undefined','electrical','AGT','default','10.00','17.00','34.00','5','2','S3','1','3_VI shelf','2014-01-28 15:56:54','','barcode:113878283060, name:led light wire - on board, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878283910','Turn light bulb - EG2020','upload/1389039485197.jpg','3109100-005','electrical','AGT','default','2.50','6.00','12.00','4','10','S3','1','3_VI shelf','2014-04-09 16:46:14','','barcode:113878283910, name:turn light bulb - eg2020, model:3109100-005, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878284719','Rear Light Bulb - Golf','upload/1389039246291.jpg','undefined','electrical','AGT','default','0.00','0.00','0.00','18','10','S3','1','3_VI shelf','2014-01-06 15:14:07','','barcode:113878284719, name:rear light bulb - golf, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878285629','Reflector','upload/1389039433853.jpg','undefined','accessory','AGT','default','2.00','4.50','9.00','10','2','S3','1','3_VI shelf','2014-01-29 10:04:00','','barcode:113878285629, name:reflector, model:undefined, category:accessory, sub category:agt, color:default, location:s3_1_3_vi shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878286445','Hi-Low Switch','upload/1389025128057.jpg','undefined','electrical','AGT','default','1.70','4.00','8.00','20','5','S3','1','3_V shelf','2014-01-28 15:55:22','','barcode:113878286445, name:hi-low switch, model:undefined, category:electrical, sub category:agt, color:default, location:s3_1_3_v shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878321298','Side Rear View Mirror - RH','upload/1387834072442.jpg','9002200-005','body','AGT','Silver','54.00','107.00','160.00','2','2','S2','1','5_I shelf','2014-01-29 10:19:45','','barcode:113878321298, name:side rear view mirror - rh, model:9002200-005, category:body, sub category:agt, color:silver, location:s2_1_5_i shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878969596','Oil Seal 32/47/8','upload/1389108890025.jpg','Undefined','body','AGT','default','0.80','2.50','5.00','40','5','S4','1','3_II shelf','2014-01-29 09:57:55','Oil Seal (1st shaft of retcuder)','barcode:113878969596, name:oil seal 32/47/8, model:undefined, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878970448','Oil Seal 50.3/43.1/9','upload/1389108757010.jpg','Undefined','body','AGT','default','0.60','2.50','5.00','20','5','S4','1','3_II shelf','2014-01-29 09:58:09','Oil Seal (Steering Knuckle)','barcode:113878970448, name:oil seal 50.3/43.1/9, model:undefined, category:body, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878972137','Oil Seal 42/55/7','upload/1389108974838.jpg','Undefined','mechanical','AGT','default','0.80','2.50','5.00','20','5','S4','1','3_II shelf','2014-01-29 09:58:01','Oil Seal (Half Shaft)','barcode:113878972137, name:oil seal 42/55/7, model:undefined, category:mechanical, sub category:agt, color:default, location:s4_1_3_ii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878983894','Wheel 21x11-10 CST/ Aluminum Rim F - Damaged','upload/default.jpg','PKG','tire_and_rim','CLUB,EZGO,AGT,YAMAHA','default','100.00','140.00','210.00','2','0','S4','1','1_I floor','2014-01-29 10:27:44','','barcode:113878983894, name:wheel 21x11-10 cst/ aluminum rim f - damaged, model:pkg, category:tire_and_rim, sub category:club,ezgo,agt,yamaha, color:default, location:s4_1_1_i floor');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878990073','Tyre valve','upload/1388778509557.jpg','2601210-004','body','CLUB,EZGO,AGT,YAMAHA','default','0.40','2.00','4.00','39','0','S2','1','4_III shelf','2014-01-29 10:25:54','','barcode:113878990073, name:tyre valve, model:2601210-004, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878990619','Shackle plate','upload/1388778281744.jpg','5402121-037','body','EZGO,AGT','default','0.40','2.00','4.00','19','0','S2','1','4_III shelf','2014-01-29 10:18:00','','barcode:113878990619, name:shackle plate, model:5402121-037, category:body, sub category:ezgo,agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878991309','Flip-Flop Seat Rubber Pad','upload/1388778447650.jpg','Undefined','body','AGT','default','0.40','1.00','2.00','17','3','S2','1','4_III shelf','2014-02-04 14:38:02','','barcode:113878991309, name:flip-flop seat rubber pad, model:undefined, category:body, sub category:agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878992304','Holding Block - Widshield','upload/1388778649432.jpg','5303022-011','body','AGT','default','0.40','2.00','4.00','70','0','S2','1','4_III shelf','2014-01-28 15:55:32','','barcode:113878992304, name:holding block - widshield, model:5303022-011, category:body, sub category:agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113878997974','Steering Wheel Cover','upload/1388778365416.jpg','2024-2704017','body','AGT','default','0.80','2.00','4.00','5','2','S2','1','4_III shelf','2014-01-29 10:21:56','','barcode:113878997974, name:steering wheel cover, model:2024-2704017, category:body, sub category:agt, color:default, location:s2_1_4_iii shelf');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113879004663','Battery - US 2200','upload/1389111169353.jpg','PKG','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','398','0','L','3-4','1','2014-04-10 14:02:53','','barcode:113879004663, name:battery - us 2200, model:pkg, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:l_3-4_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113879005228','Battery - Trojan T875','upload/1389111134947.jpg','PKG','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','28','0','L','3-4','1','2014-01-07 11:12:14','','barcode:113879005228, name:battery - trojan t875, model:pkg, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:l_3-4_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113879005492','Battery - Trojan T105','upload/1389111071822.jpg','PKG','body','CLUB,EZGO,AGT,YAMAHA','default','0.00','0.00','0.00','224','0','L','3-4','1','2014-03-20 10:48:18','','barcode:113879005492, name:battery - trojan t105, model:pkg, category:body, sub category:club,ezgo,agt,yamaha, color:default, location:l_3-4_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113890212526','Top Basket','upload/1389110290807.gif','5702100-048','accessory','AGT','default','52.40','125.00','185.00','2','1','h','1','0','2014-01-29 10:24:11','','barcode:113890212526, name:top basket, model:5702100-048, category:accessory, sub category:agt, color:default, location:h_1_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113897315200','Wheel 24x8-12 WAN DA with Aluminum Rim','upload/default.jpg','PKG','body','AGT','default','85.00','120.00','180.00','4','2','L','1','3_I SKID','2014-01-29 10:28:04','EG6040A4D','barcode:113897315200, name:wheel 24x8-12 wan da with aluminum rim, model:pkg, category:body, sub category:agt, color:default, location:l_1_3_i skid');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113958394533','Strobe Light - Blue and Red','upload/1395839846526.jpg','3124100-011     ','accessory','AGT','default','180.00','400.00','502.00','0','0','N/A','0','0','2014-03-26 09:17:27','','barcode:113958394533, name:strobe light - blue and red, model:3124100-011     , category:accessory, sub category:agt, color:default, location:n/a_0_0');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113958396331','Strobe Light - Yellow and Orange','upload/1395839704823.jpg','SE-305','accessory','AGT','default','180.00','400.00','502.00','0','0','N/A','0','0','2014-03-26 09:15:04','','barcode:113958396331, name:strobe light - yellow and orange, model:se-305, category:accessory, sub category:agt, color:default, location:n/a_0_0');
/*!40000 ALTER TABLE `ew_part` ENABLE KEYS */;


--
-- Create Table `ew_pending`
--

DROP TABLE IF EXISTS `ew_pending`;
CREATE TABLE `ew_pending` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user` varchar(20) CHARACTER SET utf8 NOT NULL,
  `client` varchar(40) CHARACTER SET utf8 NOT NULL,
  `quantity` int(10) NOT NULL,
  `table` varchar(20) CHARACTER SET utf8 NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_pending`
--

/*!40000 ALTER TABLE `ew_pending` DISABLE KEYS */;
INSERT INTO `ew_pending` (`pid`,`barcode`,`user`,`client`,`quantity`,`table`,`time`) VALUES ('19','013878273573','otto','classic cart','-1','ew_car','2014-04-10 14:00:13');
/*!40000 ALTER TABLE `ew_pending` ENABLE KEYS */;


--
-- Create Table `ew_relation`
--

DROP TABLE IF EXISTS `ew_relation`;
CREATE TABLE `ew_relation` (
  `rid` int(20) NOT NULL AUTO_INCREMENT,
  `main_part` varchar(20) CHARACTER SET utf8 NOT NULL,
  `attach_part` varchar(20) CHARACTER SET utf8 NOT NULL,
  `amount` int(20) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_relation`
--

/*!40000 ALTER TABLE `ew_relation` DISABLE KEYS */;
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('7','113855786227','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('11','113855773834','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('9','113855768358','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('12','113874838896','113874837101','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('13','113874837101','113874838896','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('14','113875706287','113861036513','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('15','113878265368','113878264399','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('16','113878264399','113878265368','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('17','113875696246','113860136683','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('18','113860136683','113875696246','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('20','113875499828','113875511107','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('21','113875511107','113875499828','2');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('22','113875502090','113875502687','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('23','113875502687','113875502090','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('24','113856726477','113874694069','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('25','113856730198','113874694069','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('26','113856724550','113874694069','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('27','113856726379','113874694069','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('28','113856732204','113874694069','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('29','113856717210','113874694069','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('30','113856717210','113874688608','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('31','113856724550','113874688608','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('32','113874657396','113874667209','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('33','113874667209','113874657396','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('34','113875749549','113875750225','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('35','113875750225','113875749549','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('36','113874806896','113874805471','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('37','113874805471','113874806896','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('38','113874854618','113874855314','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('39','113874855314','113874854618','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('40','113875507516','113875508403','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('42','113875508403','113875507516','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('43','113875507516','113875508802','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('44','113875508403','113875508802','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('45','113875507516','113875510340','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('46','113875508403','113875510340','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('47','113878094409','113878118930','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('48','113878093952','113878118930','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('49','113855795797','113875563935','2');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('50','113855789397','113875563935','2');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('51','113875563935','113855789397','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('52','113875563935','113855795797','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('53','113874010003','113875628522','2');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('54','113875628522','113874010003','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('55','113874801718','113874701375','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('56','113874701375','113874801718','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('57','113860136683','113875709563','2');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('58','113875705210','113875707186','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('59','113875705210','113874669055','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('60','113874669055','113875707186','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('61','113875707186','113874669055','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('62','113878082911','113874694562','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('63','113874694562','113878082911','2');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('64','113860146106','113875706287','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('65','113874033533','113875684999','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('66','113875684999','113874033533','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('67','113874802719','113874804634','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('68','113874804634','113874802719','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('70','113874862100','113874862027','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('71','113874862027','113874862100','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('72','113874815828','113874813410','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('73','113874813410','113874815828','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('74','113855780864','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('75','113855786227','113875741899','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('76','113855768358','113875741899','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('77','113855773834','113875741899','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('78','113897315200','113875741899','1');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('79','113897315200','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('80','113855777806','113875764620','4');
INSERT INTO `ew_relation` (`rid`,`main_part`,`attach_part`,`amount`) VALUES ('81','113855777806','113875741899','1');
/*!40000 ALTER TABLE `ew_relation` ENABLE KEYS */;


--
-- Create Table `ew_transaction`
--

DROP TABLE IF EXISTS `ew_transaction`;
CREATE TABLE `ew_transaction` (
  `tid` int(20) NOT NULL AUTO_INCREMENT COMMENT 'unique transection id',
  `user` varchar(20) NOT NULL COMMENT 'Who made this transection',
  `barcode` varchar(20) NOT NULL COMMENT 'UPC-A 12 digits barcode',
  `type` varchar(20) NOT NULL COMMENT 'Enter, pending, depart',
  `quantity` int(10) NOT NULL COMMENT 'Amount of items being trans',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Transaction time stamp',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=1150 DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_transaction`
--

/*!40000 ALTER TABLE `ew_transaction` DISABLE KEYS */;
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1','san','013849843167','car','1','2013-11-20 21:52:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('2','san','013849843596','car','1','2013-11-20 21:52:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('3','san','013849844238','car','1','2013-11-20 21:54:40');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('4','san','013849845400','car','1','2013-11-20 21:56:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('5','san','013849846414','car','1','2013-11-20 21:57:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('6','san','013849847336','car','1','2013-11-20 21:59:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('7','san','013849848035','car','1','2013-11-20 22:00:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('8','san','013849848309','car','1','2013-11-20 22:00:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('9','san','013849848727','car','1','2013-11-20 22:01:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('10','san','013849849042','car','1','2013-11-20 22:01:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('11','san','013849850219','car','1','2013-11-20 22:03:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('12','san','013849851104','car','1','2013-11-20 22:05:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('13','san','013849851341','car','1','2013-11-20 22:06:05');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('14','san','013849852101','car','1','2013-11-20 22:07:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('15','san','013849852326','car','1','2013-11-20 22:07:37');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('16','san','013849852676','car','1','2013-11-20 22:08:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('17','san','013849853196','car','1','2013-11-20 22:08:58');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('18','san','013849853756','car','1','2013-11-20 22:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('19','san','013849854322','car','1','2013-11-20 22:10:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('20','san','013849854684','car','1','2013-11-20 22:11:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('21','san','013849855695','car','1','2013-11-20 22:13:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('22','san','013849856001','car','1','2013-11-20 22:13:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('23','san','013849856394','car','1','2013-11-20 22:14:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('24','san','013849856577','car','1','2013-11-20 22:14:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('25','san','013849856801','car','1','2013-11-20 22:14:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('26','san','013849857035','car','1','2013-11-20 22:15:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('27','san','013849857340','car','1','2013-11-20 22:15:57');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('28','san','013849857778','car','1','2013-11-20 22:16:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('29','san','013849857969','car','1','2013-11-20 22:16:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('30','san','013849858260','car','1','2013-11-20 22:17:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('31','san','013849858479','car','1','2013-11-20 22:17:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('32','san','013849858782','car','1','2013-11-20 22:18:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('33','san','013849859041','car','1','2013-11-20 22:18:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('34','san','013849859323','car','1','2013-11-20 22:19:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('35','san','013849859659','car','1','2013-11-20 22:19:45');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('36','san','013849859999','car','1','2013-11-20 22:20:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('457','otto','013859994784','car','1','2013-12-02 10:54:10');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('977','otto','013859994784','car','-1','2013-12-23 16:35:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('976','san','113878321298','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('975','san','113878286445','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('974','san','113878285629','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('973','san','113878284719','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('972','san','113878283910','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('971','san','113878283060','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('970','san','113878282586','part','21','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('969','san','113878282207','part','21','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('968','san','113878281176','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('967','san','113878280863','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('966','san','113878280024','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('965','san','113878279170','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('964','san','113878278718','part','12','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('963','san','113878278199','part','15','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('962','san','113878277615','part','19','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('961','san','113878276989','part','25','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('960','san','113878275921','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('959','san','113878275369','part','17','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('958','san','113878274626','part','25','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('957','san','113878273877','part','12','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('956','san','113878272791','part','11','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('955','san','113878272184','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('954','san','113878271280','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('953','san','113878270780','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('952','san','113878269647','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('951','san','113878266414','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('950','san','113878265874','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('949','san','113878265368','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('948','san','113878264399','part','88','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('947','san','113878263216','part','29','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('946','san','113878261008','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('945','san','113878123902','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('944','san','113878123216','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('943','san','113878122294','part','13','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('942','san','113878120972','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('941','san','113878120248','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('940','san','113878118930','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('939','san','113878118605','part','33','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('938','san','113878115393','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('937','san','113878114441','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('936','san','113878113414','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('935','san','113878112939','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('934','san','113878112510','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('933','san','113878110008','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('932','san','113878109505','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('931','san','113878109179','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('930','san','113878107737','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('929','san','113878106590','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('928','san','113878106177','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('927','san','113878104955','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('926','san','113878104320','part','48','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('925','san','113878103505','part','13','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('924','san','113878103106','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('923','san','113878098067','part','48','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('922','san','113878096654','part','46','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('921','san','113878094409','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('920','san','113878093952','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('919','san','113878088998','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('918','san','113878088327','part','11','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('917','san','113878086410','part','15','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('916','san','113878082911','part','41','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('915','san','113875764620','part','500','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('914','san','113875758458','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('913','san','113875757827','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('912','san','113875757195','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('911','san','113875756594','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('910','san','113875756083','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('909','san','113875753656','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('908','san','113875752475','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('907','san','113875752178','part','19','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('906','san','113875750225','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('905','san','113875749549','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('904','san','113875746339','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('903','san','113875745490','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('902','san','113875744839','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('901','san','113875744437','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('900','san','113875742842','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('899','san','113875741899','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('898','san','113875741190','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('897','san','113875740798','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('896','san','113875735287','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('895','san','113875734794','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('894','san','113875734063','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('893','san','113875733270','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('892','san','113875732227','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('891','san','113875709563','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('890','san','113875707186','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('889','san','113875706287','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('888','san','113875705210','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('887','san','113875703804','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('886','san','113875696246','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('885','san','113875693714','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('884','san','113875689178','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('883','san','113875688937','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('882','san','113875687755','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('881','san','113875686804','part','58','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('880','san','113875685230','part','150','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('879','san','113875684999','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('878','san','113875683616','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('877','san','113875682157','part','36','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('876','san','113875628522','part','14','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('875','san','113875563935','part','147','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('874','san','113875562993','part','44','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('873','san','113875528431','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('872','san','113875527221','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('871','san','113875525170','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('870','san','113875523072','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('869','san','113875519554','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('868','san','113875518830','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('867','san','113875517870','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('866','san','113875511107','part','39','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('815','san','113874804634','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('865','san','113875510757','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('864','san','113875510340','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('863','san','113875508802','part','16','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('862','san','113875508403','part','22','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('861','san','113875507516','part','24','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('860','san','113875506994','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('859','san','113875506733','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('858','san','113875506414','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('857','san','113875505132','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('856','san','113875504357','part','7','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('855','san','113875502687','part','16','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('854','san','113875502090','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('853','san','113875499828','part','40','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('852','san','113875496561','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('851','san','113875495845','part','35','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('850','san','113875495207','part','66','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('849','san','113874880273','part','40','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('848','san','113874864521','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('847','san','113874863430','part','120','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('846','san','113874862955','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('845','san','113874862100','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('844','san','113874862027','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('843','san','113874856197','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('842','san','113874855716','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('841','san','113874855314','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('840','san','113874854618','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('839','san','113874845946','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('838','san','113874845600','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('837','san','113874844445','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('836','san','113874843531','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('835','san','113874843125','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('834','san','113874842091','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('833','san','113874841768','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('832','san','113874841056','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('831','san','113874840236','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('830','san','113874838896','part','80','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('829','san','113874835726','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('828','san','113874833776','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('827','san','113874816760','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('826','san','113874816080','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('825','san','113874815828','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('824','san','113874813410','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('823','san','113874812661','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('822','san','113874811211','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('821','san','113874809185','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('820','san','113874808788','part','14','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('819','san','113874807834','part','11','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('818','san','113874807201','part','30','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('817','san','113874806896','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('816','san','113874805471','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('814','san','113874802719','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('813','san','113874801718','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('812','san','113874701375','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('811','san','113874694562','part','100','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('810','san','113874690781','part','6','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('809','san','113874689510','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('808','san','113874688608','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('807','san','113874694069','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('806','san','113874676661','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('805','san','113874676203','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('804','san','113874669055','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('803','san','113874668190','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('802','san','113874667209','part','12','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('801','san','113874666349','part','14','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('800','san','113874665250','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('799','san','113874661256','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('798','san','113874660495','part','9','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('797','san','113874657396','part','18','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('796','san','113874033533','part','143','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('795','san','113878320669','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('794','san','113874010003','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('793','san','113874008674','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('698','otto','013878178357','car','1','2013-12-23 11:58:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('699','otto','013878179093','car','1','2013-12-23 11:58:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('700','otto','013878179678','car','1','2013-12-23 11:59:46');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('701','otto','013878181388','car','1','2013-12-23 12:02:43');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('702','otto','013878183182','car','1','2013-12-23 12:05:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('703','otto','013878248948','car','1','2013-12-23 13:55:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('704','otto','013878250105','car','1','2013-12-23 13:57:13');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('705','otto','013878250462','car','1','2013-12-23 13:57:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('706','otto','013878252345','car','1','2013-12-23 14:00:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('707','otto','013878252919','car','1','2013-12-23 14:01:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('708','otto','013878253878','car','1','2013-12-23 14:03:27');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('709','otto','013878254236','car','1','2013-12-23 14:04:13');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('710','otto','013878255184','car','1','2013-12-23 14:05:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('711','otto','013878255554','car','1','2013-12-23 14:06:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('712','otto','013878261696','car','1','2013-12-23 14:16:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('792','san','113874020209','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('791','san','113861036513','part','10','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('790','san','113861020767','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('789','san','113861020003','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('788','san','113860146106','part','24','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('718','otto','013878269189','car','1','2013-12-23 14:29:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('787','san','113860136683','part','22','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('720','otto','013878269640','car','1','2013-12-23 14:29:39');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('721','otto','013878269848','car','1','2013-12-23 14:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('722','otto','013878270074','car','1','2013-12-23 14:30:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('786','san','113860008361','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('785','san','113860007207','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('725','otto','013878271054','car','1','2013-12-23 14:32:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('784','san','113860007132','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('727','otto','013878272167','car','1','2013-12-23 14:33:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('783','san','113860005355','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('729','otto','013878272679','car','1','2013-12-23 14:34:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('730','otto','013878273016','car','1','2013-12-23 14:35:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('731','otto','013878273573','car','1','2013-12-23 14:36:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('782','san','113860002295','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('733','otto','013878273839','car','1','2013-12-23 14:36:38');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('734','otto','013878274028','car','1','2013-12-23 14:37:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('781','san','113856751895','part','1','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('736','otto','013878274540','car','1','2013-12-23 14:37:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('737','otto','013878274827','car','1','2013-12-23 14:38:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('780','san','113856751451','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('739','otto','013878275466','car','1','2013-12-23 14:39:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('779','san','113856750152','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('741','otto','013878275778','car','1','2013-12-23 14:39:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('778','san','113856732204','part','3','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('777','san','113856730198','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('776','san','113856726477','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('775','san','113856726379','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('774','san','113856724550','part','2','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('773','san','113856717210','part','5','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('772','san','113856688951','part','50','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('771','san','113856688278','part','47','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('770','san','113855795797','part','20','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('769','san','113855789397','part','62','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('768','san','113855787534','part','40','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('767','san','113855786227','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('766','san','113855768358','part','28','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('765','san','113855773834','part','28','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('764','san','113855777806','part','8','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('763','san','113855780864','part','4','2013-12-23 16:30:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('758','otto','013878292620','car','1','2013-12-23 15:08:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('978','otto','113874838896','part','-2','2013-12-23 16:51:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('979','otto','113878103505','part','-1','2013-12-23 16:51:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('980','otto','113874880273','part','71','2013-12-23 18:42:36');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('981','otto','113875495207','part','66','2013-12-23 18:42:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('982','otto','113875496561','part','19','2013-12-23 18:45:43');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('983','otto','113875502687','part','5','2013-12-23 18:46:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('984','otto','113875502090','part','8','2013-12-23 18:47:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('985','otto','113875499828','part','2','2013-12-23 18:48:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('986','otto','113875495845','part','7','2013-12-23 18:49:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('987','otto','113874033533','part','1','2013-12-23 20:17:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('988','otto','113874838896','part','2','2013-12-23 20:27:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('989','otto','113875563935','part','1','2013-12-23 20:27:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('990','otto','113874837101','part','2','2013-12-23 20:27:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('991','otto','113878969596','part','40','2013-12-24 09:57:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('992','otto','113878970448','part','20','2013-12-24 10:00:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('993','otto','113878972137','part','20','2013-12-24 10:01:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('994','otto','113874694562','part','5','2013-12-24 10:14:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('995','otto','113878983894','part','2','2013-12-24 10:20:41');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('996','otto','113878263216','part','1','2013-12-24 10:28:31');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('997','otto','113878990073','part','0','2013-12-24 10:31:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('998','otto','113878990619','part','0','2013-12-24 10:32:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('999','otto','113878991309','part','0','2013-12-24 10:33:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1000','otto','113878992304','part','0','2013-12-24 10:34:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1001','otto','113878990619','part','17','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1002','otto','113878990073','part','39','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1003','otto','113878991309','part','18','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1004','otto','113878992304','part','59','2013-12-24 10:42:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1005','otto','113878997974','part','4','2013-12-24 10:43:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1006','otto','113879004663','part','0','2013-12-24 10:55:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1007','otto','113879005228','part','0','2013-12-24 10:55:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1008','otto','113879005492','part','0','2013-12-24 10:56:36');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1009','otto','113855795797','part','1','2013-12-24 10:57:35');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1010','otto','113874694069','part','1','2013-12-24 11:02:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1011','otto','113874838896','part','1','2013-12-24 11:04:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1012','otto','113875742842','part','1','2013-12-24 11:04:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1013','otto','113879004663','part','424','2013-12-24 11:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1014','otto','113879005228','part','28','2013-12-24 11:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1015','otto','113879005492','part','232','2013-12-24 11:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1016','otto','113874809185','part','1','2013-12-24 11:17:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1017','otto','113856688278','part','2','2013-12-24 11:25:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1018','otto','113875507516','part','-2','2013-12-24 13:45:24');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1019','otto','113878992304','part','10','2013-12-24 13:47:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1020','otto ','113874010003','part','1','2013-12-30 15:38:27');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1021','otto ','113855789397','part','7','2013-12-30 15:40:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1022','otto ','113855795797','part','-1','2013-12-30 15:57:03');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1023','otto','113856688951','part','1','2014-01-02 10:44:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1024','otto','113856688951','part','-2','2014-01-02 10:58:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1025','otto ','113855786227','part','4','2014-01-02 15:03:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1026','otto ','113874666349','part','-7','2014-01-02 16:23:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1027','otto ','113874665250','part','-2','2014-01-02 16:29:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1028','otto ','113874661256','part','-2','2014-01-02 16:36:41');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1029','otto ','113874667209','part','-9','2014-01-02 16:41:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1030','otto','113874676661','part','-1','2014-01-02 16:45:24');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1031','otto ','113874676661','part','-1','2014-01-02 16:47:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1032','otto ','113874676661','part','1','2014-01-02 16:47:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1033','otto','113874694069','part','1','2014-01-03 09:52:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1034','otto','113875683616','part','-120','2014-01-03 10:11:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1035','otto','113875684999','part','28','2014-01-03 10:41:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1036','otto','113875685230','part','510','2014-01-03 11:04:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1037','otto','113875741899','part','80','2014-01-03 11:36:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1038','otto','113875742842','part','67','2014-01-03 11:41:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1039','otto','113875563935','part','2','2014-01-03 11:51:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1040','otto','113875628522','part','2','2014-01-03 13:06:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1041','otto','113878990619','part','2','2014-01-03 14:44:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1042','otto','113878997974','part','1','2014-01-03 14:46:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1043','otto','113878992304','part','1','2014-01-03 14:52:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1044','otto','113875527221','part','50','2014-01-03 15:01:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1045','otto','113875528431','part','50','2014-01-03 15:01:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1046','otto','113890212526','part','2','2014-01-06 10:16:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1047','otto ','113878280024','part','1','2014-01-06 10:22:40');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1048','otto ','113878280863','part','15','2014-01-06 10:25:37');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1049','otto ','113878261008','part','1','2014-01-06 10:26:47');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1050','otto','113878274626','part','-2','2014-01-06 11:02:46');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1051','otto','113878277615','part','-1','2014-01-06 11:17:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1052','otto','113878278718','part','1','2014-01-06 11:20:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1053','otto','113878283060','part','1','2014-01-06 11:25:12');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1054','otto ','113874807201','part','9','2014-01-06 15:22:57');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1055','otto ','113874808788','part','3','2014-01-06 15:31:25');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1056','otto-lau','113855795797','part','-1','2014-01-06 15:41:11');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1057','otto-lau','113855789397','part','1','2014-01-06 15:41:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1058','otto ','113878104320','part','-2','2014-01-07 10:09:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1059','otto ','113878086410','part','-1','2014-01-07 13:16:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1060','otto ','113878114441','part','3','2014-01-07 13:39:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1061','otto ','113878113414','part','-3','2014-01-07 13:40:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1062','otto ','113874838896','part','13','2014-01-07 13:49:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1063','otto-lau','113874008674','part','1','2014-01-07 14:14:56');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1064','otto-lau','113874033533','part','-1','2014-01-07 15:35:58');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1065','otto-lau','113855780864','part','-8','2014-01-09 15:14:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1066','otto-lau','113875519554','part','-1','2014-01-13 14:04:22');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1067','otto-lau','113855780864','part','4','2014-01-14 15:25:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1068','otto-lau','113855777806','part','-4','2014-01-14 15:25:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1069','otto-lau','113897315200','part','4','2014-01-14 15:32:05');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1070','Boyao-Wang','013849843596','car','-1','2014-01-15 09:50:45');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1071','otto-lau','113855773834','part','-1','2014-01-17 09:42:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1072','otto-lau','113874844445','part','1','2014-01-17 14:32:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1073','otto-lau','113878276989','part','-1','2014-01-22 09:28:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1074','otto-lau','013904144693','car','1','2014-01-22 13:18:55');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1075','Tracy-Liu','013904144693','car','1','2014-01-22 15:23:22');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1076','otto-lau','013904144693','car','-1','2014-01-22 15:41:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1077','otto-lau','113874666349','part','-1','2014-01-29 14:47:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1078','otto-lau','113855787534','part','-1','2014-01-29 14:47:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1079','otto-lau','113875735287','part','-1','2014-01-29 14:47:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1080','otto-lau','113875685230','part','-4','2014-01-29 14:47:37');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1081','otto-lau','113878104320','part','-1','2014-01-30 14:01:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1082','otto-lau','113874033533','part','-1','2014-01-30 14:01:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1083','otto-lau','113878103505','part','-1','2014-01-30 14:01:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1084','otto-lau','113878120248','part','-1','2014-01-30 14:01:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1085','otto-lau','113875705210','part','-2','2014-02-03 14:45:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1086','otto-lau','113855789397','part','-1','2014-02-04 10:10:39');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1087','Christal-Usiosefe','013904144693','car','-1','2014-02-04 14:22:29');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1088','Christal-Usiosefe','013904144693','car','1','2014-02-04 14:26:41');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1089','Christal-Usiosefe','013849856394','car','-1','2014-02-04 14:27:28');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1090','otto-lau','113874863430','part','2','2014-02-06 14:24:02');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1091','otto-lau','113874864521','part','1','2014-02-06 14:24:02');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1092','Christal-Usiosefe','013849848309','car','-1','2014-02-12 11:33:40');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1093','otto','013924049396','car','1','2014-02-14 14:09:03');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1094','otto','113874844445','part','1','2014-02-18 16:48:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1095','otto','113878991309','part','-1','2014-02-20 13:28:36');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1096','otto','113875563935','part','-2','2014-02-20 13:28:36');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1097','otto','113855780864','part','-1','2014-02-20 13:28:47');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1098','otto','113875563935','part','-2','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1099','otto','113855773834','part','-2','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1100','otto','113875764620','part','-16','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1101','otto','113875741899','part','-4','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1102','otto','113855768358','part','-2','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1103','otto','113860146106','part','-1','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1104','otto','113855795797','part','-1','2014-02-20 14:01:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1105','Christal-Usiosefe','013924049396','car','-1','2014-02-24 09:46:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1106','Christal-Usiosefe','113874837101','part','-1','2014-03-11 14:55:41');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1107','Christal-Usiosefe','013878178357','car','-1','2014-03-12 09:17:17');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1108','Christal-Usiosefe','113855789397','part','-1','2014-03-13 11:49:57');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1109','otto','113879005492','part','-8','2014-03-20 10:48:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1110','otto','113874838896','part','-1','2014-03-20 10:48:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1111','otto','113856717210','part','-1','2014-03-20 10:48:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1112','otto','113878282586','part','-2','2014-03-20 10:48:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1113','otto','113878275921','part','-1','2014-03-20 10:48:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1114','otto','113874808788','part','-1','2014-03-20 10:48:18');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1115','otto','113878106590','part','-1','2014-03-21 15:22:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1116','otto','113874033533','part','-1','2014-03-21 15:22:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1117','otto','113855795797','part','-1','2014-03-21 15:22:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1118','otto','113874838896','part','-1','2014-03-21 15:22:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1119','otto','113878094409','part','-1','2014-03-21 15:22:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1120','otto','013849858782','car','-1','2014-03-21 15:22:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1121','otto','013849852101','car','-1','2014-03-21 15:23:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1122','otto','113958394533','part','0','2014-03-26 09:13:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1123','otto','113958396331','part','0','2014-03-26 09:15:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1124','otto','013849859323','car','-1','2014-03-26 09:48:38');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1125','otto','013849859041','car','-1','2014-03-26 09:48:38');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1126','otto','013849857340','car','-1','2014-03-27 09:42:46');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1127','otto','013849857340','car','1','2014-04-01 16:32:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1128','otto','013963845512','car','1','2014-04-01 16:36:00');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1129','otto','013963845620','car','1','2014-04-01 16:38:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1130','otto','013878275778','car','-1','2014-04-04 10:51:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1131','otto','013849857035','car','-1','2014-04-04 10:51:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1132','otto','113855787534','part','-5','2014-04-09 10:47:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1133','otto','113878104320','part','-7','2014-04-09 10:47:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1134','otto','113874008674','part','-2','2014-04-09 10:47:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1135','otto','113855789397','part','-4','2014-04-09 10:47:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1136','otto','113855795797','part','-1','2014-04-09 10:47:26');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1137','otto','013849858260','car','-1','2014-04-09 11:39:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1138','otto','013849853756','car','-1','2014-04-09 15:42:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1139','otto','013878269848','car','-1','2014-04-09 15:42:42');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1140','otto','013878273839','car','-1','2014-04-09 15:46:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1141','otto','113874862955','part','-1','2014-04-09 16:46:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1142','otto','113878283910','part','-4','2014-04-09 16:46:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1143','otto','113878282586','part','-4','2014-04-09 16:46:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1144','otto','113879004663','part','-26','2014-04-10 14:02:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1145','otto','113855768358','part','-6','2014-04-10 14:04:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1146','otto','113855773834','part','-5','2014-04-10 14:04:33');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1147','otto','113855787534','part','-2','2014-04-10 14:06:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1148','otto','113878104320','part','-1','2014-04-10 14:06:08');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1149','otto','013878255554','car','-1','2014-04-11 13:09:20');
/*!40000 ALTER TABLE `ew_transaction` ENABLE KEYS */;


--
-- Create Table `ew_user`
--

DROP TABLE IF EXISTS `ew_user`;
CREATE TABLE `ew_user` (
  `user` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'User name',
  `pass` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'Password',
  `type` int(1) NOT NULL COMMENT '0. admin, 1.superuser, 2.user',
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_user`
--

/*!40000 ALTER TABLE `ew_user` DISABLE KEYS */;
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Allen-Cai','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('otto','123','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Luke-Li','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Boyao-Wang','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Otto-Lau','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Tracy-Liu','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Guo-Tuo','0000','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('Christal-Usiosefe','0000','1');
/*!40000 ALTER TABLE `ew_user` ENABLE KEYS */;


--
-- Create Table `transaction_view`
--

DROP VIEW IF EXISTS `transaction_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transaction_view` AS select `ew_transaction`.`tid` AS `tid`,`ew_transaction`.`user` AS `user`,`ew_transaction`.`barcode` AS `barcode`,(select `barcode_view`.`name` AS `name` from `barcode_view` where (`ew_transaction`.`barcode` = `barcode_view`.`barcode`)) AS `name`,`ew_transaction`.`type` AS `type`,`ew_transaction`.`quantity` AS `quantity`,`ew_transaction`.`time` AS `time` from `ew_transaction`;


SET FOREIGN_KEY_CHECKS=1;
-- EOB

