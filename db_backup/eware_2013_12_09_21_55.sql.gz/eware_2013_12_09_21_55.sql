-- Status:10:171:MP_0:eware:php:1.24.4::5.5.32:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|ew_admin|1|2068|2013-11-27 16:54:42|MyISAM
-- TABLE|ew_car|38|14324|2013-12-09 15:29:57|MyISAM
-- TABLE|ew_cart|0|1024|2013-12-09 15:29:57|MyISAM
-- TABLE|ew_log|1|2088|2013-12-05 11:16:20|MyISAM
-- TABLE|ew_message|24|7088|2013-12-04 10:17:21|MyISAM
-- TABLE|ew_part|31|13412|2013-12-09 15:29:57|MyISAM
-- TABLE|ew_pending|0|1024|2013-12-09 15:29:57|MyISAM
-- TABLE|ew_relation|0|1024|2013-12-09 15:29:57|MyISAM
-- TABLE|ew_transaction|72|4928|2013-12-09 15:29:57|MyISAM
-- TABLE|ew_user|4|2128|2013-11-27 16:56:55|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2013-12-09 21:55

--
-- Create Table `ew_admin`
--

DROP TABLE IF EXISTS `ew_admin`;
CREATE TABLE `ew_admin` (
  `user` varchar(40) CHARACTER SET utf8 NOT NULL,
  `pass` varchar(40) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_admin`
--

/*!40000 ALTER TABLE `ew_admin` DISABLE KEYS */;
INSERT INTO `ew_admin` (`user`,`pass`) VALUES ('admin','1');
/*!40000 ALTER TABLE `ew_admin` ENABLE KEYS */;


--
-- Create Table `ew_car`
--

DROP TABLE IF EXISTS `ew_car`;
CREATE TABLE `ew_car` (
  `barcode` varchar(20) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT 'Name of the car',
  `photo_url` varchar(200) DEFAULT 'upload\\default.jpg' COMMENT 'Photo URL',
  `model` varchar(40) NOT NULL COMMENT 'Model of the car',
  `vin` varchar(40) DEFAULT NULL,
  `year` int(10) NOT NULL DEFAULT '2013',
  `category` varchar(20) NOT NULL COMMENT 'Finished/Semi finished',
  `color` varchar(20) DEFAULT NULL COMMENT 'The color of product',
  `condition` varchar(20) NOT NULL COMMENT 'New, used, demo, damaged',
  `p_price` decimal(10,2) NOT NULL COMMENT 'Purchase price',
  `w_price` decimal(10,2) NOT NULL COMMENT 'Wholesale price',
  `r_price` decimal(10,2) NOT NULL COMMENT 'Retail price',
  `quantity` int(10) NOT NULL COMMENT 'Amount in stock',
  `w_quantity` int(10) NOT NULL COMMENT 'Warning if in stock less than this amount',
  `l_zone` varchar(20) DEFAULT NULL COMMENT 'Location zone',
  `l_column` varchar(20) DEFAULT NULL COMMENT 'Location column',
  `l_level` varchar(20) DEFAULT NULL COMMENT 'Location level',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Latest update date',
  `des` text COMMENT 'Description of item',
  `xsearch` text NOT NULL COMMENT 'name,barcode,model,category,color,location,condition',
  PRIMARY KEY (`barcode`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_car`
--

/*!40000 ALTER TABLE `ew_car` DISABLE KEYS */;
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849843167','KERNEL','upload/sample/kernel.jpg','EG6020X',NULL,'2013','finish','orange','new','0.00','10999.00','13999.00','1','5','n','1','1','2013-11-22 07:37:12','										','barcode:013849843167, name:kernel, model:eg6020x, category:finish, color:orange, location:n_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849843596','HULK','upload/sample/hulk.jpg','EG6020A4D',NULL,'2013','finish','camo','new','0.00','9850.00','12999.00','1','0','n','1','1','2013-11-20 16:55:14','','barcode:013849843596, name:hulk, model:eg6020a4d, category:finish, color:camo, location:n_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849844238','HOBBIT 4+2 Customize','upload/sample/hobbit4p2.jpg','EG2048KSZ',NULL,'2013','finish','blue','new','0.00','5750.00','7699.00','1','0','n','1','1','2013-11-21 11:46:07','No Cover','barcode:013849844238, name:hobbit 4+2 customize, model:eg2048ksz, category:finish, color:blue, location:n_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849845400','Motorcycle','upload/default.jpg','Customize','123','2013','finish','white','damaged','0.00','0.00','0.00','1','0','n','1','1','2013-11-25 11:22:25','no battery','barcode:013849845400, name:motorcycle, model:customize, category:finish, color:white, location:n_1_1, condition:damaged, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849846414','QUANTUM Customize','upload/sample/quantum.jpg','EG6043K01',NULL,'2013','finish','white','new','0.00','8499.00','10999.00','1','0','c','1','1','2013-11-22 06:27:55','This car is sealed.','barcode:013849846414, name:quantum customize, model:eg6043k01, category:finish, color:white, location:c_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849847336','Garbage Truck','upload/default.jpg','Customize',NULL,'2013','finish','green','new','0.00','0.00','0.00','1','0','c','1','1','2013-11-21 11:49:44','','barcode:013849847336, name:garbage truck, model:customize, category:finish, color:green, location:c_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848035','ARGO 14','upload/sample/argo14.jpg','EG6158K01',NULL,'2013','finish','black','new','0.00','13599.00','17999.00','1','0','c','1','1','2013-11-20 17:00:16','','barcode:013849848035, name:argo 14, model:eg6158k01, category:finish, color:black, location:c_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848309','ARGO 14','upload/sample/argo14.jpg','EG6158K01',NULL,'2013','finish','white','new','0.00','13599.00','17999.00','1','0','c','1','1','2013-11-20 17:00:44','','barcode:013849848309, name:argo 14, model:eg6158k01, category:finish, color:white, location:c_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849848727','HOBBIT 2+2 Ambulance','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','finish','red','new','0.00','4599.00','6199.00','1','0','c','2','1','2013-11-20 17:03:00','','barcode:013849848727, name:hobbit 2+2 ambulance, model:eg2028ksz01, category:finish, color:red, location:c_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849849042','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ',NULL,'2013','finish','red','new','0.00','6999.00','9150.00','1','0','c','2','1','2013-11-20 17:03:12','','barcode:013849849042, name:hobbit 6+2, model:eg2068ksz, category:finish, color:red, location:c_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849850219','HOBBIT 6+2','upload/sample/hobbit6p2.jpg','EG2068KSZ',NULL,'2013','finish','silver','demo','0.00','6999.00','9150.00','1','0','c','2','1','2013-11-20 17:04:15','','barcode:013849850219, name:hobbit 6+2, model:eg2068ksz, category:finish, color:silver, location:c_2_1, condition:demo');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849851104','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ',NULL,'2013','finish','green','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-11-20 17:05:20','','barcode:013849851104, name:hobbit 4+2, model:eg2048ksz, category:finish, color:green, location:c_3_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849851341','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ',NULL,'2013','finish','black','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-11-22 07:05:25','										','barcode:013849851341, name:hobbit 4+2, model:eg2048ksz, category:finish, color:black, location:c_3_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852101','RAMBLER','upload/1385396224190.jpg','EG2048ASZ','123','2013','finish','black','damaged','0.00','6199.00','8299.00','1','0','c','4','1','2013-11-25 11:17:04','','barcode:013849852101, name:rambler, model:eg2048asz, category:finish, color:black, location:c_4_1, condition:damaged, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852326','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','semi','silver','new','0.00','5950.00','7499.00','1','0','c','4','1','2013-11-20 17:08:14','','barcode:013849852326, name:nomad, model:eg2020asz, category:semi, color:silver, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849852676','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','semi','gold','new','0.00','5950.00','7499.00','1','0','c','4','1','2013-11-20 17:08:04','','barcode:013849852676, name:nomad, model:eg2020asz, category:semi, color:gold, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849853196','CRICKET 2','upload/sample/cricket2.jpg','EG2028K',NULL,'2013','semi','white','demo','0.00','4299.00','5799.00','1','0','c','5','1','2013-11-20 17:09:12','','barcode:013849853196, name:cricket 2, model:eg2028k, category:semi, color:white, location:c_5_1, condition:demo');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849853756','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','semi','black','new','0.00','4599.00','6199.00','1','0','s','1','1','2013-11-20 17:10:01','','barcode:013849853756, name:hobbit 2+2, model:eg2028ksz01, category:semi, color:black, location:s_1_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849854322','HOBBIT 4+2','upload/1384986489670.jpg','EG2048KSZ',NULL,'2013','finish','black','new','0.00','5750.00','7699.00','1','0','s','2','1','2013-11-20 17:28:09','','barcode:013849854322, name:hobbit 4+2, model:eg2048ksz, category:finish, color:black, location:s_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849854684','QUANTUM Customize','upload/sample/quantum.jpg','EG6043K01',NULL,'2013','finish','white','new','0.00','8499.00','10999.00','1','0','s','2','1','2013-11-22 04:36:53','This car has a cargo box~','barcode:013849854684, name:quantum customize, model:eg6043k01, category:finish, color:white, location:s_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849855695','CRICKET 2','upload/sample/cricket2.jpg','EG2028K',NULL,'2013','semi','green','used','0.00','4299.00','5799.00','1','0','e','6','1','2013-11-20 17:13:07','','barcode:013849855695, name:cricket 2, model:eg2028k, category:semi, color:green, location:e_6_1, condition:used');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856001','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','finish','black','new','0.00','5950.00','7499.00','1','0','e','5','1','2013-11-21 10:00:06','','barcode:013849856001, name:nomad, model:eg2020asz, category:finish, color:black, location:e_5_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856394','CRICKET 2','upload/sample/cricket2.jpg','EG2028K',NULL,'2013','finish','red','new','0.00','4299.00','5799.00','1','0','e','5','1','2013-11-20 17:14:09','','barcode:013849856394, name:cricket 2, model:eg2028k, category:finish, color:red, location:e_5_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856577','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','finish','black','new','0.00','5950.00','7499.00','1','0','c','5','1','2013-11-20 17:14:32','','barcode:013849856577, name:nomad, model:eg2020asz, category:finish, color:black, location:c_5_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849856801','NUCLEUS','upload/sample/nucleus.jpg','EG6021H',NULL,'2013','finish','orange','new','0.00','7199.00','9599.00','1','0','c','4','1','2013-11-20 17:14:51','','barcode:013849856801, name:nucleus, model:eg6021h, category:finish, color:orange, location:c_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857035','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','finish','black','new','0.00','4599.00','6199.00','1','0','e','4','1','2013-11-20 17:15:23','','barcode:013849857035, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:e_4_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857340','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','finish','red','new','0.00','4599.00','6199.00','1','0','c','3','1','2013-11-20 17:15:57','','barcode:013849857340, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:red, location:c_3_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857778','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ',NULL,'2013','finish','green','new','0.00','5750.00','7699.00','1','0','c','3','1','2013-11-20 17:16:30','','barcode:013849857778, name:hobbit 4+2, model:eg2048ksz, category:finish, color:green, location:c_3_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849857969','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','finish','green','new','0.00','4599.00','6199.00','1','0','c','3','1','2013-11-20 17:16:53','','barcode:013849857969, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:green, location:c_3_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858260','NOMAD','upload/sample/nomad.jpg','EG2020ASZ',NULL,'2013','finish','red','new','0.00','5950.00','7499.00','1','0','c','2','1','2013-11-20 17:17:15','','barcode:013849858260, name:nomad, model:eg2020asz, category:finish, color:red, location:c_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858479','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','finish','blue','damaged','0.00','4599.00','6199.00','1','0','e','2','1','2013-11-20 17:17:48','','barcode:013849858479, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:blue, location:e_2_1, condition:damaged');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849858782','RAMBLER','upload/sample/rambler.jpg','EG2048ASZ',NULL,'2013','finish','silver','new','0.00','6199.00','8299.00','1','0','e','2','1','2013-11-20 17:18:15','','barcode:013849858782, name:rambler, model:eg2048asz, category:finish, color:silver, location:e_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859041','RAMBLER','upload/sample/rambler.jpg','EG2048ASZ',NULL,'2013','finish','blue','new','0.00','6199.00','8299.00','1','0','c','2','1','2013-11-20 17:18:32','','barcode:013849859041, name:rambler, model:eg2048asz, category:finish, color:blue, location:c_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859323','HOBBIT 2+2','upload/sample/hobbit2p2.jpg','EG2028KSZ01',NULL,'2013','finish','black','new','0.00','4599.00','6199.00','1','0','c','2','1','2013-11-24 03:42:44','','barcode:013849859323, name:hobbit 2+2, model:eg2028ksz01, category:finish, color:black, location:c_2_1, condition:new');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859659','RAMBLER','upload/sample/rambler.jpg','EG2048ASZ','321','2013','semi','black','new','0.00','6199.00','8299.00','1','0','c','4','1','2013-11-28 09:43:20','','barcode:013849859659, name:rambler, model:eg2048asz, category:semi, color:black, location:c_4_1, condition:new, year:2013, vin:321');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013849859999','HOBBIT 4+2','upload/sample/hobbit4p2.jpg','EG2048KSZ','123','2013','semi','silver','new','0.00','5750.00','7699.00','1','0','c','4','1','2013-11-28 09:42:37','','barcode:013849859999, name:hobbit 4+2, model:eg2048ksz, category:semi, color:silver, location:c_4_1, condition:new, year:2013, vin:123');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013853546558','ARGO 11','upload/sample/argo11.jpg','EG6118KA','3C3CFFAR1DT546508','2013','finish','black','new','0.00','12299.00','15599.00','0','0','c','1','1','2013-11-25 10:44:00','Assembly by otto;','barcode:013853546558, name:argo 11, model:eg6118ka, category:finish, color:black, location:c_1_1, condition:new, year:2013, vin:3c3cffar1dt546508');
INSERT INTO `ew_car` (`barcode`,`name`,`photo_url`,`model`,`vin`,`year`,`category`,`color`,`condition`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('013859994784','HOBBIT 2HCX','upload/sample/hobbit2hcx.jpg','EG2048HCX','undefine','2013','finish','White','new','0.00','5850.00','7899.00','1','0','c','1','1','2013-12-04 12:08:32','Serial Number: 13080079\r\nController Number: 12261P060690','barcode:013859994784, name:hobbit 2hcx, model:eg2048hcx, category:finish, color:white, location:c_1_1, condition:new, year:2013, vin:undefine');
/*!40000 ALTER TABLE `ew_car` ENABLE KEYS */;


--
-- Create Table `ew_cart`
--

DROP TABLE IF EXISTS `ew_cart`;
CREATE TABLE `ew_cart` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user` varchar(20) CHARACTER SET utf8 NOT NULL,
  `table` varchar(20) CHARACTER SET utf8 NOT NULL,
  `quantity` int(10) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_cart`
--

/*!40000 ALTER TABLE `ew_cart` DISABLE KEYS */;
/*!40000 ALTER TABLE `ew_cart` ENABLE KEYS */;


--
-- Create Table `ew_log`
--

DROP TABLE IF EXISTS `ew_log`;
CREATE TABLE `ew_log` (
  `log_id` int(20) NOT NULL AUTO_INCREMENT,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Log time',
  `user` varchar(20) NOT NULL COMMENT 'Who made this transaction',
  `msg` tinytext NOT NULL COMMENT 'Log message',
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_log`
--

/*!40000 ALTER TABLE `ew_log` DISABLE KEYS */;
INSERT INTO `ew_log` (`log_id`,`time`,`user`,`msg`) VALUES ('1','2013-12-05 11:16:17','otto','login to the system.');
/*!40000 ALTER TABLE `ew_log` ENABLE KEYS */;


--
-- Create Table `ew_message`
--

DROP TABLE IF EXISTS `ew_message`;
CREATE TABLE `ew_message` (
  `mid` int(10) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `path` varchar(40) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_message`
--

/*!40000 ALTER TABLE `ew_message` DISABLE KEYS */;
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('69','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855784845,225115B12 Journey with Aluminum Rim,-16,75.00,0.00<br>','2013-11-27 16:01:59','upload/1385586119250.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('68','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113855773834,21x11-10 CST with Aluminum Rim R,28,0.00,0.00<br>113855777806,25x8-12 ATX78 WAN DA with Aluminum Rim,8,0.00,0.00<br>113855780864,155R12C KENDA with Steel Rim,4,0.00,0.00<br>113855768358,21x11-10 CST with Aluminum Rim F,28,0.00,0.00<br>113855784845,225115B12 Journey with Aluminum Rim,16,0.00,0.00<br>113855786227,205150-10 KENDA with Aluminum Rimg,8,0.00,0.00<br>113855787534,Flip-Flop Seat Kit,36,0.00,0.00<br>113855789397,2028 Foldable Windshield,76,0.00,0.00<br>113855795797,2020 Foldable Windshield,22,0.00,0.00<br>','2013-11-27 15:57:30','upload/1385585850600.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('70','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113853459109,Accelerator,10,4.00,8.00<br>','2013-11-28 09:32:30','upload/1385649150797.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('71','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113853451924,Motor 38KW 48V,4,2.00,3.00<br>113853457811,Motor Screw Set,4,2.00,3.00<br>','2013-11-28 09:35:55','upload/1385649355641.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('72','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113853459109,Accelerator,-3,4.00,8.00<br>113853451924,Motor 38KW 48V,-3,2.00,3.00<br>113853457811,Motor Screw Set,-3,2.00,3.00<br>','2013-11-28 09:56:23','upload/1385650583297.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('73','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113853459109,Accelerator,-3,4.00,8.00<br>','2013-11-28 09:57:19','upload/1385650639141.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('74','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113853459109,Accelerator,1,4.00,8.00<br>113853457811,Motor Screw Set,26,2.00,3.00<br>','2013-11-28 10:04:58','upload/1385651098188.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('75','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113853459109,Accelerator,10,4.00,8.00<br>113853451924,Motor 38KW 48V,10,2.00,3.00<br>113853457811,Motor Screw Set,5,2.00,3.00<br>','2013-11-28 13:42:54','upload/1385664174891.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('76','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856688278,Left Half Axle,0,0.00,0.00<br>113856688951,Right Half Axle,0,0.00,0.00<br>','2013-11-28 15:03:08','upload/1385668988094.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('77','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856688278,Left Half Axle,47,0.00,0.00<br>','2013-11-28 15:30:27','upload/1385670627344.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('78','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856688951,Right Half Axle,50,0.00,0.00<br>','2013-11-28 15:30:51','upload/1385670651188.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('79','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856717210,1400x1100x250 Carbon Steel Cargo Box- Manual Dump,5,0.00,0.00<br>','2013-11-28 15:52:46','upload/1385671966594.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('80','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856724550,1400x1100x250 Aluminum Cargo Box- Manual Dump,2,0.00,0.00<br>113856726379,1000x1100x250 Carbon Steel Cargo Box - Non Standard,2,0.00,0.00<br>113856726477,1000x1100x250 Aluminum Cargo Box - Non Standard,2,0.00,0.00<br>','2013-11-28 16:04:53','upload/1385672693938.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('81','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856730198,770x1100x250 Aluminium Cargo Box- Standard,2,0.00,0.00<br>113856732204,770x1100x250 Carbon Steel Cargo Box- Standard,4,0.00,0.00<br>','2013-11-28 16:14:25','upload/1385673265406.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('82','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113856750152,Rear Cover - Metallic Green - Used,2,0.00,0.00<br>113856751451,Rear Cover - Pure Black - Used,3,0.00,0.00<br>113856751895,Rear Cover - Camouflage - Used,1,0.00,0.00<br>','2013-11-28 16:47:50','upload/1385675270391.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('83','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>013859994784,HOBBIT 2HCX,1,5850.00,7899.00<br>113860002295,Front Cover - Metallic Green - Used,2,0.00,0.00<br>113860005355,Front Cover - Pure Black - Used,1,0.00,0.00<br>113860007132,Front Cover - Pure Black - Used,2,0.00,0.00<br>113860007207,Front Cover - Camouflage,1,0.00,0.00<br>113860008361,Central Cover - camouflage - used,1,0.00,0.00<br>','2013-12-02 11:19:21','upload/1386001161953.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('84','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113860136683,Seat Back Cushion,22,0.00,0.00<br>','2013-12-02 14:48:57','upload/1386013737313.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('85','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113860146106,Seat Cushion,24,0.00,0.00<br>','2013-12-02 15:04:23','upload/1386014663250.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('86','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113861020767,123,0,0.00,0.00<br>','2013-12-03 15:21:52','upload/1386102112912.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('87','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113861020767,Drivers Seat,4,0.00,0.00<br>','2013-12-03 15:29:10','upload/1386102550178.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('88','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113861020003,Passenger Seat,4,0.00,0.00<br>','2013-12-03 15:31:15','upload/1386102675241.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('89','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113861036513,Assembly of Cushion,23,0.00,0.00<br>113860146106,Seat Cushion,-13,0.00,0.00<br>','2013-12-03 15:49:19','upload/1386103759006.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('90','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113860146106,Seat Cushion,13,0.00,0.00<br>113861036513,Assembly of Cushion,-13,0.00,0.00<br>','2013-12-03 16:05:23','upload/1386104723569.csv');
INSERT INTO `ew_message` (`mid`,`user`,`message`,`time`,`path`) VALUES ('91','otto','Barcode,Name,Amount,Dealer Price,Retail Price<br>113861699105,Front Axle Assemblyï¼ˆå‰æ¡¥æ€»æˆï¼‰,0,0.00,0.00<br>113855787534,Flip-Flop Seat Kit,3,0.00,0.00<br>','2013-12-04 10:17:17','upload/1386170237615.csv');
/*!40000 ALTER TABLE `ew_message` ENABLE KEYS */;


--
-- Create Table `ew_part`
--

DROP TABLE IF EXISTS `ew_part`;
CREATE TABLE `ew_part` (
  `barcode` varchar(20) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL COMMENT 'Name of the part',
  `photo_url` tinytext COMMENT 'Photo URL',
  `part_num` varchar(20) NOT NULL COMMENT 'Part number of the part',
  `category` varchar(20) NOT NULL COMMENT 'Body, Accessory, Tire and Rim, Mechanical, Electrical',
  `sub_category` varchar(20) NOT NULL COMMENT 'Universal, Club car, EZGO, AGT, Yamaha',
  `color` varchar(20) DEFAULT NULL COMMENT 'The color of product',
  `p_price` decimal(10,2) NOT NULL COMMENT 'Purchase price',
  `w_price` decimal(10,2) NOT NULL COMMENT 'Wholesale price',
  `r_price` decimal(10,2) NOT NULL COMMENT 'Retail price',
  `quantity` int(10) NOT NULL COMMENT 'Amount in stock',
  `w_quantity` int(10) NOT NULL COMMENT 'Warning if in stock less than this amount',
  `l_zone` varchar(20) DEFAULT NULL COMMENT 'Location zone',
  `l_column` varchar(20) DEFAULT NULL COMMENT 'Location column',
  `l_level` varchar(20) DEFAULT NULL COMMENT 'Location level',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Latest update date',
  `des` text NOT NULL COMMENT 'Description of item',
  `xsearch` text NOT NULL COMMENT 'Name,part_num,category,sub_category,color,location',
  PRIMARY KEY (`barcode`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_part`
--

/*!40000 ALTER TABLE `ew_part` DISABLE KEYS */;
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855780864','155R12C KENDA with Steel Rim','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','4','0','w','1','1','2013-11-27 15:57:30','','barcode:113855780864, name:155r12c kenda with steel rim, model:, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855777806','25x8-12 ATX78 WAN DA with Aluminum Rim','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','8','0','w','1','1','2013-11-27 15:57:30','','barcode:113855777806, name:25x8-12 atx78 wan da with aluminum rim, model:, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855773834','21x11-10 CST with Aluminum Rim R','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','28','0','w','1','1','2013-11-27 15:57:30','','barcode:113855773834, name:21x11-10 cst with aluminum rim r, model:, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855768358','21x11-10 CST with Aluminum Rim F','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','28','0','w','1','1','2013-11-27 15:57:30','','barcode:113855768358, name:21x11-10 cst with aluminum rim f, model:, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855784845','225115B12 Journey with Aluminum Rim','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','75.00','0.00','0','5','w','1','1','2013-11-28 09:55:11','','barcode:113855784845, name:225115b12 journey with aluminum rim, model:, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855786227','205150-10 KENDA with Aluminum Rimg','upload/default.jpg','PKG','tire_and_rim','AGT','default','0.00','0.00','0.00','8','0','w','1','1','2013-11-27 15:57:30','','barcode:113855786227, name:205150-10 kenda with aluminum rimg, model:, category:tire_and_rim, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855787534','Flip-Flop Seat Kit','upload/default.jpg','PKG','body','AGT','default','0.00','0.00','0.00','39','0','w','1','1','2013-12-04 10:17:17','','barcode:113855787534, name:flip-flop seat kit, model:, category:body, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855789397','2028 Foldable Windshield','upload/default.jpg','PKG','body','AGT','default','0.00','0.00','0.00','76','0','w','1','1','2013-11-27 15:57:30','','barcode:113855789397, name:2028 foldable windshield, model:, category:body, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113855795797','2020 Foldable Windshield','upload/default.jpg','PKG','body','AGT','default','0.00','0.00','0.00','22','0','w','1','1','2013-11-27 15:57:30','','barcode:113855795797, name:2020 foldable windshield, model:, category:body, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856688278','Left Half Axle','upload/default.jpg','2402100-008','mechanical','AGT','default','0.00','0.00','0.00','47','0','w','1','1','2013-11-28 15:30:27','','barcode:113856688278, name:left half axle, model:, category:mechanical, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856688951','Right Half Axle','upload/default.jpg','2402200-008','mechanical','AGT','default','0.00','0.00','0.00','50','0','w','1','1','2013-11-28 15:30:51','','barcode:113856688951, name:right half axle, model:, category:mechanical, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856717210','1400x1100x250 Carbon Steel Cargo Box- Manual Dump','upload/default.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','5','0','w','1','1','2013-11-28 15:52:46','','barcode:113856717210, name:1400x1100x250 carbon steel cargo box- manual dump, model:, category:accessory, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856724550','1400x1100x250 Aluminum Cargo Box- Manual Dump','upload/default.jpg','PKG','body','AGT','default','0.00','0.00','0.00','2','0','w','1','1','2013-11-28 16:04:53','','barcode:113856724550, name:1400x1100x250 aluminum cargo box- manual dump, model:, category:body, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856726379','1000x1100x250 Carbon Steel Cargo Box - Non Standard','upload/default.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','2','0','w','1','1','2013-11-28 16:04:53','','barcode:113856726379, name:1000x1100x250 carbon steel cargo box - non standard, model:, category:accessory, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856726477','1000x1100x250 Aluminum Cargo Box - Non Standard','upload/default.jpg','PKG','body','AGT','default','0.00','0.00','0.00','2','0','w','1','1','2013-11-28 16:04:53','','barcode:113856726477, name:1000x1100x250 aluminum cargo box - non standard, model:, category:body, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856730198','770x1100x250 Aluminum Cargo Box- Standard','upload/default.jpg','PKG','accessory','UNKNOW','default','0.00','0.00','0.00','2','0','w','1','1','2013-11-28 16:19:08','','barcode:113856730198, name:770x1100x250 aluminum cargo box- standard, model:, category:accessory, sub category:unknow, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856732204','770x1100x250 Carbon Steel Cargo Box- Standard','upload/default.jpg','PKG','accessory','AGT','default','0.00','0.00','0.00','4','0','w','1','1','2013-11-28 16:14:25','','barcode:113856732204, name:770x1100x250 carbon steel cargo box- standard, model:, category:accessory, sub category:agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856750152','Rear Cover - Metallic Green - Used','upload/default.jpg','5402010-036-A1','body','EZGO,AGT','default','0.00','0.00','0.00','2','0','w','1','1','2013-11-28 16:47:50','','barcode:113856750152, name:rear cover - metallic green - used, model:, category:body, sub category:ezgo,agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856751451','Rear Cover - Pure Black - Used','upload/default.jpg','5402010-036-A4','body','EZGO,AGT','default','0.00','0.00','0.00','3','0','w','1','1','2013-11-28 16:47:50','','barcode:113856751451, name:rear cover - pure black - used, model:, category:body, sub category:ezgo,agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113856751895','Rear Cover - Camouflage - Used','upload/default.jpg','23456543','body','EZGO,AGT','default','0.00','0.00','0.00','1','0','w','1','1','2013-11-28 16:47:50','','barcode:113856751895, name:rear cover - camouflage - used, model:, category:body, sub category:ezgo,agt, color:default, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860002295','Front Cover - Metallic Green - Used','upload/default.jpg','5302010-036-A1','body','AGT','Metallic Green','0.00','0.00','0.00','2','0','w','1','1','2013-12-02 11:19:21','EG2028 Series','barcode:113860002295, name:front cover - metallic green - used, model:, category:body, sub category:agt, color:metallic green, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860005355','Front Cover - Pure Black - Used','upload/default.jpg','5302010-036-A4','body','AGT','Pure Black','0.00','0.00','0.00','1','0','w','1','1','2013-12-02 11:19:21','EG2028 Series','barcode:113860005355, name:front cover - pure black - used, model:, category:body, sub category:agt, color:pure black, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860007132','Front Cover - Pure Black - Used','upload/default.jpg','5302010-048','body','AGT','Pure Black','0.00','0.00','0.00','2','0','w','1','1','2013-12-02 11:19:21','EG2020 Series','barcode:113860007132, name:front cover - pure black - used, model:, category:body, sub category:agt, color:pure black, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860007207','Front Cover - Camouflage - Used','upload/default.jpg','3040-5202001-114','body','UNKNOW','camouflage','0.00','0.00','0.00','1','0','w','1','1','2013-12-02 11:22:48','','barcode:113860007207, name:front cover - camouflage - used, model:, category:body, sub category:unknow, color:camouflage, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860008361','Central Cover - camouflage - used','upload/default.jpg','undefined','body','UNKNOW','camouflage','0.00','0.00','0.00','1','0','w','1','1','2013-12-02 11:19:21','','barcode:113860008361, name:central cover - camouflage - used, model:, category:body, sub category:unknow, color:camouflage, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860136683','Seat Back Cushion','upload/default.jpg','7106100-036','body','AGT','Tan','0.00','0.00','0.00','22','0','w','1','1','2013-12-02 14:48:57','','barcode:113860136683, name:seat back cushion, model:, category:body, sub category:agt, color:tan, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113860146106','Seat Cushion','upload/default.jpg','7101100-036','body','AGT','Tan','0.00','0.00','0.00','24','0','w','1','1','2013-12-03 16:05:23','EG2028','barcode:113860146106, name:seat cushion, model:, category:body, sub category:agt, color:tan, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861020003','Passenger Seat','upload/default.jpg','7149000-014','body','AGT','Grey','0.00','0.00','0.00','4','0','w','1','1','2013-12-03 15:31:15','Eg6158','barcode:113861020003, name:passenger seat, model:, category:body, sub category:agt, color:grey, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861020767','Drivers Seat','upload/default.jpg','7101000-014','body','AGT','Grey','0.00','0.00','0.00','4','0','w','1','1','2013-12-03 15:29:10','','barcode:113861020767, name:drivers seat, model:, category:body, sub category:agt, color:grey, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861036513','Assembly of Cushion','upload/default.jpg','7101100-040','body','AGT','Tan','0.00','0.00','0.00','10','0','w','1','1','2013-12-03 16:05:23','First Row Seat','barcode:113861036513, name:assembly of cushion, model:, category:body, sub category:agt, color:tan, location:w_1_1');
INSERT INTO `ew_part` (`barcode`,`name`,`photo_url`,`part_num`,`category`,`sub_category`,`color`,`p_price`,`w_price`,`r_price`,`quantity`,`w_quantity`,`l_zone`,`l_column`,`l_level`,`date`,`des`,`xsearch`) VALUES ('113861699105','Front Axle Assemblyï¼ˆå‰æ¡¥æ€»æˆï¼‰','upload/default.jpg','PKG','mechanical','AGT','default','0.00','0.00','0.00','0','0','w','1','1','2013-12-04 10:12:33','Completed front axle assembly','barcode:113861699105, name:front axle assemblyï¼ˆå‰æ¡¥æ€»æˆï¼‰, model:, category:mechanical, sub category:agt, color:default, location:w_1_1');
/*!40000 ALTER TABLE `ew_part` ENABLE KEYS */;


--
-- Create Table `ew_pending`
--

DROP TABLE IF EXISTS `ew_pending`;
CREATE TABLE `ew_pending` (
  `pid` int(10) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user` varchar(20) CHARACTER SET utf8 NOT NULL,
  `client` varchar(40) CHARACTER SET utf8 NOT NULL,
  `quantity` int(10) NOT NULL,
  `table` varchar(20) CHARACTER SET utf8 NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_pending`
--

/*!40000 ALTER TABLE `ew_pending` DISABLE KEYS */;
/*!40000 ALTER TABLE `ew_pending` ENABLE KEYS */;


--
-- Create Table `ew_relation`
--

DROP TABLE IF EXISTS `ew_relation`;
CREATE TABLE `ew_relation` (
  `rid` int(20) NOT NULL AUTO_INCREMENT,
  `main_part` varchar(20) CHARACTER SET utf8 NOT NULL,
  `attach_part` varchar(20) CHARACTER SET utf8 NOT NULL,
  `amount` int(20) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_relation`
--

/*!40000 ALTER TABLE `ew_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ew_relation` ENABLE KEYS */;


--
-- Create Table `ew_transaction`
--

DROP TABLE IF EXISTS `ew_transaction`;
CREATE TABLE `ew_transaction` (
  `tid` int(20) NOT NULL AUTO_INCREMENT COMMENT 'unique transection id',
  `user` varchar(20) NOT NULL COMMENT 'Who made this transection',
  `barcode` varchar(20) NOT NULL COMMENT 'UPC-A 12 digits barcode',
  `type` varchar(20) NOT NULL COMMENT 'Enter, pending, depart',
  `quantity` int(10) NOT NULL COMMENT 'Amount of items being trans',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Transaction time stamp',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM AUTO_INCREMENT=475 DEFAULT CHARSET=utf8;

--
-- Data for Table `ew_transaction`
--

/*!40000 ALTER TABLE `ew_transaction` DISABLE KEYS */;
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('1','san','013849843167','car','1','2013-11-20 21:52:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('2','san','013849843596','car','1','2013-11-20 21:52:54');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('3','san','013849844238','car','1','2013-11-20 21:54:40');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('4','san','013849845400','car','1','2013-11-20 21:56:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('5','san','013849846414','car','1','2013-11-20 21:57:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('6','san','013849847336','car','1','2013-11-20 21:59:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('7','san','013849848035','car','1','2013-11-20 22:00:16');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('8','san','013849848309','car','1','2013-11-20 22:00:44');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('9','san','013849848727','car','1','2013-11-20 22:01:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('10','san','013849849042','car','1','2013-11-20 22:01:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('11','san','013849850219','car','1','2013-11-20 22:03:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('12','san','013849851104','car','1','2013-11-20 22:05:20');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('13','san','013849851341','car','1','2013-11-20 22:06:05');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('14','san','013849852101','car','1','2013-11-20 22:07:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('15','san','013849852326','car','1','2013-11-20 22:07:37');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('16','san','013849852676','car','1','2013-11-20 22:08:04');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('17','san','013849853196','car','1','2013-11-20 22:08:58');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('18','san','013849853756','car','1','2013-11-20 22:10:01');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('19','san','013849854322','car','1','2013-11-20 22:10:52');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('20','san','013849854684','car','1','2013-11-20 22:11:34');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('21','san','013849855695','car','1','2013-11-20 22:13:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('22','san','013849856001','car','1','2013-11-20 22:13:49');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('23','san','013849856394','car','1','2013-11-20 22:14:09');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('24','san','013849856577','car','1','2013-11-20 22:14:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('25','san','013849856801','car','1','2013-11-20 22:14:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('26','san','013849857035','car','1','2013-11-20 22:15:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('27','san','013849857340','car','1','2013-11-20 22:15:57');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('28','san','013849857778','car','1','2013-11-20 22:16:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('29','san','013849857969','car','1','2013-11-20 22:16:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('30','san','013849858260','car','1','2013-11-20 22:17:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('31','san','013849858479','car','1','2013-11-20 22:17:48');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('32','san','013849858782','car','1','2013-11-20 22:18:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('33','san','013849859041','car','1','2013-11-20 22:18:32');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('34','san','013849859323','car','1','2013-11-20 22:19:07');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('35','san','013849859659','car','1','2013-11-20 22:19:45');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('36','san','013849859999','car','1','2013-11-20 22:20:14');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('430','otto','113855786227','part','8','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('429','otto','113855784845','part','16','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('428','otto','113855773834','part','28','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('427','otto','113855777806','part','8','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('426','otto','113855780864','part','4','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('425','otto','113855768358','part','28','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('431','otto','113855787534','part','36','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('432','otto','113855789397','part','76','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('433','otto','113855795797','part','22','2013-11-27 15:57:30');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('434','otto','113855784845','part','-16','2013-11-27 16:01:59');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('446','otto','113856688278','part','47','2013-11-28 15:30:27');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('447','otto','113856688951','part','50','2013-11-28 15:30:51');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('448','otto','113856717210','part','5','2013-11-28 15:52:46');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('449','otto','113856726477','part','2','2013-11-28 16:04:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('450','otto','113856726379','part','2','2013-11-28 16:04:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('451','otto','113856724550','part','2','2013-11-28 16:04:53');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('452','otto','113856732204','part','4','2013-11-28 16:14:25');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('453','otto','113856730198','part','2','2013-11-28 16:14:25');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('454','otto','113856751895','part','1','2013-11-28 16:47:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('455','otto','113856751451','part','3','2013-11-28 16:47:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('456','otto','113856750152','part','2','2013-11-28 16:47:50');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('457','otto','013859994784','car','1','2013-12-02 10:54:10');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('458','otto','113860005355','part','1','2013-12-02 11:19:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('459','otto','113860002295','part','2','2013-12-02 11:19:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('461','otto','113860007132','part','2','2013-12-02 11:19:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('462','otto','113860007207','part','1','2013-12-02 11:19:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('463','otto','113860008361','part','1','2013-12-02 11:19:21');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('464','otto','113860136683','part','22','2013-12-02 14:48:57');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('465','otto','113860146106','part','24','2013-12-02 15:04:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('467','otto','113861020767','part','4','2013-12-03 15:29:10');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('468','otto','113861020003','part','4','2013-12-03 15:31:15');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('469','otto','113860146106','part','-13','2013-12-03 15:49:19');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('470','otto','113861036513','part','23','2013-12-03 15:49:19');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('471','otto','113861036513','part','-13','2013-12-03 16:05:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('472','otto','113860146106','part','13','2013-12-03 16:05:23');
INSERT INTO `ew_transaction` (`tid`,`user`,`barcode`,`type`,`quantity`,`time`) VALUES ('473','otto','113855787534','part','3','2013-12-04 10:17:17');
/*!40000 ALTER TABLE `ew_transaction` ENABLE KEYS */;


--
-- Create Table `ew_user`
--

DROP TABLE IF EXISTS `ew_user`;
CREATE TABLE `ew_user` (
  `user` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'User name',
  `pass` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT 'Password',
  `type` int(1) NOT NULL COMMENT '0. admin, 1.superuser, 2.user',
  PRIMARY KEY (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Data for Table `ew_user`
--

/*!40000 ALTER TABLE `ew_user` DISABLE KEYS */;
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('san','san','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('si','si','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('otto','123','1');
INSERT INTO `ew_user` (`user`,`pass`,`type`) VALUES ('test','123','1');
/*!40000 ALTER TABLE `ew_user` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

