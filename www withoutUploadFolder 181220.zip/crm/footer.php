<?PHP
/*
* Copyright © 2013 Elaine Relation
* File: footer.php
* Page Footer
*/
?>
    <div id="footer">
    
        Copyright © 2013 Elaine Relations Lite | Customized for <a href="http://www.agtecars.com" target="_blank">AGT Electric Cars</a>
        
	</div>
</div> <!-- end of wrapper -->


</body>
</html>

