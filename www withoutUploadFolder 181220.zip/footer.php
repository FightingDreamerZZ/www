<?PHP
/*
* Copyright © 2013 Elaine Warehouse
* File: footer.php
* Page Footer
*/
?>
    <div id="footer">
    
        Copyright © 2013 Elaine Warehouse 1.90 | Customized for <a href="http://www.agtecars.com" target="_blank">AGT Electric Cars</a>
        
	</div>
</div> <!-- end of wrapper -->


</body>
</html>