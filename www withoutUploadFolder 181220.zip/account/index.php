<?PHP
/*
* Copyright © 2013 Elaine CRM
* File: index.php
* This file display a user panel to access all frequently used functions.
*/
error_reporting(E_ALL ^ E_NOTICE);
//include('lib/sql.php');
//include('lib/user_lib.php');

print_r($_COOKIE);


//include('header.php');
?>

<p>Elaine Account Lite - Comming soon</p>
<?PHP
//include('footer.php');
?>