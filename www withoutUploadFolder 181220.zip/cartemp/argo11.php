<?PHP
$defaultset = array(
'name' => "ARGO 11",
'model' => "EG6118KA",
'pprice' => "0",
'wprice' => "12299",
'rprice' => "15599",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/argo11.jpg",
);
?>
