<?PHP
$defaultset = array(
'name' => "ARGO 14",
'model' => "EG6158K01",
'pprice' => "0",
'wprice' => "13599",
'rprice' => "17999",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/argo14.jpg",
);
?>
