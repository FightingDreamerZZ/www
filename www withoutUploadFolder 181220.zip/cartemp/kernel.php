<?PHP
$defaultset = array(
'name' => "KERNEL",
'model' => "EG6020X",
'pprice' => "0",
'wprice' => "10999",
'rprice' => "13999",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/kernel.jpg",
);
?>
