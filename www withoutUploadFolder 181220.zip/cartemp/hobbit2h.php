<?PHP
$defaultset = array(
'name' => "HOBBIT 2H",
'model' => "EG2028H",
'pprice' => "0",
'wprice' => "6999",
'rprice' => "5199",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hobbit2h.jpg",
);
?>
