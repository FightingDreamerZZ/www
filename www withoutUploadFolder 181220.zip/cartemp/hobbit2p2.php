<?PHP
$defaultset = array(
'name' => "HOBBIT 2+2",
'model' => "EG2028KSZ01",
'pprice' => "0",
'wprice' => "4599",
'rprice' => "6199",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hobbit2p2.jpg",
);
?>
