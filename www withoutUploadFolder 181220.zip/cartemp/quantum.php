<?PHP
$defaultset = array(
'name' => "QUANTUM",
'model' => "EG6043K01",
'pprice' => "0",
'wprice' => "8499",
'rprice' => "10999",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/quantum.jpg",
);
?>
