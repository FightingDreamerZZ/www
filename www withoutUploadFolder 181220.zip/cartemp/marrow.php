<?PHP
$defaultset = array(
'name' => "MARROW",
'model' => "EG6032H",
'pprice' => "0",
'wprice' => "19599",
'rprice' => "16599",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/marrow.jpg",
);
?>
