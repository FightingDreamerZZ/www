<?PHP
$defaultset = array(
'name' => "CRICKET 2",
'model' => "EG2028K",
'pprice' => "0",
'wprice' => "4299",
'rprice' => "5799",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/cricket2.jpg",
);
?>
