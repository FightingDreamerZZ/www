<?PHP
$defaultset = array(
'name' => "NUCLEUS",
'model' => "EG6021H",
'pprice' => "0",
'wprice' => "7199",
'rprice' => "9599",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/nucleus.jpg",
);
?>
