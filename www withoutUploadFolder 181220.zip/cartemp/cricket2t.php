<?PHP
$defaultset = array(
'name' => "CRICKET 2T",
'model' => "EG2028T",
'pprice' => "0",
'wprice' => "6999",
'rprice' => "5399",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/cricket2t.jpg",
);
?>
