<?PHP
$defaultset = array(
'name' => "enter_name",
'model' => "enter_model",
'pprice' => "enter_purchase",
'wprice' => "enter_dealerprice",
'rprice' => "enter_retailprice",
'lzone' => "enter_location_zone",
'lcolumn' => "enter_location_column",
'llevel' => "enter_location_level",
'photo' => "enter_photo_path",
);
?>
