<?PHP
$defaultset = array(
'name' => "HOBBIT 6+2",
'model' => "EG2068KSZ",
'pprice' => "0",
'wprice' => "6999",
'rprice' => "9150",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hobbit6p2.jpg",
);
?>
