<?PHP
$defaultset = array(
'name' => "HULK",
'model' => "EG6020A4D",
'pprice' => "0",
'wprice' => "9850",
'rprice' => "12999",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hulk.jpg",
);
?>
