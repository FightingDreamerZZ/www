<?PHP
$defaultset = array(
'name' => "HOBBIT 4+H",
'model' => "EG2048H",
'pprice' => "0",
'wprice' => "5750",
'rprice' => "7699",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hobbit4ph.jpg",
);
?>
