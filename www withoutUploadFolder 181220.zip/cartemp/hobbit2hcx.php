<?PHP
$defaultset = array(
'name' => "HOBBIT 2HCX",
'model' => "EG2048HCX",
'pprice' => "0",
'wprice' => "5850",
'rprice' => "7899",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hobbit2hcx.jpg",
);
?>
