<?PHP
$defaultset = array(
'name' => "CRICKET 6",
'model' => "EG2068K",
'pprice' => "0",
'wprice' => "6150",
'rprice' => "8549",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/cricket6.jpg",
);
?>
