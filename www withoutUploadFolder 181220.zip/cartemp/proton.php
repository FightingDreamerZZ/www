<?PHP
$defaultset = array(
'name' => "PROTON",
'model' => "EG6030HB101",
'pprice' => "0",
'wprice' => "11799",
'rprice' => "15299",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/proton.jpg",
);
?>
