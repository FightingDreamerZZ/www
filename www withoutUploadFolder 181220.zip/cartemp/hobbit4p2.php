<?PHP
$defaultset = array(
'name' => "HOBBIT 4+2",
'model' => "EG2048KSZ",
'pprice' => "0",
'wprice' => "5750",
'rprice' => "7699",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/hobbit4p2.jpg",
);
?>
