<?PHP
$defaultset = array(
'name' => "CRICKET 4",
'model' => "EG2048K",
'pprice' => "0",
'wprice' => "4950",
'rprice' => "6599",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/cricket4.jpg",
);
?>
