<?PHP
$defaultset = array(
'name' => "RAMBLER",
'model' => "EG2040ASZ",
'pprice' => "0",
'wprice' => "6199",
'rprice' => "8299",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/rambler.jpg",
);
?>
