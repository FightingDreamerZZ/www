<?PHP
$defaultset = array(
'name' => "NOMAD",
'model' => "EG2020ASZ",
'pprice' => "0",
'wprice' => "5950",
'rprice' => "7499",
'lzone' => "c",
'lcolumn' => "1",
'llevel' => "1",
'photo' => "upload/sample/nomad.jpg",
);
?>
