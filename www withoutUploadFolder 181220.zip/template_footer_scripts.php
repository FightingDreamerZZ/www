<?php
/**
 * Created by PhpStorm.
 * User: AGT John
 * Date: 2018-12-07
 * Time: 9:57 PM
 */
?>
<!-- footer content -->
<footer>
    <div class="pull-right">
        Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
</div>
</div>

<!-- jQuery -->
<script src="p_g_dash/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="p_g_dash/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="p_g_dash/vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="p_g_dash/vendors/nprogress/nprogress.js"></script>
<!-- Chart.js -->
<script src="p_g_dash/vendors/Chart.js/dist/Chart.min.js"></script>
<!-- gauge.js -->
<script src="p_g_dash/vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="p_g_dash/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="p_g_dash/vendors/iCheck/icheck.min.js"></script>
<!-- Skycons -->
<script src="p_g_dash/vendors/skycons/skycons.js"></script>
<!-- Flot -->
<script src="p_g_dash/vendors/Flot/jquery.flot.js"></script>
<script src="p_g_dash/vendors/Flot/jquery.flot.pie.js"></script>
<script src="p_g_dash/vendors/Flot/jquery.flot.time.js"></script>
<script src="p_g_dash/vendors/Flot/jquery.flot.stack.js"></script>
<script src="p_g_dash/vendors/Flot/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="p_g_dash/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script src="p_g_dash/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="p_g_dash/vendors/flot.curvedlines/curvedLines.js"></script>
<!-- DateJS -->
<script src="p_g_dash/vendors/DateJS/build/date.js"></script>
<!-- JQVMap -->
<script src="p_g_dash/vendors/jqvmap/dist/jquery.vmap.js"></script>
<script src="p_g_dash/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
<script src="p_g_dash/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="p_g_dash/vendors/moment/min/moment.min.js"></script>
<script src="p_g_dash/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

<!-- Custom Theme Scripts -->
<script src="p_g_dash/build/js/custom.min.js"></script>

</body>
</html>
