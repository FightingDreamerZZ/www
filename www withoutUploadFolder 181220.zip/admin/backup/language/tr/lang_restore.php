<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Şimdiye kadar <b>%d</b> tablo oluşturuldu.";
$lang['L_FILE_MISSING']="Dosya bulunamadı";
$lang['L_RESTORE_DB']="Veritabanı: '<b>%s</b>' Sunucu: '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> Tablolar oluşturuldu.";
$lang['L_RESTORE_RUN1']="<br>Şimdiye kadar <b>%s</b> / <b>%s</b> kayıt işlendi.";
$lang['L_RESTORE_RUN2']="<br>İşlenen tablo '<b>%s</b>' kayıtlar işleniyor.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> Kayıtlar işlendi.";
$lang['L_RESTORE_TABLES_COMPLETED']="Şimdiye kadar <b>%d</b> / <b>%d</b> Tablo oluşturuldu.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Tebrikler.</b><br><br>Veritabanı tamamen dönüştürüldü.<br>Yedeklemedeki bulunan bütün bilgiler işlenebildi.<br><br>İşlem tamamlanmıştır. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Hata:<br>Veritabanı seçimi '<b>";
$lang['L_DB_SELECT_ERROR2']="</b>' Hata oluştu!";
$lang['L_FILE_OPEN_ERROR']="Hata: Dosya açılamadı.";
$lang['L_PROGRESS_OVER_ALL']="Süreçin tamamı";
$lang['L_BACK_TO_OVERVIEW']="Veritabanı listesi";
$lang['L_RESTORE_RUN0']="<br>Şimdiye kadar <b>%s</b> kayıt başarılı olarak işlendi.";
$lang['L_UNKNOWN_SQLCOMMAND']="Tanınmayan SQL komudu:";
$lang['L_NOTICES']="İpuçlar";


?>