<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Es sind bis ez <b>%d</b> Tabälle agleit worde.";
$lang['L_FILE_MISSING']="Han diä Datei nöd gfunde";
$lang['L_RESTORE_DB']="Datebank '<b>%s</b>' uf Server '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> Tabälle sind angleit worde.";
$lang['L_RESTORE_RUN1']="<br>Es sind bis ez <b>%s</b> vo <b>%s</b> Datesätz erfolgriich iitreit worde.";
$lang['L_RESTORE_RUN2']="<br>Momentan werdet Date vo de Tabälle '<b>%s</b>' analysiert.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> Datesätz sind iitreit worde.";
$lang['L_RESTORE_TABLES_COMPLETED']="Es sind bis ez <b>%d</b> vo <b>%d</b> Tabälle agleit worde.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Herzliche Glückwunsch.</b><br><br>Diä Datenbank isch komplett reschtauriert worde.<br>Alli Date us de Backup-Datei sind erfolgriich i diä Datebank itreit worde.<br><br>Alls fertig. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Fähler:<br>Uuswahl vo de Datebank '<b>";
$lang['L_DB_SELECT_ERROR2']="</b>' abverheit!";
$lang['L_FILE_OPEN_ERROR']="Fähler: Diä Datei hät nöd chöne ufgmacht wärde";
$lang['L_PROGRESS_OVER_ALL']="Fortschritt total";
$lang['L_BACK_TO_OVERVIEW']="Datebank-Übersicht";
$lang['L_RESTORE_RUN0']="<br>Es sind bis ez <b>%s</b> Datesätz erfolgriich iitreit worde.";
$lang['L_UNKNOWN_SQLCOMMAND']="Unbekannte SQL-Befehl:";
$lang['L_NOTICES']="Hiiwis";


?>